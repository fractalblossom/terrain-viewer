10six Toolkit 4.1 addon bundle for Blender on Linux

Contents:
- io_scene_tensix2 addon folder
- io_scene_tensix2.zip for manual install through Blender Preferences
- First-run helper script
- Linux install scripts
- Documentation

Artist quick start:
1. Unzip this package anywhere on your Linux machine.
2. If you want an automated install, run chmod +x support/install_me_first_linux.sh and then ./support/install_me_first_linux.sh.
3. Or install io_scene_tensix2.zip through Blender Preferences > Add-ons > Install.
4. Launch Blender.
5. Set 10six Data Root to the parent folder that contains your original 10six data folders.

Notes:
- This package assumes Blender is already installed on the machine.
- This package does not include original 10six game data.
- Use io_scene_tensix2.zip in Blender's installer, not the unpacked addon folder or __init__.py.
- If you install by copying files manually, copy only the inner io_scene_tensix2 folder into Blender's addons directory, not the extracted bundle folder.
- The Linux installer targets ${XDG_CONFIG_HOME:-$HOME/.config}/blender/5.1/scripts by default.
- Helper scripts, docs, and the startup helper are bundled under support/.
