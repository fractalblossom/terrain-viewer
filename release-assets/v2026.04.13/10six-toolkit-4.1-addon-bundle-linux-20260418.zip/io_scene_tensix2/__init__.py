from __future__ import annotations

from pathlib import Path
import sys

bl_info = {
    "name": "10six Toolkit 4.1",
    "author": "GitHub Copilot",
    "version": (4, 1, 0),
    "blender": (5, 1, 0),
    "location": "File > Import / Export, 3D View > Sidebar",
    "description": "Import 10six .msh assets and export Blender content through a legacy-compatible 10six .msh hierarchy writer",
    "category": "Import-Export",
}

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Operator, Panel
from bpy_extras.io_utils import ExportHelper, ImportHelper

if not __package__:
    addon_dir = Path(__file__).resolve().parent
    addon_parent = str(addon_dir.parent)
    inferred_package = addon_dir.name or "io_scene_tensix2"
    if addon_parent not in sys.path:
        sys.path.insert(0, addon_parent)
    __package__ = inferred_package
    __path__ = [str(addon_dir)]
    sys.modules.setdefault(inferred_package, sys.modules[__name__])

from .exporter import export_tensix_msh
from .foreign_export import prepare_foreign_materials
from .importer import import_msh_file
from .metadata import find_data_root
from .validation import find_asset_root, validate_roundtrip_root, write_validation_text


ADDON_MODULE_NAME = __package__ or "io_scene_tensix2"


def addon_preferences(context=None):
    preferences_owner = context.preferences if context is not None else bpy.context.preferences
    addon_map = preferences_owner.addons
    if ADDON_MODULE_NAME in addon_map:
        return addon_map[ADDON_MODULE_NAME].preferences
    short_name = ADDON_MODULE_NAME.rsplit(".", 1)[-1]
    if short_name in addon_map:
        return addon_map[short_name].preferences
    for module_name, addon in addon_map.items():
        if module_name == short_name or module_name.endswith(f".{short_name}"):
            return addon.preferences
    return None


def save_user_preferences(report=None) -> None:
    try:
        bpy.ops.wm.save_userpref()
    except Exception as exc:
        if report is not None:
            report({"WARNING"}, f"Saved 10six settings for this session, but Blender could not write user preferences: {exc}")


def _preferences_data_root(preferences) -> str:
    return (getattr(preferences, "data_root", "") or getattr(preferences, "sixpack_root", "") or "").strip()


def _set_preferences_data_root(preferences, value: str) -> None:
    preferences.data_root = value
    if hasattr(preferences, "sixpack_root"):
        preferences.sixpack_root = value


def detect_and_optionally_store_data_root(filepath: str, context, report=None, save_if_empty: bool = True) -> Path | None:
    detected_root = find_data_root(filepath)
    if detected_root is None:
        return None

    preferences = addon_preferences(context)
    if preferences is None:
        return detected_root

    current_root = _preferences_data_root(preferences)
    if current_root:
        return Path(current_root)

    if save_if_empty:
        _set_preferences_data_root(preferences, str(detected_root))
        save_user_preferences(report=report)
        if report is not None:
            report({"INFO"}, f"Detected 10six Data Root: {detected_root}")
    return detected_root


def detect_and_optionally_store_sixpack_root(filepath: str, context, report=None, save_if_empty: bool = True) -> Path | None:
    return detect_and_optionally_store_data_root(filepath, context, report=report, save_if_empty=save_if_empty)


class TENSIX_AddonPreferences(AddonPreferences):
    bl_idname = ADDON_MODULE_NAME

    data_root: StringProperty(
        name="10six Data Root",
        description="Parent folder that contains the original 10six data folders",
        subtype="DIR_PATH",
        default="",
    )
    sixpack_root: StringProperty(
        name="Legacy 10six Data Root",
        description="Legacy compatibility storage for older toolkit versions",
        subtype="DIR_PATH",
        default="",
        options={"HIDDEN"},
    )
    texture_root_override: StringProperty(
        name="Texture Root Override",
        description="Optional override for texture lookup; leave empty for automatic texture discovery inside the original data tree",
        subtype="DIR_PATH",
        default="",
    )
    alias_file_override: StringProperty(
        name="Alias File Override",
        description="Optional override for texture_aliases.json when using a decoded workspace outside the original data tree",
        subtype="FILE_PATH",
        default="",
    )

    def draw(self, _context):
        layout = self.layout
        layout.label(text="Artist Setup")
        layout.prop(self, "data_root")
        layout.label(text="Set this once to the parent folder that contains the original 10six data folders.")

        advanced = layout.box()
        advanced.label(text="Advanced Overrides")
        advanced.prop(self, "texture_root_override")
        advanced.prop(self, "alias_file_override")


class PREFERENCES_OT_tensix_open(Operator):
    bl_idname = "preferences.tensix_open"
    bl_label = "Open 10six Preferences"
    bl_options = {"INTERNAL"}

    def execute(self, _context):
        bpy.ops.screen.userpref_show("INVOKE_DEFAULT")
        bpy.ops.preferences.addon_show(module=ADDON_MODULE_NAME)
        return {"FINISHED"}


class PREFERENCES_OT_tensix_detect_from_msh(Operator, ImportHelper):
    bl_idname = "preferences.tensix_detect_from_msh"
    bl_label = "Detect 10six Data Root From Mesh"
    bl_options = {"REGISTER"}

    filename_ext = ".msh"
    filter_glob: StringProperty(default="*.msh", options={"HIDDEN"})
    save_to_preferences: BoolProperty(
        name="Save To Preferences",
        description="Store the detected 10six Data Root so artists only need to point Blender there once",
        default=True,
    )

    def execute(self, context):
        detected_root = find_data_root(self.filepath)
        if detected_root is None:
            self.report({"ERROR"}, "Could not detect a 10six Data Root from that .msh path")
            return {"CANCELLED"}

        preferences = addon_preferences(context)
        if preferences is not None and self.save_to_preferences:
            _set_preferences_data_root(preferences, str(detected_root))
            save_user_preferences(report=self.report)
            self.report({"INFO"}, f"Saved 10six Data Root: {detected_root}")
        else:
            self.report({"INFO"}, f"Detected 10six Data Root: {detected_root}")
        return {"FINISHED"}


class IMPORT_SCENE_OT_tensix_msh(Operator, ImportHelper):
    bl_idname = "import_scene.tensix_msh"
    bl_label = "Import 10six Mesh"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".msh"
    filter_glob: StringProperty(default="*.msh", options={"HIDDEN"})

    find_smsh: BoolProperty(
        name="Find SMSH Sidecar",
        description="Try common decoded_10six path conventions to locate a matching .smsh file",
        default=True,
    )
    create_debug_empties: BoolProperty(
        name="Create Debug Empties",
        description="Create placeholder empties for named mesh parts and markers",
        default=True,
    )
    write_text_report: BoolProperty(
        name="Create Text Report",
        description="Create a Blender text datablock with the parsed import summary",
        default=True,
    )
    auto_detect_data_root: BoolProperty(
        name="Auto-Detect Data Root",
        description="If no 10six Data Root is configured yet, infer it from the selected .msh and save it",
        default=True,
    )

    def execute(self, context):
        if self.auto_detect_data_root:
            detect_and_optionally_store_data_root(
                filepath=self.filepath,
                context=context,
                report=self.report,
                save_if_empty=True,
            )
        return import_msh_file(
            context=context,
            filepath=self.filepath,
            find_smsh=self.find_smsh,
            create_debug_empties=self.create_debug_empties,
            write_text_report=self.write_text_report,
            report=self.report,
        )


class IMPORT_SCENE_OT_tensix_foreign_asset(Operator, ImportHelper):
    bl_idname = "import_scene.tensix_foreign_asset"
    bl_label = "Import Foreign Asset For 10six"
    bl_options = {"REGISTER", "UNDO"}

    filter_glob: StringProperty(default="*.fbx;*.obj", options={"HIDDEN"})

    auto_prepare_materials: BoolProperty(
        name="Prepare Materials For 10six",
        description="Bake the current procedural look into base maps and create artist override maps after import",
        default=True,
    )

    def execute(self, context):
        suffix = Path(self.filepath).suffix.lower()
        if suffix == ".fbx":
            result = bpy.ops.import_scene.fbx(filepath=self.filepath)
        elif suffix == ".obj":
            result = bpy.ops.wm.obj_import(filepath=self.filepath)
        else:
            self.report({"ERROR"}, "Only .fbx and .obj are supported by the 10six foreign import workflow")
            return {"CANCELLED"}

        if "FINISHED" not in result:
            self.report({"ERROR"}, f"Foreign import failed for {Path(self.filepath).name}")
            return {"CANCELLED"}

        context.scene.tensix_export_mode = "FOREIGN"
        if self.auto_prepare_materials:
            active = next((obj for obj in context.selected_objects if obj.type == "ARMATURE"), None)
            if active is None and context.selected_objects:
                active = context.selected_objects[0]
            if active is not None:
                context.view_layer.objects.active = active
            return prepare_foreign_materials(
                context=context,
                report=self.report,
                texture_size=context.scene.tensix_foreign_prep_texture_size,
            )

        self.report({"INFO"}, f"Imported foreign asset {Path(self.filepath).name}")
        return {"FINISHED"}


class EXPORT_SCENE_OT_tensix_msh(Operator, ExportHelper):
    bl_idname = "export_scene.tensix_msh"
    bl_label = "Export 10six Mesh"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".msh"
    filter_glob: StringProperty(default="*.msh", options={"HIDDEN"})

    def execute(self, context):
        return export_tensix_msh(
            context=context,
            filepath=self.filepath,
            report=self.report,
            export_mode=context.scene.tensix_export_mode,
            texture_size=context.scene.tensix_foreign_texture_size,
            emit_reports=context.scene.tensix_foreign_emit_reports,
        )


class OBJECT_OT_tensix_validate(Operator):
    bl_idname = "object.tensix_validate"
    bl_label = "Validate 10six Asset"
    bl_options = {"REGISTER"}

    def execute(self, context):
        active = context.active_object
        if active is None:
            self.report({"ERROR"}, "No active object selected")
            return {"CANCELLED"}
        root = find_asset_root(active)
        if root is None:
            self.report({"ERROR"}, "Active object is not part of an imported 10six asset")
            return {"CANCELLED"}

        validation, _parsed = validate_roundtrip_root(root)
        write_validation_text(validation)
        if validation.errors:
            self.report({"ERROR"}, f"10six validation found {len(validation.errors)} error(s)")
            return {"CANCELLED"}
        if validation.warnings:
            self.report({"WARNING"}, f"10six validation passed with {len(validation.warnings)} warning(s)")
            return {"FINISHED"}
        self.report({"INFO"}, "10six validation passed")
        return {"FINISHED"}


class OBJECT_OT_tensix_prepare_foreign_materials(Operator):
    bl_idname = "object.tensix_prepare_foreign_materials"
    bl_label = "Prepare Foreign Materials"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        return prepare_foreign_materials(
            context=context,
            report=self.report,
            texture_size=context.scene.tensix_foreign_prep_texture_size,
        )


class VIEW3D_PT_tensix_tools(Panel):
    bl_label = "10six"
    bl_idname = "VIEW3D_PT_tensix_tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "10six"

    def draw(self, context):
        layout = self.layout
        preferences = addon_preferences(context)

        setup_box = layout.box()
        setup_box.label(text="Artist Setup")
        if preferences is not None:
            setup_box.prop(preferences, "data_root", text="10six Data Root")
            current_data_root = _preferences_data_root(preferences)
            if current_data_root:
                setup_box.label(text=f"Using: {Path(current_data_root).name}")
            else:
                setup_box.label(text="Set the parent folder that contains your original 10six data folders")
        setup_box.operator(PREFERENCES_OT_tensix_open.bl_idname, text="Open Add-on Preferences")
        setup_box.operator(PREFERENCES_OT_tensix_detect_from_msh.bl_idname, text="Detect Data Root From .msh")

        layout.prop(context.scene, "tensix_export_mode", text="Export Mode")
        if context.scene.tensix_export_mode == "FOREIGN":
            foreign_box = layout.box()
            foreign_box.label(text="Foreign Export")
            foreign_box.prop(context.scene, "tensix_foreign_texture_size", text="Texture Size")
            foreign_box.prop(context.scene, "tensix_foreign_prep_texture_size", text="Prep Texture Size")
            foreign_box.prop(context.scene, "tensix_foreign_emit_reports", text="Write JSON Reports")
            foreign_box.operator(OBJECT_OT_tensix_prepare_foreign_materials.bl_idname, text="Prepare Foreign Materials")
            foreign_box.label(text="Import FBX/OBJ here or run prep after opening a foreign .blend.")
        layout.operator(OBJECT_OT_tensix_validate.bl_idname, text="Validate Active Asset")
        layout.operator(EXPORT_SCENE_OT_tensix_msh.bl_idname, text="Export 10six Mesh")

        active = context.active_object
        if active is None:
            layout.label(text="No active object")
            return

        root = find_asset_root(active)
        if root is None:
            if context.scene.tensix_export_mode == "FOREIGN":
                layout.label(text="Foreign export uses the active mesh or armature selection")
            else:
                layout.label(text="Active object is not a 10six asset")
            return

        source_path = root.get("tensix_source_msh", "")
        layout.label(text=f"Source: {Path(source_path).name if source_path else '<unknown>'}")

        validation, _parsed = validate_roundtrip_root(root)
        if validation.errors:
            layout.label(text=f"Errors: {len(validation.errors)}")
        elif validation.warnings:
            layout.label(text=f"Warnings: {len(validation.warnings)}")
        else:
            layout.label(text="Validation: clean")


def menu_func_import(self, _context):
    self.layout.operator(IMPORT_SCENE_OT_tensix_msh.bl_idname, text="10six Mesh (.msh)")
    self.layout.operator(IMPORT_SCENE_OT_tensix_foreign_asset.bl_idname, text="10six Foreign Asset (.fbx/.obj)")


def menu_func_export(self, _context):
    self.layout.operator(EXPORT_SCENE_OT_tensix_msh.bl_idname, text="10six Mesh (.msh)")


classes = (
    TENSIX_AddonPreferences,
    PREFERENCES_OT_tensix_open,
    PREFERENCES_OT_tensix_detect_from_msh,
    IMPORT_SCENE_OT_tensix_msh,
    IMPORT_SCENE_OT_tensix_foreign_asset,
    EXPORT_SCENE_OT_tensix_msh,
    OBJECT_OT_tensix_validate,
    OBJECT_OT_tensix_prepare_foreign_materials,
    VIEW3D_PT_tensix_tools,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    bpy.types.Scene.tensix_export_mode = EnumProperty(
        name="10six Export Mode",
        items=(
            ("ROUND_TRIP", "Round Trip", "Export imported original 10six assets back to .msh"),
            ("FOREIGN", "Foreign Asset Conversion", "Convert selected Blender meshes to a standalone 10six .msh package"),
        ),
        default="ROUND_TRIP",
    )
    bpy.types.Scene.tensix_foreign_texture_size = IntProperty(
        name="Foreign Texture Size",
        description="Texture size used by future bake-based export steps and metadata",
        default=512,
        min=64,
        max=4096,
    )
    bpy.types.Scene.tensix_foreign_prep_texture_size = IntProperty(
        name="Foreign Prep Texture Size",
        description="Texture size used when baking procedural foreign materials into editable PNG maps",
        default=1024,
        min=64,
        max=4096,
    )
    bpy.types.Scene.tensix_foreign_emit_reports = BoolProperty(
        name="Write Foreign Export Reports",
        description="Write texture and animation analysis JSON files next to foreign exports",
        default=True,
    )


def unregister():
    del bpy.types.Scene.tensix_foreign_emit_reports
    del bpy.types.Scene.tensix_foreign_prep_texture_size
    del bpy.types.Scene.tensix_foreign_texture_size
    del bpy.types.Scene.tensix_export_mode
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
