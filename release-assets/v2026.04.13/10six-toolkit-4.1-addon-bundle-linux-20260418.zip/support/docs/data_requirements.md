# Data Requirements

## Required User-Owned Data

This toolkit expects the user to supply their own legally obtained 10six data.

Minimum expectation:

- a local folder containing one of the original numbered 10six data-pack layouts recognized by the addon

Example shape:

```text
10six_data/
  visitor0/
  visitor1/
  visitor2/
  ...
```

Alternative accepted shape:

```text
10six_data/
  <other original numbered data-pack folders>/
  ...
```

## What The Toolkit Uses

- `.msh` files for mesh import and round-trip export
- texture files from the original data tree, typically under the `files/bmp` folder inside one of the original data packs
- optional `.smsh` sidecars when present and discoverable

## What The Toolkit Does Not Bundle

- original art assets
- original game installers
- decoded source payloads from this workspace

## Why

The toolkit is intended to distribute tooling, not game content.