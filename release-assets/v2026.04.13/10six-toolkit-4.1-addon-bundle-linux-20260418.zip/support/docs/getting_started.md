# Getting Started

## Audience

This toolkit is for artists who already have the original 10six data folders.

You do not need this source repository to use the intended workflow.

## What You Need

Before launching the toolkit, you need access to the original 10six data root.

The exact folder names can vary by source distribution.

What matters is that you point the addon at the parent folder that contains the original numbered data packs.

Recommended Blender source for testing and packaging:

- the official Blender 5.1 release for your platform

Do not build Blender from source unless we hit a real add-on host limitation that cannot be solved in packaged stock Blender.

## First-Time Setup

1. Launch the packaged Blender build or Blender with the 10six add-on installed.
2. If you are installing through Blender Preferences, choose `io_scene_tensix2.zip` from the extracted bundle root with `Install from Disk`.
3. Do not point Blender at the unpacked addon folder or the addon `__init__.py` file.
4. If you are copying files manually, copy only the inner `io_scene_tensix2` folder into Blender's `addons` directory. Do not copy the extracted bundle folder itself.
5. In the extracted addon bundle, the Linux helper script is `support/install_me_first_linux.sh`.
6. If the 10six add-on is not already enabled, enable it once in Blender Preferences.
7. If needed, use `Detect Data Root From .msh` in the 10six panel and select any original `.msh` file from your data folders.
8. Set `10six Data Root` to the parent folder that contains the original 10six data folders.
9. Save preferences if you want Blender to remember the path.

That is the main setup step.

## Import Flow

1. Choose `File > Import > 10six Mesh`.
2. Browse to a `.msh` file inside your original 10six data folders.
3. Import the asset.

The add-on uses your configured `10six Data Root` to locate textures and related source files where possible.

## Export Flow

1. Edit the imported asset within the supported feature set.
2. Run `Validate Active Asset` from the 10six panel.
3. If validation passes, choose `File > Export > 10six Mesh`.

## Foreign Export Flow

1. Import the source asset with Blender's built-in FBX or OBJ importer.
2. Select the mesh objects you want to export, or select the armature if the model is armature-driven.
3. In the `10six` panel, switch `Export Mode` to `Foreign Asset Conversion`.
4. Export to a new `.msh` path.
5. Review the generated `.textures.json` and, for rigged assets, `.anm` and `.animation_report.json` files next to the export.
6. Re-exporting to the same destination replaces the prior texture folder and `.anm` outputs for that asset.

## Current Limitations

- round-trip export is still the safest path for editing original 10six assets
- foreign export uses the dedicated legacy-style `.msh` writer for both static and rigid skeletal exports, with `.anm` output for rigid armature-driven assets
- foreign export bakes diffuse BMP textures when the source material is procedural or node-based
- weighted skin export is not implemented yet; the current skeletal export path is intended for rigid bone-parented assets

## Support Principle

If artists need to do anything more complicated than pointing Blender at their original 10six data root, the packaging is not simple enough yet.