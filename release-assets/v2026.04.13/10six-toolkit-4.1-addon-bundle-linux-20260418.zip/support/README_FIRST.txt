﻿1. Install the addon:
	- Windows: double-click install_me_first.bat in this folder
	- Linux: run chmod +x ./install_me_first_linux.sh and then ./install_me_first_linux.sh from this folder
	- Or install io_scene_tensix2.zip from Blender Preferences > Add-ons using the extracted bundle root
	- Do not point Blender's installer at the unpacked io_scene_tensix2 folder or __init__.py
	- If you copy files manually, copy only the inner io_scene_tensix2 folder into Blender's addons directory, not the extracted bundle folder itself
2. Launch Blender 5.1
3. Open the 10six panel
4. Set 10six Data Root to your original 10six data root folder
5. For foreign meshes, import FBX/OBJ with Blender first, switch Export Mode to FOREIGN, then export to 10six .msh

If needed:
- docs\artist_cheat_sheet.md
- docs\getting_started.md
