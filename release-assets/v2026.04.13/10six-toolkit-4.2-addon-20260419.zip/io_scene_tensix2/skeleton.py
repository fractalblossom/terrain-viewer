"""Build a real Blender armature from parsed 10six BONE chunks (4.1).

Replaces the 4.0 placeholder, which only created an EMPTY. Each BONE chunk
becomes a Blender edit bone whose head is positioned at the bone's world-space
translation (composed from the parent chain). Bones are parented per the
original ``child_count`` stack-derived hierarchy.

Each pose bone is tagged with ``tensix_seq_idx`` so the .anm importer and the
exporter can re-establish the original 0..N-1 ordering used by .anm bone
references.
"""
from __future__ import annotations

import bpy
from mathutils import Vector

from .parser import ParsedMsh


_DEFAULT_BONE_LENGTH = 1.0


def build_armature(collection, parsed: ParsedMsh, root_empty=None):
    if not parsed.bones:
        return None

    armature_data = bpy.data.armatures.new(f"{parsed.path.stem}_armature")
    armature_obj = bpy.data.objects.new(f"{parsed.path.stem}_armature", armature_data)
    armature_obj["tensix_role"] = "armature"
    armature_obj["tensix_source_msh"] = str(parsed.path)
    armature_obj["tensix_bone_count"] = len(parsed.bones)
    if root_empty is not None:
        armature_obj.parent = root_empty
    collection.objects.link(armature_obj)

    view_layer = bpy.context.view_layer
    previous_active = view_layer.objects.active
    view_layer.objects.active = armature_obj
    bpy.ops.object.mode_set(mode="EDIT")
    try:
        edit_bones = armature_data.edit_bones
        seen_names: dict[str, int] = {}
        seq_to_name: dict[int, str] = {}
        for bone in parsed.bones:
            base = bone.name or f"bone_{bone.seq_idx:02d}"
            count = seen_names.get(base, 0)
            seen_names[base] = count + 1
            unique = base if count == 0 else f"{base}.{count:03d}"
            seq_to_name[bone.seq_idx] = unique

        for bone in parsed.bones:
            edit = edit_bones.new(seq_to_name[bone.seq_idx])
            head = Vector(bone.world_translation)
            edit.head = head
            edit.tail = head + Vector((0.0, 0.0, _DEFAULT_BONE_LENGTH))
            edit["tensix_seq_idx"] = bone.seq_idx
            edit["tensix_vert_chunk_idx"] = bone.vert_chunk_idx

        for bone in parsed.bones:
            if bone.parent_seq_idx is None:
                continue
            child_edit = edit_bones[seq_to_name[bone.seq_idx]]
            parent_edit = edit_bones[seq_to_name[bone.parent_seq_idx]]
            child_edit.parent = parent_edit
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        view_layer.objects.active = previous_active

    for bone in parsed.bones:
        pose_bone = armature_obj.pose.bones.get(seq_to_name[bone.seq_idx])
        if pose_bone is None:
            continue
        pose_bone["tensix_seq_idx"] = bone.seq_idx
        pose_bone["tensix_vert_chunk_idx"] = bone.vert_chunk_idx
        pose_bone["tensix_local_matrix"] = [list(row) for row in bone.local_matrix]
        pose_bone["tensix_pivot"] = list(bone.pivot)

    armature_obj["tensix_bone_seq_to_name"] = {str(k): v for k, v in seq_to_name.items()}
    return armature_obj


def build_skeleton_placeholder(collection, parsed: ParsedMsh, root_empty=None):
    """Backwards-compatible alias for the 4.0 importer entry point."""
    return build_armature(collection, parsed, root_empty=root_empty)

