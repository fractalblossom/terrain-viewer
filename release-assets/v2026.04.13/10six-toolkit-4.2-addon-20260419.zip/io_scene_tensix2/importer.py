from __future__ import annotations

from pathlib import Path

import bpy

from .animation import collect_animation_notes
from .anm_importer import import_anm_to_action
from .debug import build_import_report
from .mesh_builder import build_asset_collection
from .metadata import find_smsh_sidecar, parse_smsh_strings
from .parser import parse_msh
from .skeleton import build_armature


def _find_sibling_anm_files(msh_path: Path) -> list[Path]:
    parent = msh_path.parent
    stem = msh_path.stem
    matches: list[Path] = []
    exact = parent / f"{stem}.anm"
    if exact.exists():
        matches.append(exact)
    for path in sorted(parent.glob(f"{stem}_*.anm")):
        if path not in matches:
            matches.append(path)
    return matches


def import_msh_file(
    context,
    filepath: str,
    find_smsh: bool,
    create_debug_empties: bool,
    write_text_report: bool,
    report,
    *,
    import_anm: bool = True,
):
    try:
        parsed = parse_msh(filepath)
    except Exception as exc:
        report({"ERROR"}, f"10six import failed: {exc}")
        return {"CANCELLED"}

    smsh_info = None
    if find_smsh:
        smsh_path = find_smsh_sidecar(filepath)
        if smsh_path:
            parsed.smsh_path = Path(smsh_path)
            smsh_info = parse_smsh_strings(smsh_path)

    collection, root_empty = build_asset_collection(context, parsed, create_debug_empties=create_debug_empties)
    armature = build_armature(collection, parsed, root_empty=root_empty)

    if parsed.smsh_path:
        collection["tensix_source_smsh"] = str(parsed.smsh_path)
    if armature is not None:
        collection["tensix_has_armature"] = True
        collection["tensix_armature_object"] = armature.name

    notes = collect_animation_notes(parsed)
    for index, note in enumerate(notes):
        collection[f"note_{index:02d}"] = note

    anm_loaded: list[str] = []
    if import_anm and armature is not None:
        for anm_path in _find_sibling_anm_files(Path(filepath)):
            try:
                action, _ = import_anm_to_action(armature, anm_path, action_name=anm_path.stem, report=report)
            except Exception as exc:
                report({"WARNING"}, f"Failed to import {anm_path.name}: {exc}")
                continue
            if action is not None:
                anm_loaded.append(anm_path.name)
        if anm_loaded:
            collection["tensix_imported_anm"] = anm_loaded

    if write_text_report:
        text_name = f"10six_{parsed.path.stem}_report.txt"
        text_block = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
        text_block.clear()
        text_block.write(build_import_report(parsed, smsh_info=smsh_info))

    extras = ""
    if armature is not None:
        extras += f", armature={len(parsed.bones)} bones"
    if anm_loaded:
        extras += f", anm={len(anm_loaded)}"
    report(
        {"INFO"},
        f"Imported {parsed.path.name}: {len(parsed.parts)} parts, {len(parsed.chunks)} chunks{extras}",
    )
    return {"FINISHED"}

