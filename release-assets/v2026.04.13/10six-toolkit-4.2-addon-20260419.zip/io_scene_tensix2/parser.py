from __future__ import annotations

import struct
from collections import Counter
from dataclasses import dataclass, field, replace
from pathlib import Path


MSH_MAGIC = 0x1234ABCD
MSH_VERSION = 8

NAME_CHUNK = 0x00000003
MESH_CHUNK_BONE = 0x00010002
MESH_CHUNK_VERTEX = 0x00010003
MESH_CHUNK_FACES = 0x00010008
MESH_CHUNK_MATERIAL = 0x00010009
MESH_CHUNK_FACES_EXT = 0x0001000A

MAX_POSITION_ABS = 1_000_000.0
MAX_UV_ABS = 1024.0


@dataclass(frozen=True)
class ChunkEntry:
    index: int
    chunk_type: int
    offset: int
    size: int


@dataclass(frozen=True)
class TriangleSource:
    chunk_index: int
    chunk_type: int
    record_index: int
    record_size: int
    primitive_type: int
    triangle_slot: int
    flipped: bool = False


@dataclass
class BoneInfo:
    seq_idx: int
    chunk_idx: int
    child_count: int
    matrix: list[list[float]]
    pivot: tuple[float, float, float]
    vert_chunk_idx: int
    children: list[BoneInfo] = field(default_factory=list)
    parent: BoneInfo | None = None


@dataclass
class ParsedBone:
    """Public bone record for armature import (4.1 anim pipeline).

    ``seq_idx`` matches the bone_index referenced by ``.anm`` BONE chunks.
    Local matrix/pivot are exactly what was written to disk; world matrix /
    world translation are pre-composed for convenient edit-bone placement.
    """
    seq_idx: int
    name: str
    parent_seq_idx: int | None
    vert_chunk_idx: int
    local_matrix: list[list[float]]
    pivot: tuple[float, float, float]
    world_matrix: list[list[float]]
    world_translation: tuple[float, float, float]


@dataclass
class MeshPart:
    name: str
    vertex_chunk_index: int
    vertex_chunk_offset: int
    vertex_chunk_size: int
    vertices: list[tuple[float, float, float]]
    uvs: list[tuple[float, float]]
    faces: list[tuple[int, int, int]]
    face_uvs: list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]]
    face_material_indices: list[int]
    material_textures: list[str]
    world_matrix: list[list[float]] | None = None
    world_translation: tuple[float, float, float] = (0.0, 0.0, 0.0)
    triangle_sources: list[TriangleSource] = field(default_factory=list)
    face_chunk_index: int | None = None
    face_chunk_type: int | None = None


@dataclass
class ParsedMsh:
    path: Path
    version: int
    chunks: list[ChunkEntry]
    chunk_type_counts: dict[str, int]
    named_vertex_chunks: list[str]
    parts: list[MeshPart]
    warnings: list[str] = field(default_factory=list)
    smsh_path: Path | None = None
    bones: list[ParsedBone] = field(default_factory=list)


def read_c_string(blob: bytes) -> str:
    if not blob:
        return ""
    terminator = blob.find(b"\x00")
    if terminator >= 0:
        blob = blob[:terminator]
    return blob.decode("latin1", errors="ignore").strip()


def sanitize_float(value: float, max_abs: float) -> float:
    if value != value:
        return 0.0
    if value > max_abs:
        return max_abs
    if value < -max_abs:
        return -max_abs
    return value


def _mat3_mul(a: list[list[float]], b: list[list[float]]) -> list[list[float]]:
    return [[sum(a[row][k] * b[k][col] for k in range(3)) for col in range(3)] for row in range(3)]


def _mat3_vec(matrix: list[list[float]], vector: tuple[float, float, float]) -> tuple[float, float, float]:
    return (
        matrix[0][0] * vector[0] + matrix[0][1] * vector[1] + matrix[0][2] * vector[2],
        matrix[1][0] * vector[0] + matrix[1][1] * vector[1] + matrix[1][2] * vector[2],
        matrix[2][0] * vector[0] + matrix[2][1] * vector[1] + matrix[2][2] * vector[2],
    )


def read_chunks(data: bytes) -> tuple[int, list[ChunkEntry]]:
    if len(data) < 40:
        raise ValueError("File too small for 10six header")
    magic, version = struct.unpack_from("<II", data, 0)
    if magic != MSH_MAGIC:
        raise ValueError(f"Unexpected magic 0x{magic:08X}; expected 0x{MSH_MAGIC:08X}")
    if version != MSH_VERSION:
        raise ValueError(f"Unexpected version {version}; expected {MSH_VERSION}")

    first_offset = struct.unpack_from("<I", data, 36)[0]
    if first_offset < 32 or first_offset > len(data):
        raise ValueError(f"Invalid first chunk offset {first_offset}")

    entry_count = (first_offset - 32) // 12
    chunks: list[ChunkEntry] = []
    for index in range(entry_count):
        chunk_type, offset, size = struct.unpack_from("<III", data, 32 + index * 12)
        if offset + size > len(data):
            continue
        chunks.append(ChunkEntry(index=index, chunk_type=chunk_type, offset=offset, size=size))
    return version, chunks


def classify_chunk(chunk_type: int) -> str:
    mapping = {
        NAME_CHUNK: "name",
        MESH_CHUNK_BONE: "bone",
        MESH_CHUNK_VERTEX: "vertex",
        MESH_CHUNK_FACES: "faces",
        MESH_CHUNK_MATERIAL: "material",
        MESH_CHUNK_FACES_EXT: "faces_ext",
    }
    return mapping.get(chunk_type, f"unknown_0x{chunk_type:08X}")


def canonical_texture_ref(texture_name: str) -> str:
    normalized = texture_name.replace("\\", "/").strip()
    if "/" in normalized:
        normalized = normalized.rsplit("/", 1)[-1]
    return normalized


def build_bone_transforms(data: bytes, chunks: list[ChunkEntry]) -> dict[int, tuple[list[list[float]], tuple[float, float, float]]]:
    bone_chunks = [chunk for chunk in chunks if chunk.chunk_type == MESH_CHUNK_BONE]
    if not bone_chunks:
        return {}

    bones: list[BoneInfo] = []
    for seq, chunk in enumerate(bone_chunks):
        blob = data[chunk.offset:chunk.offset + chunk.size]
        if len(blob) < 88:
            continue
        ints = struct.unpack_from("<6I", blob, 0)
        child_count = struct.unpack_from("<I", blob, 24)[0]
        matrix = [list(struct.unpack_from("<3f", blob, 28 + row * 16)) for row in range(3)]
        pivot = struct.unpack_from("<3f", blob, 76)
        bones.append(
            BoneInfo(
                seq_idx=seq,
                chunk_idx=chunk.index,
                child_count=child_count,
                matrix=matrix,
                pivot=pivot,
                vert_chunk_idx=ints[1] - 1,
            )
        )

    stack: list[BoneInfo] = []
    for bone in bones:
        if bone.child_count > 0 and len(stack) >= bone.child_count:
            bone.children = stack[-bone.child_count:]
            stack = stack[:-bone.child_count]
            for child in bone.children:
                child.parent = bone
        stack.append(bone)

    root = stack[-1] if stack else None
    if root is None:
        return {}

    world_matrix: dict[int, list[list[float]]] = {}
    world_translation: dict[int, tuple[float, float, float]] = {}

    def _walk(bone: BoneInfo) -> None:
        if bone.parent is None:
            world_matrix[bone.seq_idx] = bone.matrix
            world_translation[bone.seq_idx] = (0.0, 0.0, 0.0)
        else:
            parent_matrix = world_matrix[bone.parent.seq_idx]
            parent_translation = world_translation[bone.parent.seq_idx]
            world_matrix[bone.seq_idx] = _mat3_mul(parent_matrix, bone.matrix)
            world_translation[bone.seq_idx] = (
                parent_matrix[0][0] * bone.pivot[0] + parent_matrix[0][1] * bone.pivot[1] + parent_matrix[0][2] * bone.pivot[2] + parent_translation[0],
                parent_matrix[1][0] * bone.pivot[0] + parent_matrix[1][1] * bone.pivot[1] + parent_matrix[1][2] * bone.pivot[2] + parent_translation[1],
                parent_matrix[2][0] * bone.pivot[0] + parent_matrix[2][1] * bone.pivot[1] + parent_matrix[2][2] * bone.pivot[2] + parent_translation[2],
            )
        for child in bone.children:
            _walk(child)

    _walk(root)

    result: dict[int, tuple[list[list[float]], tuple[float, float, float]]] = {}
    for bone in bones:
        result[bone.vert_chunk_idx] = (world_matrix[bone.seq_idx], world_translation[bone.seq_idx])
    return result


def build_bone_name_map(data: bytes, chunks: list[ChunkEntry]) -> dict[int, str]:
    name_map: dict[int, str] = {}
    for index, chunk in enumerate(chunks):
        if chunk.chunk_type != MESH_CHUNK_BONE:
            continue
        blob = data[chunk.offset:chunk.offset + chunk.size]
        if len(blob) < 8:
            continue
        vertex_chunk_index = struct.unpack_from("<I", blob, 4)[0] - 1
        if index > 0 and chunks[index - 1].chunk_type == NAME_CHUNK:
            name = read_c_string(data[chunks[index - 1].offset:chunks[index - 1].offset + chunks[index - 1].size])
            if name:
                name_map[vertex_chunk_index] = name
    return name_map


def build_parsed_bones(data: bytes, chunks: list[ChunkEntry]) -> list[ParsedBone]:
    """Return a public bone list ordered by BONE-chunk sequence (.anm bone_index).

    Re-parses the BONE chunks (matches ``build_bone_transforms`` layout) and
    walks the same child-count stack to derive parent/child relationships.
    Returned bones are in the same seq order as ``.anm`` BONE references.
    """
    bone_chunks = [chunk for chunk in chunks if chunk.chunk_type == MESH_CHUNK_BONE]
    if not bone_chunks:
        return []

    name_map = build_bone_name_map(data, chunks)

    bones: list[BoneInfo] = []
    for seq, chunk in enumerate(bone_chunks):
        blob = data[chunk.offset:chunk.offset + chunk.size]
        if len(blob) < 88:
            continue
        ints = struct.unpack_from("<6I", blob, 0)
        child_count = struct.unpack_from("<I", blob, 24)[0]
        matrix = [list(struct.unpack_from("<3f", blob, 28 + row * 16)) for row in range(3)]
        pivot = struct.unpack_from("<3f", blob, 76)
        bones.append(
            BoneInfo(
                seq_idx=seq,
                chunk_idx=chunk.index,
                child_count=child_count,
                matrix=matrix,
                pivot=pivot,
                vert_chunk_idx=ints[1] - 1,
            )
        )

    stack: list[BoneInfo] = []
    for bone in bones:
        if bone.child_count > 0 and len(stack) >= bone.child_count:
            bone.children = stack[-bone.child_count:]
            stack = stack[:-bone.child_count]
            for child in bone.children:
                child.parent = bone
        stack.append(bone)

    root = stack[-1] if stack else None
    if root is None:
        return []

    world_matrix: dict[int, list[list[float]]] = {}
    world_translation: dict[int, tuple[float, float, float]] = {}

    def _walk(bone: BoneInfo) -> None:
        if bone.parent is None:
            world_matrix[bone.seq_idx] = bone.matrix
            world_translation[bone.seq_idx] = (0.0, 0.0, 0.0)
        else:
            pm = world_matrix[bone.parent.seq_idx]
            pt = world_translation[bone.parent.seq_idx]
            world_matrix[bone.seq_idx] = _mat3_mul(pm, bone.matrix)
            world_translation[bone.seq_idx] = (
                pm[0][0] * bone.pivot[0] + pm[0][1] * bone.pivot[1] + pm[0][2] * bone.pivot[2] + pt[0],
                pm[1][0] * bone.pivot[0] + pm[1][1] * bone.pivot[1] + pm[1][2] * bone.pivot[2] + pt[1],
                pm[2][0] * bone.pivot[0] + pm[2][1] * bone.pivot[1] + pm[2][2] * bone.pivot[2] + pt[2],
            )
        for child in bone.children:
            _walk(child)

    _walk(root)

    parsed: list[ParsedBone] = []
    for bone in bones:
        name = name_map.get(bone.vert_chunk_idx, f"bone_{bone.seq_idx:02d}")
        parsed.append(
            ParsedBone(
                seq_idx=bone.seq_idx,
                name=name,
                parent_seq_idx=bone.parent.seq_idx if bone.parent is not None else None,
                vert_chunk_idx=bone.vert_chunk_idx,
                local_matrix=bone.matrix,
                pivot=bone.pivot,
                world_matrix=world_matrix[bone.seq_idx],
                world_translation=world_translation[bone.seq_idx],
            )
        )
    return parsed


def parse_material_texture(chunk_blob: bytes) -> str | None:
    if len(chunk_blob) < 36:
        return None
    name = read_c_string(chunk_blob[32:])
    return canonical_texture_ref(name) if name else None


def parse_material_textures(chunk_blob: bytes) -> list[str]:
    if len(chunk_blob) < 4:
        return []
    count = struct.unpack_from("<I", chunk_blob, 0)[0]
    expected = 4 + count * 64
    if count == 0 or expected != len(chunk_blob):
        texture_name = parse_material_texture(chunk_blob)
        return [texture_name] if texture_name else []

    textures: list[str] = []
    for index in range(count):
        record_start = 4 + index * 64
        name = read_c_string(chunk_blob[record_start + 28:record_start + 64])
        textures.append(canonical_texture_ref(name) if name else "")
    return textures


def parse_vertex_chunk(chunk_blob: bytes) -> tuple[list[tuple[float, float, float]], list[tuple[float, float]]] | None:
    if len(chunk_blob) < 4:
        return None
    count = struct.unpack_from("<I", chunk_blob, 0)[0]
    expected = 4 + count * 20
    if count == 0 or expected != len(chunk_blob):
        return None

    vertices: list[tuple[float, float, float]] = []
    uvs: list[tuple[float, float]] = []
    offset = 4
    for _ in range(count):
        x, y, z, u, v = struct.unpack_from("<5f", chunk_blob, offset)
        vertices.append(
            (
                sanitize_float(x, MAX_POSITION_ABS),
                sanitize_float(y, MAX_POSITION_ABS),
                sanitize_float(z, MAX_POSITION_ABS),
            )
        )
        uvs.append((sanitize_float(u, MAX_UV_ABS), sanitize_float(v, MAX_UV_ABS)))
        offset += 20
    return vertices, uvs


def triangulate_fan(vertex_count: int) -> list[tuple[int, int, int]]:
    if vertex_count < 3:
        return []
    return [(0, index, index + 1) for index in range(1, vertex_count - 1)]


def _fix_degenerate_uvs(
    u0: float,
    v0: float,
    u1: float,
    v1: float,
    u2: float,
    v2: float,
) -> tuple[float, float, float, float, float, float]:
    epsilon = 1e-3
    uv_area = abs((u1 - u0) * (v2 - v0) - (u2 - u0) * (v1 - v0))
    if uv_area >= 1e-7:
        return u0, v0, u1, v1, u2, v2
    u2 += epsilon
    v2 += epsilon
    uv_area = abs((u1 - u0) * (v2 - v0) - (u2 - u0) * (v1 - v0))
    if uv_area >= 1e-7:
        return u0, v0, u1, v1, u2, v2
    u1 += epsilon
    return u0, v0, u1, v1, u2, v2


def parse_face_chunk(
    chunk_blob: bytes,
    vertex_count: int,
    chunk_index: int,
    chunk_type: int,
    record_size: int = 60,
) -> tuple[
    list[tuple[int, int, int]],
    list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]],
    list[int],
    list[TriangleSource],
]:
    if vertex_count < 3 or len(chunk_blob) < 12:
        return [], [], [], []

    face_count, _, _ = struct.unpack_from("<III", chunk_blob, 0)
    expected = 12 + face_count * record_size
    if face_count == 0 or expected != len(chunk_blob):
        return [], [], [], []

    faces: list[tuple[int, int, int]] = []
    face_uvs: list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]] = []
    face_material_indices: list[int] = []
    triangle_sources: list[TriangleSource] = []

    for record_index in range(face_count):
        record_offset = 12 + record_index * record_size
        primitive_type, i0, i1, i2 = struct.unpack_from("<4I", chunk_blob, record_offset)
        if primitive_type not in (3, 4):
            continue
        if i0 >= vertex_count or i1 >= vertex_count or i2 >= vertex_count:
            continue

        material_index = struct.unpack_from("<I", chunk_blob, record_offset + 20)[0]
        u0, u1, u2, u3, v0, v1, v2, v3 = struct.unpack_from("<8f", chunk_blob, record_offset + 28)
        u0 = sanitize_float(u0, MAX_UV_ABS)
        u1 = sanitize_float(u1, MAX_UV_ABS)
        u2 = sanitize_float(u2, MAX_UV_ABS)
        u3 = sanitize_float(u3, MAX_UV_ABS)
        v0 = sanitize_float(v0, MAX_UV_ABS)
        v1 = sanitize_float(v1, MAX_UV_ABS)
        v2 = sanitize_float(v2, MAX_UV_ABS)
        v3 = sanitize_float(v3, MAX_UV_ABS)

        if primitive_type == 4:
            i3 = struct.unpack_from("<I", chunk_blob, record_offset + 16)[0]
            if i3 >= vertex_count:
                continue

            if i0 != i1 and i1 != i2 and i0 != i2:
                fixed = _fix_degenerate_uvs(u0, v0, u1, v1, u2, v2)
                faces.append((i0, i1, i2))
                face_material_indices.append(material_index)
                face_uvs.append(((fixed[0], fixed[1]), (fixed[2], fixed[3]), (fixed[4], fixed[5])))
                triangle_sources.append(
                    TriangleSource(
                        chunk_index=chunk_index,
                        chunk_type=chunk_type,
                        record_index=record_index,
                        record_size=record_size,
                        primitive_type=primitive_type,
                        triangle_slot=0,
                    )
                )

            if i0 != i2 and i2 != i3 and i0 != i3:
                fixed = _fix_degenerate_uvs(u0, v0, u2, v2, u3, v3)
                faces.append((i0, i2, i3))
                face_material_indices.append(material_index)
                face_uvs.append(((fixed[0], fixed[1]), (fixed[2], fixed[3]), (fixed[4], fixed[5])))
                triangle_sources.append(
                    TriangleSource(
                        chunk_index=chunk_index,
                        chunk_type=chunk_type,
                        record_index=record_index,
                        record_size=record_size,
                        primitive_type=primitive_type,
                        triangle_slot=1,
                    )
                )
            continue

        if i0 == i1 or i1 == i2 or i0 == i2:
            continue
        fixed = _fix_degenerate_uvs(u0, v0, u1, v1, u2, v2)
        faces.append((i0, i1, i2))
        face_material_indices.append(material_index)
        face_uvs.append(((fixed[0], fixed[1]), (fixed[2], fixed[3]), (fixed[4], fixed[5])))
        triangle_sources.append(
            TriangleSource(
                chunk_index=chunk_index,
                chunk_type=chunk_type,
                record_index=record_index,
                record_size=record_size,
                primitive_type=primitive_type,
                triangle_slot=0,
            )
        )

    return faces, face_uvs, face_material_indices, triangle_sources


def vec_sub(a: tuple[float, float, float], b: tuple[float, float, float]) -> tuple[float, float, float]:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def cross(a: tuple[float, float, float], b: tuple[float, float, float]) -> tuple[float, float, float]:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def dot(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def fix_face_winding(
    vertices: list[tuple[float, float, float]],
    faces: list[tuple[int, int, int]],
    face_uvs: list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]],
    triangle_sources: list[TriangleSource],
) -> tuple[
    list[tuple[int, int, int]],
    list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]],
    list[TriangleSource],
]:
    if not faces or len(vertices) < 3:
        return faces, face_uvs, triangle_sources

    centroid = (
        sum(vertex[0] for vertex in vertices) / len(vertices),
        sum(vertex[1] for vertex in vertices) / len(vertices),
        sum(vertex[2] for vertex in vertices) / len(vertices),
    )

    fixed_faces: list[tuple[int, int, int]] = []
    fixed_face_uvs: list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]] = []
    fixed_sources: list[TriangleSource] = []

    for index, face in enumerate(faces):
        i0, i1, i2 = face
        v0, v1, v2 = vertices[i0], vertices[i1], vertices[i2]
        face_normal = cross(vec_sub(v1, v0), vec_sub(v2, v0))
        face_center = (
            (v0[0] + v1[0] + v2[0]) / 3.0,
            (v0[1] + v1[1] + v2[1]) / 3.0,
            (v0[2] + v1[2] + v2[2]) / 3.0,
        )
        to_face = vec_sub(face_center, centroid)
        source = triangle_sources[index] if index < len(triangle_sources) else TriangleSource(-1, -1, -1, 0, 3, 0, False)

        if dot(face_normal, to_face) < 0:
            fixed_faces.append((i0, i2, i1))
            uv0, uv1, uv2 = face_uvs[index]
            fixed_face_uvs.append((uv0, uv2, uv1))
            fixed_sources.append(replace(source, flipped=not source.flipped))
        else:
            fixed_faces.append(face)
            fixed_face_uvs.append(face_uvs[index])
            fixed_sources.append(source)

    return fixed_faces, fixed_face_uvs, fixed_sources


def parse_msh(filepath: str | Path) -> ParsedMsh:
    path = Path(filepath)
    data = path.read_bytes()
    version, chunks = read_chunks(data)
    counts = Counter(classify_chunk(chunk.chunk_type) for chunk in chunks)
    warnings: list[str] = []
    parts: list[MeshPart] = []

    bone_transforms = build_bone_transforms(data, chunks)
    bone_names = build_bone_name_map(data, chunks)

    for index, chunk in enumerate(chunks):
        if chunk.chunk_type != MESH_CHUNK_VERTEX:
            continue

        parsed_vertex = parse_vertex_chunk(data[chunk.offset:chunk.offset + chunk.size])
        if not parsed_vertex:
            continue
        vertices, uvs = parsed_vertex
        if len(vertices) < 1:
            continue

        world_matrix = None
        world_translation = (0.0, 0.0, 0.0)
        if chunk.index in bone_transforms:
            world_matrix, world_translation = bone_transforms[chunk.index]
            vertices = [
                (
                    sanitize_float(world_matrix[0][0] * x + world_matrix[0][1] * y + world_matrix[0][2] * z + world_translation[0], MAX_POSITION_ABS),
                    sanitize_float(world_matrix[1][0] * x + world_matrix[1][1] * y + world_matrix[1][2] * z + world_translation[1], MAX_POSITION_ABS),
                    sanitize_float(world_matrix[2][0] * x + world_matrix[2][1] * y + world_matrix[2][2] * z + world_translation[2], MAX_POSITION_ABS),
                )
                for x, y, z in vertices
            ]

        part_name = f"vertex_chunk_{chunk.index}"
        if index > 0 and chunks[index - 1].chunk_type == NAME_CHUNK:
            previous = chunks[index - 1]
            value = read_c_string(data[previous.offset:previous.offset + previous.size])
            if value:
                part_name = value
        elif chunk.index in bone_names:
            part_name = bone_names[chunk.index]

        material_textures: list[str] = []
        faces: list[tuple[int, int, int]] = []
        face_uvs: list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]] = []
        face_material_indices: list[int] = []
        triangle_sources: list[TriangleSource] = []
        face_chunk_index = None
        face_chunk_type = None
        had_face_chunk = False

        search_limit = min(len(chunks), index + 6)
        for search_index in range(index + 1, search_limit):
            search_chunk = chunks[search_index]
            if search_chunk.chunk_type == MESH_CHUNK_VERTEX:
                break
            if search_chunk.chunk_type in (MESH_CHUNK_FACES, MESH_CHUNK_FACES_EXT):
                had_face_chunk = True
                face_chunk_index = search_chunk.index
                face_chunk_type = search_chunk.chunk_type
                record_size = 132 if search_chunk.chunk_type == MESH_CHUNK_FACES_EXT else 60
                faces, face_uvs, face_material_indices, triangle_sources = parse_face_chunk(
                    data[search_chunk.offset:search_chunk.offset + search_chunk.size],
                    len(vertices),
                    chunk_index=search_chunk.index,
                    chunk_type=search_chunk.chunk_type,
                    record_size=record_size,
                )
            if search_chunk.chunk_type == MESH_CHUNK_MATERIAL and not material_textures:
                material_textures = parse_material_textures(data[search_chunk.offset:search_chunk.offset + search_chunk.size])

        if not faces:
            if had_face_chunk:
                continue
            faces = triangulate_fan(len(vertices))
            face_uvs = [(uvs[i0], uvs[i1], uvs[i2]) for i0, i1, i2 in faces]
            face_material_indices = [0] * len(faces)
            triangle_sources = [TriangleSource(-1, -1, -1, 0, 3, 0, False) for _ in faces]

        faces, face_uvs, triangle_sources = fix_face_winding(vertices, faces, face_uvs, triangle_sources)

        parts.append(
            MeshPart(
                name=part_name,
                vertex_chunk_index=chunk.index,
                vertex_chunk_offset=chunk.offset,
                vertex_chunk_size=chunk.size,
                vertices=vertices,
                uvs=uvs,
                faces=faces,
                face_uvs=face_uvs,
                face_material_indices=face_material_indices,
                material_textures=material_textures,
                world_matrix=world_matrix,
                world_translation=world_translation,
                triangle_sources=triangle_sources,
                face_chunk_index=face_chunk_index,
                face_chunk_type=face_chunk_type,
            )
        )

    if counts.get("vertex", 0) == 0:
        warnings.append("No vertex chunks were found")
    if counts.get("faces", 0) == 0 and counts.get("faces_ext", 0) == 0:
        warnings.append("No explicit face chunks were found; some assets may need fallback triangulation")

    return ParsedMsh(
        path=path,
        version=version,
        chunks=chunks,
        chunk_type_counts=dict(sorted(counts.items())),
        named_vertex_chunks=[part.name for part in parts],
        parts=parts,
        warnings=warnings,
        bones=build_parsed_bones(data, chunks),
    )
