"""Import a 10six ``.anm`` file as a Blender Action on the given armature.

Approach
--------
For each keyframe ``i`` (i = 0..N-1) and each per-bone transform we set the
pose bone's *local* matrix equal to the recorded local rotation matrix, plus
the recorded translation delta added to the bone's parsed pivot. We then
``keyframe_insert`` ``location`` and ``rotation_quaternion`` at integer frame
``i + 1`` (Blender frames are 1-indexed conventionally).

This mirrors the export path in ``foreign_export._build_animation_sequences``
which records ``rotation = local_pose_matrix.to_3x3()`` and
``translation = local_pose_matrix.translation - bind_pivot``.

Note on byte-perfect re-export: round-tripping through Blender's pose-bone /
quaternion representation introduces float rounding; this importer aims for
*structural* fidelity (same bone count, frame count, transforms within float
tolerance), not byte-perfect re-export. Achieving byte-perfect output may
require storing the raw transforms in a custom data block and bypassing the
pose-bone evaluation on export — punted for now.
"""
from __future__ import annotations

from pathlib import Path

import bpy
from mathutils import Matrix, Vector

from .anm_parser import AnmFile, parse_anm


def _matrix3_to_4x4(rotation: list[list[float]], translation: tuple[float, float, float]) -> Matrix:
    return Matrix((
        (rotation[0][0], rotation[0][1], rotation[0][2], translation[0]),
        (rotation[1][0], rotation[1][1], rotation[1][2], translation[1]),
        (rotation[2][0], rotation[2][1], rotation[2][2], translation[2]),
        (0.0, 0.0, 0.0, 1.0),
    ))


def _seq_to_pose_bone_map(armature_obj) -> dict[int, bpy.types.PoseBone]:
    mapping: dict[int, bpy.types.PoseBone] = {}
    for pose_bone in armature_obj.pose.bones:
        seq = pose_bone.get("tensix_seq_idx")
        if seq is None:
            continue
        mapping[int(seq)] = pose_bone
    return mapping


def _seq_to_pivot(armature_obj) -> dict[int, tuple[float, float, float]]:
    pivots: dict[int, tuple[float, float, float]] = {}
    for pose_bone in armature_obj.pose.bones:
        seq = pose_bone.get("tensix_seq_idx")
        pivot = pose_bone.get("tensix_pivot")
        if seq is None or pivot is None:
            continue
        pivots[int(seq)] = (float(pivot[0]), float(pivot[1]), float(pivot[2]))
    return pivots


def _extend_armature_with_synthetic_bones(armature_obj, missing_seq_indices: set[int]) -> dict[int, str]:
    """Add placeholder edit bones for ``missing_seq_indices`` so that an
    external-skeleton .anm can still drive a complete Action.

    Synthetic bones sit at the armature origin with a unit Z tail and have
    no parent. They are tagged ``tensix_seq_idx`` and ``tensix_synthetic`` so
    downstream tooling (and re-export) can treat them like normal tagged
    bones. Returns a {seq_idx: bone_name} mapping for the new bones.
    """
    if not missing_seq_indices:
        return {}

    view_layer = bpy.context.view_layer
    previous_active = view_layer.objects.active
    view_layer.objects.active = armature_obj
    previous_mode = armature_obj.mode if armature_obj.mode else "OBJECT"
    bpy.ops.object.mode_set(mode="EDIT")
    new_names: dict[int, str] = {}
    try:
        existing = {bone.name for bone in armature_obj.data.edit_bones}
        for seq in sorted(missing_seq_indices):
            base = f"__anm_bone_{seq}"
            name = base
            counter = 1
            while name in existing:
                name = f"{base}_{counter}"
                counter += 1
            existing.add(name)
            edit_bone = armature_obj.data.edit_bones.new(name)
            edit_bone.head = (0.0, 0.0, 0.0)
            edit_bone.tail = (0.0, 0.0, 1.0)
            new_names[seq] = name
    finally:
        bpy.ops.object.mode_set(mode=previous_mode)
        view_layer.objects.active = previous_active

    # Tag the matching pose bones (only available outside EDIT mode).
    for seq, name in new_names.items():
        pose_bone = armature_obj.pose.bones.get(name)
        if pose_bone is None:
            continue
        pose_bone["tensix_seq_idx"] = seq
        pose_bone["tensix_synthetic"] = True
        pose_bone["tensix_pivot"] = (0.0, 0.0, 0.0)
        pose_bone["tensix_local_matrix"] = [
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
        ]

    seq_to_name = dict(armature_obj.get("tensix_bone_seq_to_name", {}) or {})
    for seq, name in new_names.items():
        seq_to_name[str(seq)] = name
    armature_obj["tensix_bone_seq_to_name"] = seq_to_name
    return new_names


def import_anm_to_action(
    armature_obj,
    anm_path: str | Path,
    *,
    action_name: str | None = None,
    activate: bool = True,
    extend_armature: bool = True,
    report=None,
) -> tuple[bpy.types.Action | None, AnmFile]:
    """Parse ``anm_path`` and build a Blender Action on ``armature_obj``.

    When ``extend_armature`` is True (default), bone indices referenced by the
    .anm but missing from the armature trigger creation of synthetic
    placeholder bones at the armature origin so that no animation data is
    silently dropped (common case: external/shared skeleton anims).

    ``report`` is an optional Blender-style callback ``(set, str)`` used to
    emit a WARNING when synthetic bones are added or transforms dropped.

    Returns ``(action, parsed_anm)`` — ``action`` is ``None`` only if the
    parsed file has no keyframes.
    """
    anm = parse_anm(anm_path)
    if not anm.keyframes:
        return None, anm

    name = action_name or Path(anm_path).stem
    action = bpy.data.actions.get(name) or bpy.data.actions.new(name=name)
    if armature_obj.animation_data is None:
        armature_obj.animation_data_create()
    if activate:
        armature_obj.animation_data.action = action

    seq_map = _seq_to_pose_bone_map(armature_obj)
    referenced: set[int] = {
        transform.bone_index
        for keyframe in anm.keyframes
        for transform in keyframe.bone_transforms
    }
    missing = sorted(seq for seq in referenced if seq not in seq_map)
    synthetic_added: dict[int, str] = {}
    if missing and extend_armature:
        synthetic_added = _extend_armature_with_synthetic_bones(armature_obj, set(missing))
        if synthetic_added and report is not None:
            report(
                {"WARNING"},
                f"{Path(anm_path).name}: armature missing {len(synthetic_added)} bone(s) "
                f"referenced by .anm (indices {sorted(synthetic_added)}); added synthetic "
                f"placeholder bones at origin (likely external/shared skeleton).",
            )
        # Re-read the seq map so the new bones are picked up.
        seq_map = _seq_to_pose_bone_map(armature_obj)

    pivots = _seq_to_pivot(armature_obj)

    dropped: dict[int, int] = {}

    # Switch to pose mode so keyframe_insert works on pose-bone props.
    view_layer = bpy.context.view_layer
    previous_active = view_layer.objects.active
    view_layer.objects.active = armature_obj
    bpy.ops.object.mode_set(mode="POSE")
    try:
        for kf_index, keyframe in enumerate(anm.keyframes):
            frame_number = kf_index + 1
            bpy.context.scene.frame_set(frame_number)
            for transform in keyframe.bone_transforms:
                pose_bone = seq_map.get(transform.bone_index)
                if pose_bone is None:
                    dropped[transform.bone_index] = dropped.get(transform.bone_index, 0) + 1
                    continue
                pivot = pivots.get(transform.bone_index, (0.0, 0.0, 0.0))
                local_translation = (
                    transform.translation[0] + pivot[0],
                    transform.translation[1] + pivot[1],
                    transform.translation[2] + pivot[2],
                )
                local_matrix = _matrix3_to_4x4(transform.rotation, local_translation)
                if pose_bone.parent is not None:
                    pose_bone.matrix = pose_bone.parent.matrix @ local_matrix
                else:
                    pose_bone.matrix = local_matrix
                pose_bone.keyframe_insert("location", frame=frame_number)
                pose_bone.keyframe_insert("rotation_quaternion", frame=frame_number)
                pose_bone.keyframe_insert("scale", frame=frame_number)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        view_layer.objects.active = previous_active

    if dropped and report is not None:
        total = sum(dropped.values())
        report(
            {"WARNING"},
            f"{Path(anm_path).name}: dropped {total} bone-transform keyframe(s) "
            f"for unmapped bone indices {sorted(dropped)} (extend_armature disabled).",
        )

    action["tensix_source_anm"] = str(anm_path)
    action["tensix_keyframe_count"] = len(anm.keyframes)
    if synthetic_added:
        action["tensix_synthetic_bones_added"] = sorted(synthetic_added)
    if dropped:
        action["tensix_dropped_bone_indices"] = sorted(dropped)
    return action, anm
