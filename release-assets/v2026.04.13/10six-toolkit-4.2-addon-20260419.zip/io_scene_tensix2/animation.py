from __future__ import annotations


def collect_animation_notes(parsed) -> list[str]:
    notes: list[str] = []
    if parsed.chunk_type_counts.get("bone", 0):
        notes.append("Bone chunks detected; armature will be built on import")
    return notes
