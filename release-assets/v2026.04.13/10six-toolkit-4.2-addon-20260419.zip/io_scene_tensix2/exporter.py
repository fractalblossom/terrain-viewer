from __future__ import annotations

import struct
from pathlib import Path

from mathutils import Vector

from .foreign_export import _generate_smsh_sidecar, export_foreign_msh
from .parser import MeshPart, ParsedMsh, TriangleSource
from .validation import find_asset_root, validate_roundtrip_root, write_validation_text


def _invert_3x3(matrix: list[list[float]]) -> list[list[float]]:
    a00, a01, a02 = matrix[0]
    a10, a11, a12 = matrix[1]
    a20, a21, a22 = matrix[2]
    det = (
        a00 * (a11 * a22 - a12 * a21)
        - a01 * (a10 * a22 - a12 * a20)
        + a02 * (a10 * a21 - a11 * a20)
    )
    if abs(det) < 1e-8:
        raise ValueError("Encountered a non-invertible 10six part transform")
    inv_det = 1.0 / det
    return [
        [+(a11 * a22 - a12 * a21) * inv_det, -(a01 * a22 - a02 * a21) * inv_det, +(a01 * a12 - a02 * a11) * inv_det],
        [-(a10 * a22 - a12 * a20) * inv_det, +(a00 * a22 - a02 * a20) * inv_det, -(a00 * a12 - a02 * a10) * inv_det],
        [+(a10 * a21 - a11 * a20) * inv_det, -(a00 * a21 - a01 * a20) * inv_det, +(a00 * a11 - a01 * a10) * inv_det],
    ]


def _apply_matrix(matrix: list[list[float]], vector: tuple[float, float, float]) -> tuple[float, float, float]:
    return (
        matrix[0][0] * vector[0] + matrix[0][1] * vector[1] + matrix[0][2] * vector[2],
        matrix[1][0] * vector[0] + matrix[1][1] * vector[1] + matrix[1][2] * vector[2],
        matrix[2][0] * vector[0] + matrix[2][1] * vector[1] + matrix[2][2] * vector[2],
    )


def _chunk_map(parsed: ParsedMsh):
    return {chunk.index: chunk for chunk in parsed.chunks}


def _asset_space_matrix(root, obj):
    return root.matrix_world.inverted() @ obj.matrix_world


def _extract_vertex_uvs(mesh) -> list[tuple[float, float]]:
    vertex_uvs = [(0.0, 0.0) for _ in mesh.vertices]
    if not mesh.uv_layers:
        return vertex_uvs
    uv_layer = mesh.uv_layers.active.data
    assigned: set[int] = set()
    for polygon in mesh.polygons:
        for loop_index in polygon.loop_indices:
            vertex_index = mesh.loops[loop_index].vertex_index
            if vertex_index in assigned:
                continue
            uv = uv_layer[loop_index].uv
            vertex_uvs[vertex_index] = (float(uv.x), float(uv.y))
            assigned.add(vertex_index)
    return vertex_uvs


def _triangle_uvs(mesh) -> list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]]:
    uv_layer = mesh.uv_layers.active.data
    triangles = []
    for polygon in mesh.polygons:
        triangles.append(
            tuple(
                (float(uv_layer[polygon.loop_start + loop_offset].uv.x), float(uv_layer[polygon.loop_start + loop_offset].uv.y))
                for loop_offset in range(3)
            )
        )
    return triangles


def _mesh_world_vertices(root, obj, part: MeshPart) -> list[tuple[float, float, float]]:
    if obj.type == "EMPTY":
        current_centroid = _asset_space_matrix(root, obj).translation
        original_centroid = Vector((
            sum(vertex[0] for vertex in part.vertices) / len(part.vertices),
            sum(vertex[1] for vertex in part.vertices) / len(part.vertices),
            sum(vertex[2] for vertex in part.vertices) / len(part.vertices),
        ))
        delta = current_centroid - original_centroid
        return [(vertex[0] + delta.x, vertex[1] + delta.y, vertex[2] + delta.z) for vertex in part.vertices]

    asset_matrix = _asset_space_matrix(root, obj)
    return [
        tuple(float(value) for value in (asset_matrix @ vertex.co.to_4d()).xyz)
        for vertex in obj.data.vertices
    ]


def _localize_vertices(world_vertices, part: MeshPart) -> list[tuple[float, float, float]]:
    if part.world_matrix is None:
        return world_vertices
    inverse = _invert_3x3(part.world_matrix)
    tx, ty, tz = part.world_translation
    localized = []
    for x, y, z in world_vertices:
        localized.append(_apply_matrix(inverse, (x - tx, y - ty, z - tz)))
    return localized


def _write_vertex_chunk(data: bytearray, part: MeshPart, local_vertices, vertex_uvs) -> None:
    if part.vertex_chunk_size < 4 + len(local_vertices) * 20:
        raise ValueError(f"Vertex chunk for {part.name} is smaller than expected")
    for index, (vertex, uv) in enumerate(zip(local_vertices, vertex_uvs)):
        offset = part.vertex_chunk_offset + 4 + index * 20
        struct.pack_into("<5f", data, offset, vertex[0], vertex[1], vertex[2], uv[0], uv[1])


def _reordered_triangle_uvs(triangle_uvs, source: TriangleSource):
    if source.flipped:
        return triangle_uvs[0], triangle_uvs[2], triangle_uvs[1]
    return triangle_uvs


def _write_face_chunks(data: bytearray, parsed: ParsedMsh, part: MeshPart, current_triangle_uvs) -> None:
    chunk_map = _chunk_map(parsed)
    quad_states: dict[tuple[int, int], dict[str, list[float | None]]] = {}

    for triangle_index, source in enumerate(part.triangle_sources):
        if source.chunk_index < 0 or triangle_index >= len(current_triangle_uvs):
            continue
        chunk = chunk_map.get(source.chunk_index)
        if chunk is None:
            continue

        ordered = _reordered_triangle_uvs(current_triangle_uvs[triangle_index], source)
        record_offset = chunk.offset + 12 + source.record_index * source.record_size

        if source.primitive_type == 3:
            existing = list(struct.unpack_from("<8f", data, record_offset + 28))
            existing[0], existing[1], existing[2] = ordered[0][0], ordered[1][0], ordered[2][0]
            existing[4], existing[5], existing[6] = ordered[0][1], ordered[1][1], ordered[2][1]
            struct.pack_into("<8f", data, record_offset + 28, *existing)
            continue

        key = (source.chunk_index, source.record_index)
        if key not in quad_states:
            existing = list(struct.unpack_from("<8f", data, record_offset + 28))
            quad_states[key] = {
                "u": [existing[0], existing[1], existing[2], existing[3]],
                "v": [existing[4], existing[5], existing[6], existing[7]],
            }

        state = quad_states[key]
        if source.triangle_slot == 0:
            state["u"][0], state["u"][1], state["u"][2] = ordered[0][0], ordered[1][0], ordered[2][0]
            state["v"][0], state["v"][1], state["v"][2] = ordered[0][1], ordered[1][1], ordered[2][1]
        else:
            state["u"][0], state["u"][2], state["u"][3] = ordered[0][0], ordered[1][0], ordered[2][0]
            state["v"][0], state["v"][2], state["v"][3] = ordered[0][1], ordered[1][1], ordered[2][1]

    for (chunk_index, record_index), state in quad_states.items():
        chunk = chunk_map[chunk_index]
        source = next(item for item in part.triangle_sources if item.chunk_index == chunk_index and item.record_index == record_index)
        record_offset = chunk.offset + 12 + record_index * source.record_size
        values = [state["u"][0], state["u"][1], state["u"][2], state["u"][3], state["v"][0], state["v"][1], state["v"][2], state["v"][3]]
        struct.pack_into("<8f", data, record_offset + 28, *values)


def export_roundtrip_msh(context, filepath: str, report, export_mode: str = "ROUND_TRIP"):
    active = context.active_object
    if active is None:
        report({"ERROR"}, "No active object selected")
        return {"CANCELLED"}

    root = find_asset_root(active)
    if root is None:
        report({"ERROR"}, "Active object is not part of an imported 10six asset")
        return {"CANCELLED"}

    if export_mode != "ROUND_TRIP":
        report({"ERROR"}, "Foreign asset conversion mode is not implemented yet; use round-trip mode")
        return {"CANCELLED"}

    validation, parsed = validate_roundtrip_root(root)
    write_validation_text(validation)
    if validation.errors or parsed is None:
        report({"ERROR"}, "10six export blocked by validation errors; see 10six_validation_report.txt")
        return {"CANCELLED"}

    source_path = Path(validation.source_path)
    output_path = Path(filepath)
    data = bytearray(source_path.read_bytes())
    part_map = {part.vertex_chunk_index: part for part in parsed.parts}

    asset_objects = []
    stack = [root]
    while stack:
        current = stack.pop()
        asset_objects.append(current)
        stack.extend(list(current.children))

    for obj in asset_objects:
        vertex_chunk_index = obj.get("tensix_vertex_chunk_index")
        if vertex_chunk_index is None or int(vertex_chunk_index) not in part_map:
            continue
        part = part_map[int(vertex_chunk_index)]
        world_vertices = _mesh_world_vertices(root, obj, part)
        local_vertices = _localize_vertices(world_vertices, part)

        if obj.type == "MESH":
            vertex_uvs = _extract_vertex_uvs(obj.data)
            triangle_uvs = _triangle_uvs(obj.data)
        else:
            vertex_uvs = list(part.uvs)
            triangle_uvs = list(part.face_uvs)

        _write_vertex_chunk(data, part, local_vertices, vertex_uvs)
        _write_face_chunks(data, parsed, part, triangle_uvs)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(data)
    smsh_path = _generate_smsh_sidecar(output_path, model_type="Generic Model", report=report)
    if smsh_path is not None:
        report({"INFO"}, f"Generated companion .smsh: {smsh_path}")
    report({"INFO"}, f"Exported 10six round-trip asset to {output_path}")
    return {"FINISHED"}


def export_tensix_msh(
    context,
    filepath: str,
    report,
    export_mode: str = "ROUND_TRIP",
    texture_size: int = 512,
    emit_reports: bool = True,
    scale: float = 1.0,
):
    if export_mode == "FOREIGN":
        return export_foreign_msh(
            context=context,
            filepath=filepath,
            report=report,
            texture_size=texture_size,
            emit_reports=emit_reports,
            scale=scale,
        )
    return export_roundtrip_msh(context=context, filepath=filepath, report=report, export_mode=export_mode)