#!/usr/bin/env bash
set -euo pipefail

BLENDER_VERSION="5.1"
ADDON_ZIP="../io_scene_tensix2.zip"
ADDON_FOLDER="../io_scene_tensix2"
STARTUP_HELPER_SCRIPT="./tensix_first_run_startup.py"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --blender-version)
            BLENDER_VERSION="$2"
            shift 2
            ;;
        --addon-zip)
            ADDON_ZIP="$2"
            shift 2
            ;;
        --addon-folder)
            ADDON_FOLDER="$2"
            shift 2
            ;;
        --startup-helper-script)
            STARTUP_HELPER_SCRIPT="$2"
            shift 2
            ;;
        *)
            echo "Unknown argument: $1" >&2
            exit 1
            ;;
    esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

resolve_installer_path() {
    local candidate="$1"
    if [[ "$candidate" = /* ]]; then
        printf '%s\n' "$candidate"
    else
        printf '%s\n' "$SCRIPT_DIR/${candidate#./}"
    fi
}

USER_CONFIG_ROOT="${XDG_CONFIG_HOME:-$HOME/.config}"
USER_SCRIPTS_ROOT="$USER_CONFIG_ROOT/blender/$BLENDER_VERSION/scripts"
USER_ADDONS_ROOT="$USER_SCRIPTS_ROOT/addons"
USER_STARTUP_ROOT="$USER_SCRIPTS_ROOT/startup"
TARGET_ADDON="$USER_ADDONS_ROOT/io_scene_tensix2"
TARGET_STARTUP_SCRIPT="$USER_STARTUP_ROOT/tensix_first_run_startup.py"

mkdir -p "$USER_ADDONS_ROOT" "$USER_STARTUP_ROOT"

RESOLVED_ADDON_ZIP="$(resolve_installer_path "$ADDON_ZIP")"
RESOLVED_ADDON_FOLDER="$(resolve_installer_path "$ADDON_FOLDER")"
RESOLVED_STARTUP_HELPER_SCRIPT="$(resolve_installer_path "$STARTUP_HELPER_SCRIPT")"

rm -rf "$TARGET_ADDON"

if [[ -d "$RESOLVED_ADDON_FOLDER" ]]; then
    cp -R "$RESOLVED_ADDON_FOLDER" "$TARGET_ADDON"
    echo "Installed io_scene_tensix2 from folder into $TARGET_ADDON"
elif [[ -f "$RESOLVED_ADDON_ZIP" ]]; then
    if command -v unzip >/dev/null 2>&1; then
        unzip -oq "$RESOLVED_ADDON_ZIP" -d "$USER_ADDONS_ROOT"
    elif command -v python3 >/dev/null 2>&1; then
        python3 - <<'PY' "$RESOLVED_ADDON_ZIP" "$USER_ADDONS_ROOT"
import sys
import zipfile

zip_path = sys.argv[1]
destination = sys.argv[2]
with zipfile.ZipFile(zip_path) as archive:
    archive.extractall(destination)
PY
    else
        echo "Could not find unzip or python3 to extract $RESOLVED_ADDON_ZIP" >&2
        exit 1
    fi
    echo "Installed io_scene_tensix2 from zip into $USER_ADDONS_ROOT"
else
    echo "Could not find io_scene_tensix2 folder or zip next to this installer. Use the extracted bundle root that contains io_scene_tensix2 and support/." >&2
    exit 1
fi

if [[ -f "$RESOLVED_STARTUP_HELPER_SCRIPT" ]]; then
    cp "$RESOLVED_STARTUP_HELPER_SCRIPT" "$TARGET_STARTUP_SCRIPT"
    echo "Installed first-run startup helper into $TARGET_STARTUP_SCRIPT"
fi

echo "Next steps for the artist:"
echo "1. Launch Blender $BLENDER_VERSION"
echo "2. The first-run helper will try to enable '10six Toolkit 4.0' and create a quick-start text block"
echo "3. Open the 10six panel"
echo "4. Set 10six Data Root to the parent folder containing your original 10six data folders"