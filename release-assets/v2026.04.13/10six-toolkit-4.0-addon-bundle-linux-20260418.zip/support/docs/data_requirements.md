# Data Requirements

## Required User-Owned Data

This toolkit expects the user to supply their own legally obtained 10six data.

Minimum expectation:

- a local folder containing one of the original numbered 10six data-pack layouts recognized by the addon

Example shape:

```text
10six_data/
  visitor0/
  visitor1/
  visitor2/
  ...
```

Alternative accepted shape:

```text
10six_data/
  <other original numbered data-pack folders>/
  ...
```

## What The Toolkit Uses

- `.msh` files for mesh import and round-trip export
- texture files from the original data tree, typically under the `files/bmp` folder inside one of the original data packs
- optional `.smsh` sidecars when present and discoverable

## What Foreign Export Expects From Artist Authored Assets

- one rooted hierarchy per exported asset
- valid UVs on every renderable mesh
- practical diffuse material inputs, ideally image-backed
- unique source texture basenames when multiple texture files are involved

## What Foreign Export Writes

- exported `.msh`
- `.textures.json` manifest
- sibling texture output folder
- for supported rigid armature-driven assets, `.anm` and `.animation_report.json`

## What The Toolkit Does Not Bundle

- original art assets
- original game installers
- decoded source payloads from this workspace

## Why

The toolkit is intended to distribute tooling, not game content.