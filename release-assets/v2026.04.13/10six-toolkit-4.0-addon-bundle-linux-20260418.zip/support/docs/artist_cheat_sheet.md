# Artist Cheat Sheet

## Install

If you already have Blender:

1. In Blender, open `Edit > Preferences > Add-ons`.
2. Click `Install from Disk`.
3. Select `io_scene_tensix2.zip`.
4. Enable `10six Toolkit 4.0`.

Do not point `Install from Disk` at the unpacked `io_scene_tensix2` folder or its `__init__.py` file.

If you want to use the unpacked folder, copy only the inner `io_scene_tensix2` folder into Blender's user `addons` directory or use the included install script instead.

Do not copy the extracted addon bundle folder itself into Blender's `addons` directory. The bundle is a container that includes `io_scene_tensix2`, `support`, and docs; Blender should see `io_scene_tensix2` directly.

Windows shortcut option:

1. From the extracted bundle root, double-click `support/install_me_first.bat`.
2. Launch Blender.
3. Enable `10six Toolkit 4.0` if Blender does not enable it automatically.

Linux shortcut option:

1. From the extracted bundle root, run `chmod +x support/install_me_first_linux.sh`.
2. From the extracted bundle root, run `./support/install_me_first_linux.sh`.
3. Launch Blender.
4. Enable `10six Toolkit 4.0` if Blender does not enable it automatically.

## First Run

1. Open the 3D View.
2. Press `N` to open the right sidebar.
3. Open the `10six` tab.
4. Set `10six Data Root` to the parent folder that contains your original 10six data folders.

Fast setup option:

1. Click `Detect Data Root From .msh`.
2. Pick any original 10six `.msh` file.

## Import

1. Choose `File > Import > 10six Mesh`.
2. Pick a `.msh` file from your original 10six data.
3. Wait for Blender to build the asset.

## See Textures

1. In the 3D View, look at the top-right corner.
2. Click the third sphere icon.
3. That mode is `Material Preview`.

If the mesh is still gray:

1. Confirm `10six Data Root` is correct.
2. Re-import the mesh.

## View The Whole Model

1. Select the model.
2. Press `Numpad .` to frame it.
3. Hold middle mouse and drag to orbit.
4. Use the mouse wheel to zoom.
5. Use `Shift` plus middle mouse to pan.

## Validate And Export

1. Select the imported asset.
2. Open the `10six` panel.
3. Click `Validate Active Asset`.
4. If validation passes, choose `File > Export > 10six Mesh`.
5. Test the exported `.msh` in-game.

## Foreign Export

1. Import your `.blend`, `.fbx`, `.obj`, or `.dae` with Blender's built-in importers.
2. Build one rooted export hierarchy. Use either a single top-level mesh or parent the selected meshes under one Empty root.
3. Make sure every renderable mesh has valid UVs.
4. Prefer image-backed diffuse materials. If the source material is procedural, inspect the baked diffuse result after export.
5. Select the target mesh root, the Empty root, or the source rigid armature root.
6. In the `10six` panel, set `Export Mode` to `Foreign Asset Conversion`.
7. Click `Export 10six Mesh`.
8. The addon writes `.msh`, `.textures.json`, and exported texture bitmaps next to the output file.
9. Texture references prefer the source texture basename, like the old Max pipeline. Rename source textures if two different files collapse to the same basename.
10. If the asset is a rigid armature-driven model, the addon also writes `.anm` plus `.animation_report.json`.
11. Re-exporting to the same location replaces the previous texture folder and `.anm` outputs for that asset.
12. Test the asset in-game.

## Current Limits

- keep the imported topology unchanged
- do not add or remove faces for round-trip export
- do not change material slot layout
- UV edits are supported better than broad material rewrites
- foreign export routes static meshes and rigid bone-parented armature assets through the legacy-style `.msh` writer
- foreign export writes baked diffuse BMP textures for procedural and node-based materials
- resolve duplicate source texture basenames before export
- weighted skinned export is still not the primary supported path; the current skeletal path targets rigid bone-parented assets