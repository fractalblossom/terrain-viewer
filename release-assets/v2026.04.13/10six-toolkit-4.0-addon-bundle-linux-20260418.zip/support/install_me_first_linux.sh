#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

chmod +x "$SCRIPT_DIR/install_into_user_blender_linux.sh"
"$SCRIPT_DIR/install_into_user_blender_linux.sh"

echo
echo "10six install completed."
echo "Launch Blender next."