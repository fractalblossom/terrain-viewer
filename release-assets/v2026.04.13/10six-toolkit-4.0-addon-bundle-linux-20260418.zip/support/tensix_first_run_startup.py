import addon_utils
import bpy


TEXT_NAME = "10six_Quick_Start"


def ensure_addon_enabled() -> None:
    addon_utils.modules_refresh()
    loaded_default, loaded_state = addon_utils.check("io_scene_tensix2")
    if loaded_default or loaded_state:
        return
    try:
        addon_utils.enable("io_scene_tensix2", default_set=True, persistent=True)
    except Exception as exc:
        print(f"10six first-run helper could not enable io_scene_tensix2: {exc}")


def ensure_quick_start_text() -> None:
    text_block = bpy.data.texts.get(TEXT_NAME)
    if text_block is None:
        text_block = bpy.data.texts.new(TEXT_NAME)
        text_block.write(
            "10six Quick Start\n"
            "\n"
            "1. Open the 3D View sidebar with N.\n"
            "2. Open the 10six tab.\n"
            "3. Set 10six Data Root to the parent folder that contains your original 10six data folders.\n"
            "4. Or use Detect Data Root From .msh and pick an original 10six .msh file.\n"
            "5. Import with File > Import > 10six Mesh.\n"
            "6. Use Material Preview to see textures.\n"
            "7. Validate before export.\n"
            "8. For foreign assets, build one rooted hierarchy and switch Export Mode to Foreign Asset Conversion.\n"
        )


def _deferred_setup() -> None:
    ensure_addon_enabled()
    ensure_quick_start_text()
    return None


def register() -> None:
    bpy.app.timers.register(_deferred_setup, first_interval=0.25, persistent=True)


def unregister() -> None:
    pass


if __name__ == "__main__":
    register()