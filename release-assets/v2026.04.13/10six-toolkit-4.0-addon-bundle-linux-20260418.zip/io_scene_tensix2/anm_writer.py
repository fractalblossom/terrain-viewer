from __future__ import annotations

import struct
from dataclasses import dataclass


MAGIC = 0x1234ABCD
VERSION = 8

ANM_CHUNK_KEYFRAME_INDEX = 0x00020001
ANM_CHUNK_KEYFRAME_META = 0x00020003
ANM_CHUNK_BONE_TRANSFORM = 0x00020004


@dataclass
class AnimBoneTransform:
    bone_index: int
    rotation: list[list[float]]
    translation: tuple[float, float, float]


@dataclass
class AnimSequence:
    name: str
    frame_times: list[int]
    keyframes: list[list[AnimBoneTransform]]


def _pack_bone_transform(transform: AnimBoneTransform) -> bytes:
    flat_rotation = [transform.rotation[row][col] for row in range(3) for col in range(3)]
    values = [
        int(transform.bone_index),
        0,
        *[float(value) for value in flat_rotation],
        float(transform.translation[0]),
        float(transform.translation[1]),
        float(transform.translation[2]),
    ]
    return struct.pack("<II12f", *values)


def build_anm(sequence: AnimSequence) -> bytes:
    """Serialise an animation sequence in 10six ``.anm`` container format.

    Layout (see ``anm_parser`` for the full spec):
      * Container header — ``magic, version, entry_count+1, entry_count, 0, 1, 0, 0``
      * Chunk table of 12-byte ``(type, offset, size)`` entries.
      * Chunks: KF_IDX, then for each keyframe N BONE transforms followed by
        one META chunk. KF_IDX stores ``count + (count+1) * u32`` where
        ``entries[0] = 0`` and ``entries[i]`` is the 1-based chunk index of
        the i-th META chunk.
    """
    if not sequence.frame_times or not sequence.keyframes:
        raise ValueError("Animation sequence has no keyframes")
    if len(sequence.frame_times) != len(sequence.keyframes):
        raise ValueError("Animation frame time count does not match keyframe count")

    # Build BONE + META chunks first, tracking META 1-based indices so KF_IDX
    # can be emitted as the very first chunk while still pointing to them.
    chunks: list[tuple[int, bytes]] = []
    # Placeholder for KF_IDX at chunk index 0.
    chunks.append((ANM_CHUNK_KEYFRAME_INDEX, b""))
    meta_chunk_1based_indices: list[int] = []
    for keyframe in sequence.keyframes:
        if not keyframe:
            raise ValueError("Animation keyframe has no bone transforms")
        referenced_chunks: list[int] = []
        for transform in keyframe:
            chunk_index = len(chunks)
            chunks.append((ANM_CHUNK_BONE_TRANSFORM, _pack_bone_transform(transform)))
            referenced_chunks.append(chunk_index + 1)
        meta_blob = bytearray(struct.pack("<I", len(keyframe)))
        for reference in referenced_chunks:
            meta_blob.extend(struct.pack("<I", int(reference)))
        meta_chunk_1based_indices.append(len(chunks) + 1)
        chunks.append((ANM_CHUNK_KEYFRAME_META, bytes(meta_blob)))

    # Real files emit KF_IDX as `count + (count+1) × u32` where entries[0]=0
    # and entries[i] (i>=1) is the 1-based chunk index of the META chunk that
    # terminates keyframe (i-1).
    kf_blob = bytearray(struct.pack("<I", len(sequence.keyframes)))
    kf_blob.extend(struct.pack("<I", 0))
    for meta_1based in meta_chunk_1based_indices:
        kf_blob.extend(struct.pack("<I", int(meta_1based)))
    chunks[0] = (ANM_CHUNK_KEYFRAME_INDEX, bytes(kf_blob))

    entry_count = len(chunks)
    # Real files (rbehem1/rtriage1/rtriage2) always close the table with a
    # null sentinel entry: `(type=0, offset=0, size=0)`, 12 bytes of zeros.
    # Account for it in entry_count so the header counters agree with the
    # original byte layout.
    entry_count_with_sentinel = entry_count + 1
    first_offset = 32 + entry_count_with_sentinel * 12
    # Header bytes 8-31 pattern matches real files:
    #   u32@8  = entry_count + 1         (i.e. entries + sentinel + 1)
    #   u32@12 = entry_count             (i.e. entries + sentinel; note this
    #                                     differs from .msh which uses
    #                                     entry_count+1 here too)
    #   u32@16 = 0
    #   u32@20 = 1                        (constant marker)
    #   u32@24 = 0
    #   u32@28 = 0
    header = struct.pack(
        "<8I",
        MAGIC,
        VERSION,
        entry_count_with_sentinel + 1,
        entry_count_with_sentinel,
        0,
        1,
        0,
        0,
    )

    table = bytearray()
    payload = bytearray()
    offset = first_offset
    for chunk_type, chunk_blob in chunks:
        table.extend(struct.pack("<III", chunk_type, offset, len(chunk_blob)))
        payload.extend(chunk_blob)
        offset += len(chunk_blob)
    # Null sentinel entry terminating the chunk table.
    table.extend(struct.pack("<III", 0, 0, 0))

    return header + bytes(table) + bytes(payload)