from __future__ import annotations

from .parser import ParsedMsh


def build_import_report(parsed: ParsedMsh, smsh_info: dict | None = None) -> str:
    lines: list[str] = []
    lines.append(f"10six import report for: {parsed.path.name}")
    lines.append(f"version: {parsed.version}")
    lines.append(f"chunk_count: {len(parsed.chunks)}")
    lines.append("")
    lines.append("chunk types:")
    for key, value in parsed.chunk_type_counts.items():
        lines.append(f"- {key}: {value}")

    lines.append("")
    lines.append("named vertex chunks:")
    if parsed.named_vertex_chunks:
        for name in parsed.named_vertex_chunks[:32]:
            lines.append(f"- {name}")
        if len(parsed.named_vertex_chunks) > 32:
            lines.append(f"- ... {len(parsed.named_vertex_chunks) - 32} more")
    else:
        lines.append("- none")

    if parsed.warnings:
        lines.append("")
        lines.append("warnings:")
        for warning in parsed.warnings:
            lines.append(f"- {warning}")

    if smsh_info:
        lines.append("")
        lines.append(f"smsh sidecar: {smsh_info.get('file')}")
        lines.append(f"smsh size: {smsh_info.get('size')}")
        lines.append(f"smsh contains SMSH string: {smsh_info.get('contains_smsh')}")
        lines.append("smsh sample strings:")
        for value in smsh_info.get("strings", []):
            lines.append(f"- {value}")

    lines.append("")
    lines.append(f"parts: {len(parsed.parts)}")
    for part in parsed.parts[:24]:
        lines.append(
            f"- {part.name}: verts={len(part.vertices)} faces={len(part.faces)} vertex_chunk={part.vertex_chunk_index} materials={len(part.material_textures)}"
        )
    if len(parsed.parts) > 24:
        lines.append(f"- ... {len(parsed.parts) - 24} more parts")

    return "\n".join(lines) + "\n"
