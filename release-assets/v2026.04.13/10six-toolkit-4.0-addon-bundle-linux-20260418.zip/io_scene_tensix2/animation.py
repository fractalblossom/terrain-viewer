from __future__ import annotations


def collect_animation_notes(parsed) -> list[str]:
    notes: list[str] = []
    if parsed.chunk_type_counts.get("bone", 0):
        notes.append("Bone chunks detected; this asset may have a skeletal or multipart hierarchy")
    notes.append(".anm import is not implemented in this starter scaffold")
    return notes
