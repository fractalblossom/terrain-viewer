from __future__ import annotations

import json
import math
import shutil
import struct
import subprocess
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path

import bpy
from mathutils import Matrix

from .anm_writer import AnimBoneTransform, AnimSequence, build_anm
from .msh_writer import FaceRecord, StaticMeshPart
from .skeletal_writer import SkeletalBoneRecord, SkeletalMeshPart, build_skeletal_msh


@dataclass
class TextureExportRecord:
    object_name: str
    material: str
    texture_ref: str
    strategy: str
    source: str | None


@dataclass
class ExportSummary:
    mesh_mode: str
    mesh_file: str
    texture_manifest_file: str | None
    texture_directory: str | None
    animation_files: list[str]
    smsh_file: str | None = None


@dataclass
class AnimationReport:
    armature_name: str
    bone_count: int
    deform_bone_count: int
    action_names: list[str]
    action_frame_ranges: dict[str, tuple[float, float]]
    mesh_bone_guesses: dict[str, str | None]
    notes: list[str]


@dataclass
class MaterialBakeSetup:
    material: object
    image_node: object
    emission_node: object | None
    output_node: object | None
    previous_active_node: object | None
    original_surface_socket: object | None


@dataclass
class PreparedMaterialMaps:
    baked_path: str
    artist_path: str
    guide_path: str
    material_name: str
    object_name: str


def _safe_ascii(value: str, fallback: str) -> str:
    cleaned = value.encode("ascii", errors="ignore").decode("ascii").strip()
    if not cleaned:
        return fallback
    return "".join(ch if ch.isalnum() or ch in ("_", "-", ".") else "_" for ch in cleaned)


def _iter_descendants(root):
    stack = list(root.children)
    while stack:
        current = stack.pop()
        yield current
        stack.extend(list(current.children))


def _collect_mesh_targets(context):
    active = context.active_object
    if active is None:
        raise ValueError("No active object selected")

    selected_meshes = [obj for obj in context.selected_objects if obj.type == "MESH"]
    if active.type == "ARMATURE":
        all_child_meshes = [obj for obj in _iter_descendants(active) if obj.type == "MESH"]
        meshes = [obj for obj in selected_meshes if obj in all_child_meshes] or all_child_meshes
        if not meshes:
            raise ValueError("The active armature does not have any child mesh objects")
        return active, meshes

    if active.type == "EMPTY":
        all_child_meshes = [obj for obj in _iter_descendants(active) if obj.type == "MESH"]
        meshes = [obj for obj in selected_meshes if obj in all_child_meshes] or all_child_meshes
        if not meshes:
            raise ValueError("The active empty does not have any child mesh objects")
        return None, meshes

    if active.type == "MESH":
        meshes = selected_meshes or [active]
        armature = active.parent if active.parent and active.parent.type == "ARMATURE" else None
        return armature, meshes

    raise ValueError("Select a mesh object, an empty root, or an armature with mesh children")


def _restore_active_selection(previous_active, previous_selection):
    for obj in bpy.context.selected_objects:
        obj.select_set(False)
    for obj in previous_selection:
        if obj.name in bpy.data.objects:
            bpy.data.objects[obj.name].select_set(True)
    if previous_active is not None and previous_active.name in bpy.data.objects:
        bpy.context.view_layer.objects.active = bpy.data.objects[previous_active.name]


def _gather_image_nodes(node_tree, images):
    if node_tree is None:
        return
    for node in node_tree.nodes:
        if node.type == "TEX_IMAGE" and getattr(node, "image", None) is not None:
            images.append(node.image)
        elif node.type == "GROUP" and getattr(node, "node_tree", None) is not None:
            _gather_image_nodes(node.node_tree, images)


def _blend_search_roots() -> list[Path]:
    roots: list[Path] = []
    blend_filepath = bpy.data.filepath
    if blend_filepath:
        roots.append(Path(blend_filepath).resolve().parent)
    roots.append(Path.cwd().resolve())

    deduped: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        key = str(root).lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(root)
    return deduped


def _resolve_image_source_path(image: bpy.types.Image) -> Path | None:
    if image is None:
        return None

    source_path = bpy.path.abspath(image.filepath, library=image.library) if image.filepath else ""
    if source_path:
        resolved = Path(source_path).resolve()
        if resolved.is_file():
            return resolved
        basename = resolved.name
    else:
        basename = ""

    if not basename:
        basename = Path(getattr(image, "name_full", image.name)).name

    if not basename:
        return None

    for root in _blend_search_roots():
        direct_match = root / basename
        if direct_match.is_file():
            return direct_match.resolve()

    for root in _blend_search_roots():
        matches = list(root.rglob(basename))
        if matches:
            return matches[0].resolve()

    return None


def _ensure_image_has_data(image: bpy.types.Image | None) -> bool:
    if image is None:
        return False

    if getattr(image, "has_data", False) and len(getattr(image, "size", [])) >= 2 and image.size[0] > 0 and image.size[1] > 0:
        return True

    source_path = _resolve_image_source_path(image)
    if source_path is None:
        return False

    image.filepath = str(source_path)
    try:
        image.reload()
    except RuntimeError:
        return False

    return bool(getattr(image, "has_data", False) and len(getattr(image, "size", [])) >= 2 and image.size[0] > 0 and image.size[1] > 0)


def _material_images(material) -> list[bpy.types.Image]:
    if material is None or material.node_tree is None:
        return []
    images: list[bpy.types.Image] = []
    _gather_image_nodes(material.node_tree, images)
    deduped = []
    seen = set()
    for image in images:
        key = getattr(image, "name_full", image.name)
        if key in seen:
            continue
        _ensure_image_has_data(image)
        seen.add(key)
        deduped.append(image)
    return deduped


def _material_base_color(material) -> tuple[float, float, float, float]:
    if material is None:
        return 0.8, 0.8, 0.8, 1.0
    if material.node_tree is not None:
        principled = material.node_tree.nodes.get("Principled BSDF")
        if principled is not None:
            value = principled.inputs["Base Color"].default_value
            return float(value[0]), float(value[1]), float(value[2]), float(value[3])
    value = material.diffuse_color
    return float(value[0]), float(value[1]), float(value[2]), float(value[3])


def _write_solid_bmp(path: Path, rgba: tuple[float, float, float, float]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    red = max(0, min(255, int(round(rgba[0] * 255.0))))
    green = max(0, min(255, int(round(rgba[1] * 255.0))))
    blue = max(0, min(255, int(round(rgba[2] * 255.0))))
    row = bytes((blue, green, red, 0))
    pixel_data = row
    file_size = 14 + 40 + len(pixel_data)
    with path.open("wb") as handle:
        handle.write(b"BM")
        handle.write(struct.pack("<IHHI", file_size, 0, 0, 54))
        handle.write(struct.pack("<IIIHHIIIIII", 40, 1, 1, 1, 24, 0, len(pixel_data), 2835, 2835, 0, 0))
        handle.write(pixel_data)


def _export_image_to_bmp(image: bpy.types.Image, destination: Path) -> str:
    source_path = bpy.path.abspath(image.filepath, library=image.library) if image.filepath else ""
    if source_path:
        source = Path(source_path)
        if source.exists() and source.suffix.lower() == ".bmp":
            shutil.copy2(source, destination)
            return "copy-bmp"
    width = max(int(image.size[0]) if len(image.size) > 0 else 0, 1)
    height = max(int(image.size[1]) if len(image.size) > 1 else 0, 1)
    export_image = bpy.data.images.new(
        name=f"TENSIX_EXPORT_{image.name}",
        width=width,
        height=height,
        alpha=getattr(image, "channels", 4) >= 4,
        float_buffer=bool(getattr(image, "is_float", False)),
    )
    try:
        export_image.pixels[:] = image.pixels[:]
        export_image.update()
        export_image.filepath_raw = str(destination)
        export_image.file_format = "BMP"
        export_image.save()
    finally:
        if export_image.name in bpy.data.images:
            bpy.data.images.remove(export_image)
    return "render-bmp"


def _save_image_to_png(image: bpy.types.Image, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    image.filepath_raw = str(destination)
    image.file_format = "PNG"
    image.save()


def _clamp_unit(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _percentile(values: list[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = int(round((len(ordered) - 1) * fraction))
    index = max(0, min(len(ordered) - 1, index))
    return ordered[index]


def _normalize_image_for_paint_base(image: bpy.types.Image) -> None:
    image.pixels[:] = image.pixels[:]
    pixels = list(image.pixels[:])
    if not pixels:
        return

    masked_indices: list[int] = []
    luminances: list[float] = []
    for offset in range(0, len(pixels), 4):
        red, green, blue, alpha = pixels[offset:offset + 4]
        if alpha > 0.001 or max(red, green, blue) > 0.001:
            masked_indices.append(offset)
            luminances.append(0.2126 * red + 0.7152 * green + 0.0722 * blue)

    if not masked_indices:
        return

    low = _percentile(luminances, 0.05)
    high = _percentile(luminances, 0.95)

    if high - low < 0.05:
        mean_luminance = sum(luminances) / len(luminances)
        gain = 0.55 / max(mean_luminance, 0.03)
        for offset in masked_indices:
            for channel in range(3):
                pixels[offset + channel] = _clamp_unit(pow(pixels[offset + channel] * gain, 0.9))
        image.pixels[:] = pixels
        image.update()
        return

    target_low = 0.16
    target_high = 0.88
    for offset in masked_indices:
        red, green, blue, _alpha = pixels[offset:offset + 4]
        luminance = 0.2126 * red + 0.7152 * green + 0.0722 * blue
        normalized = (luminance - low) / (high - low)
        normalized = _clamp_unit(normalized)
        boosted = target_low + normalized * (target_high - target_low)
        boosted = pow(boosted, 0.85)
        scale = boosted / max(luminance, 0.02)
        pixels[offset + 0] = _clamp_unit(red * scale)
        pixels[offset + 1] = _clamp_unit(green * scale)
        pixels[offset + 2] = _clamp_unit(blue * scale)

    image.pixels[:] = pixels
    image.update()


def _image_signal_stats(image: bpy.types.Image) -> dict[str, float]:
    pixels = list(image.pixels[:])
    if not pixels:
        return {"max_rgb": 0.0, "mean_luma": 0.0, "std_luma": 0.0, "coverage": 0.0}

    luminances: list[float] = []
    max_rgb = 0.0
    covered = 0
    for offset in range(0, len(pixels), 4):
        red, green, blue, alpha = pixels[offset:offset + 4]
        if alpha > 0.01 or max(red, green, blue) > 0.01:
            luminances.append(0.2126 * red + 0.7152 * green + 0.0722 * blue)
            max_rgb = max(max_rgb, red, green, blue)
            covered += 1

    if not luminances:
        return {"max_rgb": 0.0, "mean_luma": 0.0, "std_luma": 0.0, "coverage": 0.0}

    mean_luma = sum(luminances) / len(luminances)
    std_luma = math.sqrt(sum((value - mean_luma) ** 2 for value in luminances) / len(luminances))
    return {
        "max_rgb": max_rgb,
        "mean_luma": mean_luma,
        "std_luma": std_luma,
        "coverage": covered / (len(pixels) // 4),
    }


def _normalize_image_for_guide(image: bpy.types.Image) -> None:
    pixels = list(image.pixels[:])
    if not pixels:
        return

    masked_indices: list[int] = []
    luminances: list[float] = []
    for offset in range(0, len(pixels), 4):
        red, green, blue, alpha = pixels[offset:offset + 4]
        if alpha > 0.01 or max(red, green, blue) > 0.01:
            masked_indices.append(offset)
            luminances.append(0.2126 * red + 0.7152 * green + 0.0722 * blue)

    if not masked_indices:
        return

    low = _percentile(luminances, 0.02)
    high = _percentile(luminances, 0.98)
    if high - low < 0.01:
        low = min(luminances)
        high = max(luminances)
    scale = 1.0 / max(high - low, 0.004)

    for offset in masked_indices:
        red, green, blue, alpha = pixels[offset:offset + 4]
        for channel, value in enumerate((red, green, blue)):
            normalized = (value - low) * scale
            pixels[offset + channel] = _clamp_unit(pow(max(normalized, 0.0), 0.8))
        pixels[offset + 3] = _clamp_unit(max(alpha, 0.85 if max(pixels[offset:offset + 3]) > 0.02 else alpha))

    image.pixels[:] = pixels
    image.update()


def _synthesize_tinted_mask(material, target_image: bpy.types.Image, reference_image: bpy.types.Image | None) -> None:
    base = _material_base_color(material)
    target_rgb = [float(base[0]), float(base[1]), float(base[2])]
    max_component = max(target_rgb)
    if max_component < 0.05:
        target_rgb = [0.6, 0.6, 0.6]
    else:
        scale = 0.72 / max_component
        target_rgb = [_clamp_unit(pow(component * scale, 0.9)) for component in target_rgb]

    reference_pixels = list(reference_image.pixels[:]) if reference_image is not None else []
    target_pixels = list(target_image.pixels[:])
    for offset in range(0, len(target_pixels), 4):
        if reference_pixels:
            alpha = reference_pixels[offset + 3]
            ref_luma = 0.2126 * reference_pixels[offset] + 0.7152 * reference_pixels[offset + 1] + 0.0722 * reference_pixels[offset + 2]
        else:
            alpha = 1.0
            ref_luma = 0.5
        if alpha <= 0.01:
            target_pixels[offset + 0] = 0.0
            target_pixels[offset + 1] = 0.0
            target_pixels[offset + 2] = 0.0
            target_pixels[offset + 3] = 0.0
            continue
        detail = 0.72 + min(ref_luma * 0.5, 0.28)
        target_pixels[offset + 0] = _clamp_unit(target_rgb[0] * detail)
        target_pixels[offset + 1] = _clamp_unit(target_rgb[1] * detail)
        target_pixels[offset + 2] = _clamp_unit(target_rgb[2] * detail)
        target_pixels[offset + 3] = 1.0

    target_image.pixels[:] = target_pixels
    target_image.update()


def _rescue_low_signal_maps(material, baked_image: bpy.types.Image, guide_image: bpy.types.Image | None) -> None:
    if guide_image is not None:
        _normalize_image_for_guide(guide_image)

    baked_stats = _image_signal_stats(baked_image)
    guide_stats = _image_signal_stats(guide_image) if guide_image is not None else {"max_rgb": 0.0, "std_luma": 0.0}
    baked_low_signal = baked_stats["max_rgb"] < 0.10 or baked_stats["std_luma"] < 0.03
    guide_has_signal = guide_stats["max_rgb"] >= 0.12 and guide_stats["std_luma"] >= 0.04

    if baked_low_signal and guide_image is not None and guide_has_signal:
        baked_image.pixels[:] = guide_image.pixels[:]
        baked_image.update()
        _normalize_image_for_paint_base(baked_image)
        baked_stats = _image_signal_stats(baked_image)
        baked_low_signal = baked_stats["max_rgb"] < 0.10 or baked_stats["std_luma"] < 0.03

    if baked_low_signal:
        _synthesize_tinted_mask(material, baked_image, guide_image)

    if guide_image is not None:
        guide_stats = _image_signal_stats(guide_image)
        if guide_stats["max_rgb"] < 0.08 or guide_stats["std_luma"] < 0.02:
            _synthesize_tinted_mask(material, guide_image, guide_image)


def _prepared_map_path(material, property_name: str) -> Path | None:
    raw_path = str(material.get(property_name, "") or "").strip()
    if not raw_path:
        return None
    resolved = Path(bpy.path.abspath(raw_path))
    if not resolved.is_file():
        return None
    return resolved


def _load_prepared_image(path: Path) -> bpy.types.Image | None:
    try:
        image = bpy.data.images.load(str(path), check_existing=True)
    except RuntimeError:
        return None
    if not getattr(image, "has_data", False):
        try:
            image.reload()
        except RuntimeError:
            return None
    if not getattr(image, "has_data", False):
        return None
    return image


def _legacy_texture_ref(source_name: str | Path, fallback: str) -> str:
    source_path = Path(str(source_name))
    stem = source_path.stem or source_path.name
    return _safe_ascii(stem, fallback) + ".bmp"


def _image_source_key(image: bpy.types.Image) -> str:
    source_path = _resolve_image_source_path(image)
    if source_path is not None:
        return str(source_path)
    return f"blender-image:{getattr(image, 'name_full', image.name)}"


def _find_manifest_texture(manifest: list[TextureExportRecord], texture_ref: str) -> TextureExportRecord | None:
    normalized_ref = texture_ref.lower()
    for entry in manifest:
        if entry.texture_ref.lower() == normalized_ref:
            return entry
    return None


def _ensure_texture_ref_available(manifest: list[TextureExportRecord], texture_ref: str, source: str | None) -> bool:
    existing = _find_manifest_texture(manifest, texture_ref)
    if existing is None:
        return False
    if (existing.source or None) == (source or None):
        return True
    raise ValueError(
        f"Legacy-compatible export detected two different textures that collapse to the same Max-style basename '{texture_ref}'. "
        "Rename one of the source textures so the exported .msh matches the old 3ds Max pipeline."
    )


def _prepared_material_texture_reference(material, object_name: str, textures_dir: Path, manifest: list[TextureExportRecord]) -> str | None:
    material_name = _safe_ascii(material.name if material else "material", "material")

    if material is not None:
        artist_override_path = _prepared_map_path(material, "tensix_artist_override_map")
        if artist_override_path is not None:
            loaded = _load_prepared_image(artist_override_path)
            if loaded is not None and _image_signal_stats(loaded)["coverage"] > 0.0:
                source_key = str(artist_override_path.resolve())
                texture_ref = _legacy_texture_ref(artist_override_path, material_name)
                if _ensure_texture_ref_available(manifest, texture_ref, source_key):
                    return texture_ref
                destination = textures_dir / texture_ref
                strategy = _export_image_to_bmp(loaded, destination)
                manifest.append(
                    TextureExportRecord(
                        object_name=object_name,
                        material=material_name,
                        texture_ref=texture_ref,
                        strategy=f"artist-override-{strategy}",
                        source=str(artist_override_path),
                    )
                )
                return texture_ref

        baked_base_path = _prepared_map_path(material, "tensix_baked_base_map")
        if baked_base_path is not None:
            loaded = _load_prepared_image(baked_base_path)
            if loaded is not None:
                source_key = str(baked_base_path.resolve())
                texture_ref = _legacy_texture_ref(baked_base_path, material_name)
                if _ensure_texture_ref_available(manifest, texture_ref, source_key):
                    return texture_ref
                destination = textures_dir / texture_ref
                strategy = _export_image_to_bmp(loaded, destination)
                manifest.append(
                    TextureExportRecord(
                        object_name=object_name,
                        material=material_name,
                        texture_ref=texture_ref,
                        strategy=f"prepared-base-{strategy}",
                        source=str(baked_base_path),
                    )
                )
                return texture_ref

    return None


def _material_image_reference(material, object_name: str, textures_dir: Path, manifest: list[TextureExportRecord]) -> str | None:
    material_name = _safe_ascii(material.name if material else "material", "material")

    image_nodes = _material_images(material)
    if image_nodes:
        image = image_nodes[0]
        source_key = _image_source_key(image)
        source_name = image.name if source_key.startswith("blender-image:") else source_key
        texture_ref = _legacy_texture_ref(source_name, material_name)
        if _ensure_texture_ref_available(manifest, texture_ref, source_key):
            return texture_ref
        destination = textures_dir / texture_ref
        strategy = _export_image_to_bmp(image, destination)
        manifest.append(TextureExportRecord(object_name=object_name, material=material_name, texture_ref=texture_ref, strategy=strategy, source=source_key))
        return texture_ref

    return None


def _material_texture_fallback_reference(material, object_name: str, textures_dir: Path, manifest: list[TextureExportRecord]) -> str:
    material_name = _safe_ascii(material.name if material else "material", "material")

    image_ref = _material_image_reference(material, object_name, textures_dir, manifest)
    if image_ref is not None:
        return image_ref

    texture_ref = _safe_ascii(f"{object_name}_{material_name}", material_name) + ".bmp"
    destination = textures_dir / texture_ref
    _write_solid_bmp(destination, _material_base_color(material))
    manifest.append(TextureExportRecord(object_name=object_name, material=material_name, texture_ref=texture_ref, strategy="flat-color", source=None))
    return texture_ref


def _material_texture_reference(material, object_name: str, textures_dir: Path, manifest: list[TextureExportRecord]) -> str:
    prepared_ref = _prepared_material_texture_reference(material, object_name, textures_dir, manifest)
    if prepared_ref is not None:
        return prepared_ref
    return _material_texture_fallback_reference(material, object_name, textures_dir, manifest)


def _linked_or_default_rgba(socket) -> tuple[object | None, tuple[float, float, float, float]]:
    if socket is None:
        return None, (0.8, 0.8, 0.8, 1.0)
    if socket.is_linked:
        source_socket = socket.links[0].from_socket
        source_node = getattr(source_socket, "node", None)
        if source_node is not None and source_node.type == "TEX_IMAGE":
            _ensure_image_has_data(getattr(source_node, "image", None))
        return source_socket, (0.8, 0.8, 0.8, 1.0)
    value = getattr(socket, "default_value", (0.8, 0.8, 0.8, 1.0))
    if hasattr(value, "__len__") and len(value) >= 4:
        return None, (float(value[0]), float(value[1]), float(value[2]), float(value[3]))
    if hasattr(value, "__len__") and len(value) >= 3:
        return None, (float(value[0]), float(value[1]), float(value[2]), 1.0)
    scalar = float(value)
    return None, (scalar, scalar, scalar, 1.0)


def _material_bake_color_source(material) -> tuple[object | None, tuple[float, float, float, float]]:
    if material is None or material.node_tree is None:
        return None, _material_base_color(material)

    node_tree = material.node_tree

    for node_type, socket_name in (
        ("BSDF_PRINCIPLED", "Base Color"),
        ("EMISSION", "Color"),
        ("BSDF_DIFFUSE", "Color"),
        ("BSDF_GLASS", "Color"),
        ("BSDF_GLOSSY", "Color"),
    ):
        node = next((candidate for candidate in node_tree.nodes if candidate.type == node_type), None)
        if node is None:
            continue
        socket = node.inputs.get(socket_name)
        source_socket, fallback = _linked_or_default_rgba(socket)
        if source_socket is not None:
            return source_socket, fallback
        return None, fallback

    image_node = next((candidate for candidate in node_tree.nodes if candidate.type == "TEX_IMAGE" and getattr(candidate, "image", None) is not None), None)
    if image_node is not None:
        _ensure_image_has_data(image_node.image)
        return image_node.outputs.get("Color"), (0.8, 0.8, 0.8, 1.0)

    return None, _material_base_color(material)


def _find_active_output_node(material):
    if material is None or material.node_tree is None:
        return None
    outputs = [node for node in material.node_tree.nodes if node.type == "OUTPUT_MATERIAL"]
    if not outputs:
        return None
    return next((node for node in outputs if getattr(node, "is_active_output", False)), outputs[0])


def _prepare_material_bake_setup(material, image) -> MaterialBakeSetup | None:
    if material is None or material.node_tree is None:
        return None

    node_tree = material.node_tree
    image_node = node_tree.nodes.new("ShaderNodeTexImage")
    image_node.name = f"TENSIX_BAKE_{image.name}"
    image_node.label = image_node.name
    image_node.image = image
    previous_active_node = node_tree.nodes.active
    node_tree.nodes.active = image_node
    image_node.select = True

    output_node = _find_active_output_node(material)
    if output_node is None:
        return MaterialBakeSetup(material=material, image_node=image_node, emission_node=None, output_node=None, previous_active_node=previous_active_node, original_surface_socket=None)

    source_socket, fallback_rgba = _material_bake_color_source(material)
    emission_node = node_tree.nodes.new("ShaderNodeEmission")
    emission_node.name = f"TENSIX_BAKE_EMIT_{image.name}"
    emission_node.label = emission_node.name
    if source_socket is not None:
        node_tree.links.new(source_socket, emission_node.inputs["Color"])
    else:
        emission_node.inputs["Color"].default_value = fallback_rgba

    surface_input = output_node.inputs.get("Surface")
    original_surface_socket = None
    if surface_input is not None:
        if surface_input.is_linked:
            original_surface_socket = surface_input.links[0].from_socket
            for link in list(surface_input.links):
                node_tree.links.remove(link)
        node_tree.links.new(emission_node.outputs["Emission"], surface_input)

    return MaterialBakeSetup(
        material=material,
        image_node=image_node,
        emission_node=emission_node,
        output_node=output_node,
        previous_active_node=previous_active_node,
        original_surface_socket=original_surface_socket,
    )


def _find_material_color_input(material):
    if material is None or material.node_tree is None:
        return None
    for node_type, socket_name in (
        ("BSDF_PRINCIPLED", "Base Color"),
        ("EMISSION", "Color"),
        ("BSDF_DIFFUSE", "Color"),
        ("BSDF_GLASS", "Color"),
        ("BSDF_GLOSSY", "Color"),
    ):
        node = next((candidate for candidate in material.node_tree.nodes if candidate.type == node_type), None)
        if node is None:
            continue
        socket = node.inputs.get(socket_name)
        if socket is not None:
            return socket
    return None


def _clear_named_node(material, node_name: str) -> None:
    if material is None or material.node_tree is None:
        return
    node = material.node_tree.nodes.get(node_name)
    if node is not None:
        material.node_tree.nodes.remove(node)


def _prepare_material_image_target(material, image, node_name: str) -> MaterialBakeSetup | None:
    if material is None or material.node_tree is None:
        return None
    node_tree = material.node_tree
    image_node = node_tree.nodes.new("ShaderNodeTexImage")
    image_node.name = node_name
    image_node.label = node_name
    image_node.image = image
    previous_active_node = node_tree.nodes.active
    node_tree.nodes.active = image_node
    image_node.select = True
    return MaterialBakeSetup(
        material=material,
        image_node=image_node,
        emission_node=None,
        output_node=None,
        previous_active_node=previous_active_node,
        original_surface_socket=None,
    )


def _ensure_artist_image(image_name: str, destination: Path, texture_size: int):
    if destination.exists():
        return bpy.data.images.load(str(destination), check_existing=True)

    image = bpy.data.images.get(image_name)
    if image is None:
        image = bpy.data.images.new(name=image_name, width=int(texture_size), height=int(texture_size), alpha=True, float_buffer=False)
    else:
        image.scale(int(texture_size), int(texture_size))
    image.generated_color = (0.0, 0.0, 0.0, 0.0)
    _save_image_to_png(image, destination)
    return image


def _wire_artist_override_nodes(material, baked_image, artist_image, slot_key: str) -> bool:
    if material is None or material.node_tree is None:
        return False

    color_input = _find_material_color_input(material)
    if color_input is None:
        return False

    node_tree = material.node_tree
    baked_node_name = f"TENSIX_BAKED_{slot_key}"
    artist_node_name = f"TENSIX_ARTIST_{slot_key}"
    mix_node_name = f"TENSIX_BLEND_{slot_key}"

    _clear_named_node(material, baked_node_name)
    _clear_named_node(material, artist_node_name)
    _clear_named_node(material, mix_node_name)

    baked_node = node_tree.nodes.new("ShaderNodeTexImage")
    baked_node.name = baked_node_name
    baked_node.label = "10six Baked Base"
    baked_node.image = baked_image

    artist_node = node_tree.nodes.new("ShaderNodeTexImage")
    artist_node.name = artist_node_name
    artist_node.label = "10six Artist Override"
    artist_node.image = artist_image

    mix_node = node_tree.nodes.new("ShaderNodeMixRGB")
    mix_node.name = mix_node_name
    mix_node.label = "10six Artist Blend"
    mix_node.blend_type = "MIX"

    baked_node.location = (-900.0, 200.0)
    artist_node.location = (-900.0, -40.0)
    mix_node.location = (-620.0, 100.0)

    for link in list(color_input.links):
        node_tree.links.remove(link)

    node_tree.links.new(baked_node.outputs["Color"], mix_node.inputs[1])
    node_tree.links.new(artist_node.outputs["Color"], mix_node.inputs[2])
    node_tree.links.new(artist_node.outputs["Alpha"], mix_node.inputs["Fac"])
    node_tree.links.new(mix_node.outputs["Color"], color_input)
    return True


def _cleanup_material_bake_nodes(setups: list[MaterialBakeSetup | None]):
    for setup in setups:
        if setup is None:
            continue
        material = setup.material
        if material is None or material.node_tree is None:
            continue
        node_tree = material.node_tree
        if setup.output_node is not None:
            surface_input = setup.output_node.inputs.get("Surface")
            if surface_input is not None:
                for link in list(surface_input.links):
                    node_tree.links.remove(link)
                if setup.original_surface_socket is not None:
                    node_tree.links.new(setup.original_surface_socket, surface_input)
        if setup.emission_node is not None and setup.emission_node.name in node_tree.nodes:
            node_tree.nodes.remove(setup.emission_node)
        if setup.image_node is not None and setup.image_node.name in node_tree.nodes:
            node_tree.nodes.remove(setup.image_node)
        if setup.previous_active_node is not None and setup.previous_active_node.name in node_tree.nodes:
            node_tree.nodes.active = setup.previous_active_node


def _foreign_material_maps_root() -> Path:
    blend_filepath = bpy.data.filepath
    if blend_filepath:
        blend_path = Path(blend_filepath)
        return blend_path.parent / f"{blend_path.stem}_tensix_maps"
    return Path.cwd() / "untitled_tensix_maps"


def _prepare_object_material_maps(context, obj, output_root: Path, texture_size: int, report) -> list[PreparedMaterialMaps]:
    materials = list(obj.data.materials) if obj.type == "MESH" and obj.data is not None else []
    if not materials or not obj.data.uv_layers:
        return []

    scene = context.scene
    previous_engine = scene.render.engine
    previous_active = context.view_layer.objects.active
    previous_selection = list(context.selected_objects)
    bake_nodes: list[MaterialBakeSetup | None] = []
    bake_jobs: list[tuple[object, bpy.types.Image, Path, Path, Path, str]] = []
    prepared: list[PreparedMaterialMaps] = []
    persistent_images: set[str] = set()
    guide_nodes: list[MaterialBakeSetup | None] = []
    previous_pass_direct = None
    previous_pass_indirect = None
    previous_pass_color = None

    try:
        scene.render.engine = "CYCLES"
        if hasattr(scene, "cycles") and hasattr(scene.cycles, "device"):
            scene.cycles.device = "CPU"
        if hasattr(scene, "cycles") and hasattr(scene.cycles, "samples"):
            scene.cycles.samples = 8
        if hasattr(scene.render, "bake"):
            scene.render.bake.margin = 8
            scene.render.bake.use_clear = True
            if hasattr(scene.render.bake, "use_pass_direct"):
                previous_pass_direct = scene.render.bake.use_pass_direct
                scene.render.bake.use_pass_direct = True
            if hasattr(scene.render.bake, "use_pass_indirect"):
                previous_pass_indirect = scene.render.bake.use_pass_indirect
                scene.render.bake.use_pass_indirect = True
            if hasattr(scene.render.bake, "use_pass_color"):
                previous_pass_color = scene.render.bake.use_pass_color
                scene.render.bake.use_pass_color = True

        for selected in context.selected_objects:
            selected.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        object_key = _safe_ascii(obj.name, "part")
        output_root.mkdir(parents=True, exist_ok=True)

        for slot_index, material in enumerate(materials):
            if material is None or material.node_tree is None:
                continue

            material_key = _safe_ascii(material.name, f"material_{slot_index}")
            slot_key = f"{object_key}_m{slot_index}_{material_key}"
            baked_path = output_root / f"{slot_key}_baked.png"
            artist_path = output_root / f"{slot_key}_artist.png"
            guide_path = output_root / f"{slot_key}_guide.png"

            bake_image = bpy.data.images.new(
                name=f"TENSIX_PREP_{slot_key}",
                width=int(texture_size),
                height=int(texture_size),
                alpha=True,
                float_buffer=False,
            )
            bake_image.generated_color = (0.0, 0.0, 0.0, 0.0)
            setup = _prepare_material_bake_setup(material, bake_image)
            bake_nodes.append(setup)
            bake_jobs.append((material, bake_image, baked_path, artist_path, guide_path, slot_key))

        if not bake_jobs:
            return []

        bpy.ops.object.bake(type="EMIT", use_clear=True, margin=8)

        for _material, bake_image, baked_path, _artist_path, _guide_path, slot_key in bake_jobs:
            _normalize_image_for_paint_base(bake_image)
            _save_image_to_png(bake_image, baked_path)
            bake_image.name = f"TENSIX_PERSIST_{slot_key}"
            persistent_images.add(bake_image.name)

        _cleanup_material_bake_nodes(bake_nodes)
        bake_nodes = []

        for material, _bake_image, _baked_path, _artist_path, guide_path, slot_key in bake_jobs:
            guide_image = bpy.data.images.new(
                name=f"TENSIX_GUIDE_{slot_key}",
                width=int(texture_size),
                height=int(texture_size),
                alpha=True,
                float_buffer=False,
            )
            guide_image.generated_color = (0.0, 0.0, 0.0, 0.0)
            guide_nodes.append(_prepare_material_image_target(material, guide_image, f"TENSIX_GUIDE_TARGET_{slot_key}"))
            persistent_images.add(guide_image.name)

        if guide_nodes:
            bpy.ops.object.bake(type="COMBINED", use_clear=True, margin=8)

        for material, bake_image, baked_path, artist_path, guide_path, slot_key in bake_jobs:
            guide_image = bpy.data.images.get(f"TENSIX_GUIDE_{slot_key}")
            _rescue_low_signal_maps(material, bake_image, guide_image)
            _save_image_to_png(bake_image, baked_path)
            if guide_image is not None:
                _save_image_to_png(guide_image, guide_path)
            baked_image = bake_image
            artist_image = _ensure_artist_image(f"{slot_key}_artist", artist_path, texture_size)
            persistent_images.add(artist_image.name)
            if _wire_artist_override_nodes(material, baked_image, artist_image, slot_key):
                prepared.append(
                    PreparedMaterialMaps(
                        baked_path=str(baked_path),
                        artist_path=str(artist_path),
                        guide_path=str(guide_path),
                        material_name=material.name,
                        object_name=obj.name,
                    )
                )
                material["tensix_baked_base_map"] = str(baked_path)
                material["tensix_artist_override_map"] = str(artist_path)
                material["tensix_guide_preview_map"] = str(guide_path)
    finally:
        _cleanup_material_bake_nodes(guide_nodes)
        _cleanup_material_bake_nodes(bake_nodes)
        for _material, bake_image, _baked_path, _artist_path, _guide_path, slot_key in bake_jobs:
            for image_name in (bake_image.name, f"TENSIX_GUIDE_{slot_key}"):
                image = bpy.data.images.get(image_name)
                if image is not None and image.name not in locals().get("persistent_images", set()):
                    bpy.data.images.remove(image)
        if hasattr(scene.render, "bake"):
            if previous_pass_direct is not None:
                scene.render.bake.use_pass_direct = previous_pass_direct
            if previous_pass_indirect is not None:
                scene.render.bake.use_pass_indirect = previous_pass_indirect
            if previous_pass_color is not None:
                scene.render.bake.use_pass_color = previous_pass_color
        _restore_active_selection(previous_active, previous_selection)
        scene.render.engine = previous_engine

    return prepared


def prepare_foreign_materials(context, report, texture_size: int = 1024):
    _armature, meshes = _collect_mesh_targets(context)
    output_root = _foreign_material_maps_root()
    prepared: list[PreparedMaterialMaps] = []
    for mesh_obj in meshes:
        prepared.extend(_prepare_object_material_maps(context, mesh_obj, output_root, texture_size, report))

    if not prepared:
        report({"WARNING"}, "No UV-mapped foreign materials were prepared")
        return {"CANCELLED"}

    report({"INFO"}, f"Prepared {len(prepared)} material map pair(s) in {output_root}")
    return {"FINISHED"}


def _bake_object_material_textures(context, obj, textures_dir: Path, texture_size: int, manifest: list[TextureExportRecord], report) -> list[str]:
    materials = list(obj.data.materials) if obj.data is not None else []
    if not materials:
        return ["NoTexture.bmp"]

    object_key = _safe_ascii(obj.name, "part")
    prepared_refs = [_prepared_material_texture_reference(material, object_key, textures_dir, manifest) for material in materials]
    if all(ref is not None for ref in prepared_refs):
        return [ref for ref in prepared_refs if ref is not None]

    if not obj.data.uv_layers:
        texture_refs: list[str] = []
        for material, prepared_ref in zip(materials, prepared_refs):
            if prepared_ref is not None:
                texture_refs.append(prepared_ref)
                continue
            texture_refs.append(_material_texture_fallback_reference(material, object_key, textures_dir, manifest))
        return texture_refs

    scene = context.scene
    previous_engine = scene.render.engine
    previous_active = context.view_layer.objects.active
    previous_selection = list(context.selected_objects)
    bake_nodes: list[MaterialBakeSetup | None] = []
    baked_images: list[tuple[bpy.types.Image, Path, str, str | None]] = []
    texture_refs: list[str] = []

    try:
        scene.render.engine = "CYCLES"
        if hasattr(scene, "cycles") and hasattr(scene.cycles, "device"):
            scene.cycles.device = "CPU"
        if hasattr(scene, "cycles") and hasattr(scene.cycles, "samples"):
            scene.cycles.samples = 1
        if hasattr(scene.render, "bake"):
            scene.render.bake.margin = 8
            scene.render.bake.use_clear = True

        for selected in context.selected_objects:
            selected.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        for slot_index, material in enumerate(materials):
            material_key = _safe_ascii(material.name if material else f"material_{slot_index}", f"material_{slot_index}")

            prepared_ref = prepared_refs[slot_index]
            if prepared_ref is not None:
                texture_refs.append(prepared_ref)
                continue

            image_ref = _material_image_reference(material, object_key, textures_dir, manifest)
            if image_ref is not None:
                texture_refs.append(image_ref)
                continue

            texture_ref = f"{object_key}_m{slot_index}_{material_key}.bmp"
            destination = textures_dir / texture_ref

            if material is None or material.node_tree is None:
                _write_solid_bmp(destination, _material_base_color(material))
                manifest.append(TextureExportRecord(object_name=object_key, material=material_key, texture_ref=texture_ref, strategy="flat-color", source=None))
                texture_refs.append(texture_ref)
                continue

            image = bpy.data.images.new(
                name=f"TENSIX_BAKE_{object_key}_{slot_index}",
                width=int(texture_size),
                height=int(texture_size),
                alpha=False,
                float_buffer=False,
            )
            image.generated_color = (0.0, 0.0, 0.0, 1.0)
            setup = _prepare_material_bake_setup(material, image)
            bake_nodes.append(setup)
            baked_images.append((image, destination, texture_ref, material.filepath_from_user() if hasattr(material, "filepath_from_user") else None))
            texture_refs.append(texture_ref)

        if baked_images:
            bpy.ops.object.bake(type="EMIT", use_clear=True, margin=8)
            for image, destination, texture_ref, source in baked_images:
                _export_image_to_bmp(image, destination)
                manifest.append(TextureExportRecord(object_name=_safe_ascii(obj.name, "part"), material=Path(texture_ref).stem, texture_ref=texture_ref, strategy="bake-emit-color", source=source))
    except Exception as exc:
        report({"WARNING"}, f"Bake failed for {obj.name}: {exc}; falling back to flat-color textures")
        texture_refs = []
        for material, prepared_ref in zip(materials, prepared_refs):
            if prepared_ref is not None:
                texture_refs.append(prepared_ref)
                continue
            texture_refs.append(_material_texture_fallback_reference(material, object_key, textures_dir, manifest))
    finally:
        _cleanup_material_bake_nodes(bake_nodes)
        for image, _destination, _texture_ref, _source in baked_images:
            if image.name in bpy.data.images:
                bpy.data.images.remove(image)
        _restore_active_selection(previous_active, previous_selection)
        scene.render.engine = previous_engine

    return texture_refs or ["NoTexture.bmp"]


def _dominant_vertex_group_name(obj: bpy.types.Object) -> str | None:
    if obj.type != "MESH" or not obj.vertex_groups:
        return None
    weights: dict[int, float] = {}
    for vertex in obj.data.vertices:
        for group in vertex.groups:
            weights[group.group] = weights.get(group.group, 0.0) + group.weight
    if not weights:
        return None
    group_index = max(weights.items(), key=lambda item: item[1])[0]
    return obj.vertex_groups[group_index].name


def _build_animation_report(armature: bpy.types.Object | None, meshes: list[bpy.types.Object]) -> AnimationReport | None:
    if armature is None or armature.type != "ARMATURE":
        return None

    notes = ["Animation inventory for exported armature-driven asset."]
    action_names: list[str] = []
    action_frame_ranges: dict[str, tuple[float, float]] = {}
    for action in bpy.data.actions:
        action_names.append(action.name)
        action_frame_ranges[action.name] = tuple(float(value) for value in action.curve_frame_range)

    mesh_bone_guesses = {mesh.name: _dominant_vertex_group_name(mesh) for mesh in meshes}
    deform_bones = [bone for bone in armature.data.bones if bone.use_deform]
    if not deform_bones:
        notes.append("No deform bones were detected on the source armature.")

    return AnimationReport(
        armature_name=armature.name,
        bone_count=len(armature.data.bones),
        deform_bone_count=len(deform_bones),
        action_names=action_names,
        action_frame_ranges=action_frame_ranges,
        mesh_bone_guesses=mesh_bone_guesses,
        notes=notes,
    )


def _mesh_to_static_part(context, obj: bpy.types.Object, root_inverse: Matrix, texture_refs: list[str]) -> StaticMeshPart:
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        mesh.calc_loop_triangles()
        uv_data = mesh.uv_layers.active.data if mesh.uv_layers.active is not None else None
        transform = root_inverse @ evaluated.matrix_world
        vertices = [tuple(float(value) for value in (transform @ vertex.co)) for vertex in mesh.vertices]
        vertex_uvs = [(0.0, 0.0) for _ in mesh.vertices]
        assigned: set[int] = set()
        faces: list[FaceRecord] = []

        for loop_triangle in mesh.loop_triangles:
            polygon = mesh.polygons[loop_triangle.polygon_index]
            face_uvs = []
            for loop_index in loop_triangle.loops:
                vertex_index = mesh.loops[loop_index].vertex_index
                if uv_data is not None:
                    uv = uv_data[loop_index].uv
                    uv_pair = (float(uv.x), float(uv.y))
                else:
                    uv_pair = (0.0, 0.0)
                face_uvs.append(uv_pair)
                if vertex_index not in assigned:
                    vertex_uvs[vertex_index] = uv_pair
                    assigned.add(vertex_index)
            faces.append(
                FaceRecord(
                    indices=tuple(int(value) for value in loop_triangle.vertices),
                    material_index=min(int(polygon.material_index), max(len(texture_refs) - 1, 0)),
                    uvs=(face_uvs[0], face_uvs[1], face_uvs[2]),
                )
            )

        if not faces:
            raise ValueError(f"Mesh '{obj.name}' has no triangulated faces to export")

        return StaticMeshPart(
            name=_safe_ascii(obj.name, "part"),
            vertices=vertices,
            vertex_uvs=vertex_uvs,
            material_textures=texture_refs or ["NoTexture.bmp"],
            faces=faces,
        )
    finally:
        evaluated.to_mesh_clear()


def _mesh_to_object_local_part(context, obj: bpy.types.Object, texture_refs: list[str]) -> SkeletalMeshPart:
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        mesh.calc_loop_triangles()
        uv_data = mesh.uv_layers.active.data if mesh.uv_layers.active is not None else None
        vertices = [tuple(float(value) for value in vertex.co) for vertex in mesh.vertices]
        vertex_uvs = [(0.0, 0.0) for _ in mesh.vertices]
        assigned: set[int] = set()
        faces: list[FaceRecord] = []

        for loop_triangle in mesh.loop_triangles:
            polygon = mesh.polygons[loop_triangle.polygon_index]
            face_uvs = []
            for loop_index in loop_triangle.loops:
                vertex_index = mesh.loops[loop_index].vertex_index
                if uv_data is not None:
                    uv = uv_data[loop_index].uv
                    uv_pair = (float(uv.x), float(uv.y))
                else:
                    uv_pair = (0.0, 0.0)
                face_uvs.append(uv_pair)
                if vertex_index not in assigned:
                    vertex_uvs[vertex_index] = uv_pair
                    assigned.add(vertex_index)
            faces.append(
                FaceRecord(
                    indices=tuple(int(value) for value in loop_triangle.vertices),
                    material_index=min(int(polygon.material_index), max(len(texture_refs) - 1, 0)),
                    uvs=(face_uvs[0], face_uvs[1], face_uvs[2]),
                )
            )

        if not faces:
            raise ValueError(f"Mesh '{obj.name}' has no triangulated faces to export")

        return SkeletalMeshPart(
            name=_safe_ascii(obj.name, "part"),
            vertices=vertices,
            vertex_uvs=vertex_uvs,
            material_textures=texture_refs or ["NoTexture.bmp"],
            faces=faces,
        )
    finally:
        evaluated.to_mesh_clear()


def _unique_ascii_name(value: str, fallback: str, used: set[str]) -> str:
    base = _safe_ascii(value, fallback)
    candidate = base
    suffix = 1
    while candidate in used:
        candidate = f"{base}_{suffix}"
        suffix += 1
    used.add(candidate)
    return candidate


def _matrix_to_rows_and_pivot(matrix: Matrix) -> tuple[list[list[float]], tuple[float, float, float]]:
    return _matrix3_rows(matrix), _vector3(matrix.to_translation())


def _matrix_is_near_identity(matrix: Matrix, *, tol: float = 1e-5) -> bool:
    identity = Matrix.Identity(4)
    for r in range(4):
        for c in range(4):
            if abs(matrix[r][c] - identity[r][c]) > tol:
                return False
    return True


def _nearest_selected_mesh_parent(obj: bpy.types.Object, selected_meshes: set[bpy.types.Object]) -> bpy.types.Object | None:
    parent = obj.parent
    while parent is not None:
        if parent.type == "MESH" and parent in selected_meshes:
            return parent
        parent = parent.parent
    return None


def _collect_attachment_empties(root_empty: bpy.types.Object | None) -> list[bpy.types.Object]:
    """Return EMPTY descendants of the explicit root that should be exported as
    empty bone records (attachment points like cupola/muzzle/weapon).

    Skips the import-wrapper empties: `10six_<name>` roots and
    `<name>_skeleton` holders, which are purely organizational and were not
    present as bones in the original file.
    """
    if root_empty is None:
        return []
    attachments: list[bpy.types.Object] = []
    for obj in _iter_descendants(root_empty):
        if obj.type != "EMPTY":
            continue
        if obj.name.startswith("10six_"):
            continue
        if obj.name.endswith("_skeleton"):
            continue
        attachments.append(obj)
    return attachments


def _build_static_records(context, meshes: list[bpy.types.Object], textures_dir: Path, texture_size: int, manifest: list[TextureExportRecord], report, root_name_hint: str) -> list[SkeletalBoneRecord]:
    active = context.active_object
    ordered_meshes = list(dict.fromkeys(meshes))
    selected_meshes = set(ordered_meshes)
    used_names: set[str] = set()
    mesh_record_names = {mesh: _unique_ascii_name(mesh.name, "part", used_names) for mesh in ordered_meshes}

    explicit_root_name: str | None = None
    explicit_root_object = active if active is not None and active.type == "EMPTY" else None

    # Detect the import-wrapper EMPTY: a `10six_<name>` (or `tensix_<name>`)
    # EMPTY at identity transform that exists purely as Blender housekeeping
    # for round-tripped imports. Real .msh files do NOT have a phantom
    # geometry-less root bone, and msh2smsh.exe rejects exports that include
    # one (Error 25 — "Negative size data" on the dummy 1-vertex VERTEX chunk
    # the writer emits for a geometry-less root).  Drop the wrapper bone in
    # that case and promote the first selected top-level mesh to root, with
    # any sibling meshes re-parented under it (matches the placeholder.msh /
    # gsmkbm2.msh layout: 2 BONE chunks, both with geometry, no phantoms).
    suppress_root_bone = False
    if explicit_root_object is not None:
        is_wrapper_name = explicit_root_object.name.startswith(("10six_", "tensix_"))
        is_identity = _matrix_is_near_identity(explicit_root_object.matrix_world)
        if is_wrapper_name and is_identity:
            suppress_root_bone = True
        else:
            explicit_root_name = _unique_ascii_name(explicit_root_object.name, f"{root_name_hint}_root", used_names)

    parent_names: dict[bpy.types.Object, str | None] = {}
    for mesh in ordered_meshes:
        parent_mesh = _nearest_selected_mesh_parent(mesh, selected_meshes)
        if parent_mesh is not None:
            parent_names[mesh] = mesh_record_names[parent_mesh]
        elif explicit_root_name is not None:
            parent_names[mesh] = explicit_root_name
        else:
            parent_names[mesh] = None

    top_level_meshes = [mesh for mesh in ordered_meshes if parent_names[mesh] is None]

    if suppress_root_bone and len(top_level_meshes) > 1:
        # Promote the first top-level mesh as the new root; reparent the rest
        # under it. This converts the (wrapper EMPTY -> [m1, m2, ...])
        # hierarchy into the (m1 -> [m2, ...]) hierarchy that real files use.
        promoted = top_level_meshes[0]
        promoted_name = mesh_record_names[promoted]
        for sibling in top_level_meshes[1:]:
            parent_names[sibling] = promoted_name
        top_level_meshes = [promoted]

    if explicit_root_name is None and not suppress_root_bone and len(top_level_meshes) > 1:
        raise ValueError(
            "Legacy-compatible static export requires a single top-level root, matching the old 3ds Max exporter. "
            "Parent the selected meshes under one Empty root in Blender, or export one rooted hierarchy at a time."
        )

    world_matrices: dict[str, Matrix] = {}
    records: list[SkeletalBoneRecord] = []

    if explicit_root_name is not None and explicit_root_object is not None:
        root_matrix, root_pivot = _matrix_to_rows_and_pivot(explicit_root_object.matrix_world.copy())
        records.append(
            SkeletalBoneRecord(
                name=explicit_root_name,
                parent_name=None,
                local_matrix=root_matrix,
                pivot=root_pivot,
                mesh_part=None,
            )
        )
        world_matrices[explicit_root_name] = explicit_root_object.matrix_world.copy()

    pending = list(ordered_meshes)
    while pending:
        progressed = False
        for mesh in list(pending):
            parent_name = parent_names[mesh]
            if parent_name is not None and parent_name not in world_matrices:
                continue

            parent_world = world_matrices[parent_name] if parent_name is not None else Matrix.Identity(4)
            local_matrix = parent_world.inverted() @ mesh.matrix_world
            local_rows, local_pivot = _matrix_to_rows_and_pivot(local_matrix)
            texture_refs = _bake_object_material_textures(context, mesh, textures_dir, texture_size, manifest, report)
            mesh_part = _mesh_to_object_local_part(context, mesh, texture_refs)
            record_name = mesh_record_names[mesh]
            records.append(
                SkeletalBoneRecord(
                    name=record_name,
                    parent_name=parent_name,
                    local_matrix=local_rows,
                    pivot=local_pivot,
                    mesh_part=mesh_part,
                )
            )
            world_matrices[record_name] = mesh.matrix_world.copy()
            pending.remove(mesh)
            progressed = True

        if not progressed:
            raise ValueError("Static export could not resolve the selected mesh hierarchy")

    # Emit bone records for EMPTY attachment points (cupola/muzzle/weapon etc).
    # These appeared as geometry-less BONE chunks in the original files and are
    # required for the game to mount weapons/cupolas correctly.
    attachment_empties = _collect_attachment_empties(explicit_root_object)
    if attachment_empties:
        empty_names: dict[bpy.types.Object, str] = {}
        for empty in attachment_empties:
            empty_names[empty] = _unique_ascii_name(empty.name, "attach", used_names)

        def _empty_parent_name(empty: bpy.types.Object) -> str | None:
            parent = empty.parent
            while parent is not None:
                if parent in empty_names:
                    return empty_names[parent]
                if parent.type == "MESH" and parent in mesh_record_names:
                    return mesh_record_names[parent]
                if explicit_root_object is not None and parent is explicit_root_object:
                    return explicit_root_name
                parent = parent.parent
            return explicit_root_name

        pending_empties = list(attachment_empties)
        while pending_empties:
            progressed = False
            for empty in list(pending_empties):
                parent_name = _empty_parent_name(empty)
                if parent_name is not None and parent_name not in world_matrices:
                    # Parent is another empty we haven't emitted yet.
                    if any(empty_names.get(p) == parent_name for p in pending_empties):
                        continue
                parent_world = world_matrices[parent_name] if parent_name in world_matrices else Matrix.Identity(4)
                local_matrix = parent_world.inverted() @ empty.matrix_world
                local_rows, local_pivot = _matrix_to_rows_and_pivot(local_matrix)
                record_name = empty_names[empty]
                records.append(
                    SkeletalBoneRecord(
                        name=record_name,
                        parent_name=parent_name,
                        local_matrix=local_rows,
                        pivot=local_pivot,
                        mesh_part=None,
                    )
                )
                world_matrices[record_name] = empty.matrix_world.copy()
                pending_empties.remove(empty)
                progressed = True
            if not progressed:
                raise ValueError("Static export could not resolve attachment-empty hierarchy")

    return records


def _iter_action_frame_numbers(action) -> list[int]:
    frame_start, frame_end = action.curve_frame_range
    start = int(math.floor(frame_start))
    end = int(math.ceil(frame_end))
    return list(range(start, end + 1))


def _iter_export_actions() -> list:
    actions = []
    for action in bpy.data.actions:
        try:
            frame_start, frame_end = action.curve_frame_range
        except Exception:
            continue
        if frame_end >= frame_start:
            actions.append(action)
    return actions


def _safe_action_name(action_name: str) -> str:
    return _safe_ascii(action_name, "anim")


def _local_pose_matrix(pose_bone) -> Matrix:
    if pose_bone.parent is not None:
        return pose_bone.parent.matrix.inverted() @ pose_bone.matrix
    return pose_bone.matrix.copy()


def _matrix3_rows(matrix: Matrix) -> list[list[float]]:
    matrix3 = matrix.to_3x3()
    return [[float(matrix3[row][col]) for col in range(3)] for row in range(3)]


def _identity_matrix_rows() -> list[list[float]]:
    return [
        [1.0, 0.0, 0.0],
        [0.0, 1.0, 0.0],
        [0.0, 0.0, 1.0],
    ]


def _vector3(value) -> tuple[float, float, float]:
    return float(value.x), float(value.y), float(value.z)


def _capture_bind_pose(armature, bone_names: list[str], bind_action, bind_frame: int):
    scene = bpy.context.scene
    previous_action = armature.animation_data.action if armature.animation_data else None
    previous_frame = scene.frame_current
    if armature.animation_data is None:
        armature.animation_data_create()
    armature.animation_data.action = bind_action
    scene.frame_set(int(bind_frame))
    bpy.context.view_layer.update()

    bind_data: dict[str, tuple[list[list[float]], tuple[float, float, float]]] = {}
    for bone_name in bone_names:
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None:
            bind_data[bone_name] = (_identity_matrix_rows(), (0.0, 0.0, 0.0))
            continue
        local_matrix = _local_pose_matrix(pose_bone)
        bind_data[bone_name] = (_matrix3_rows(local_matrix), _vector3(local_matrix.to_translation()))

    scene.frame_set(previous_frame)
    armature.animation_data.action = previous_action
    bpy.context.view_layer.update()
    return bind_data


def _mesh_to_bone_local_part(context, obj, armature, bone_name: str, texture_refs: list[str]) -> SkeletalMeshPart:
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        mesh.calc_loop_triangles()
        pose_bone = armature.pose.bones[bone_name]
        bone_world = armature.matrix_world @ pose_bone.matrix
        bone_world_inverse = bone_world.inverted()
        uv_data = mesh.uv_layers.active.data if mesh.uv_layers.active is not None else None
        vertices = [tuple(float(value) for value in (bone_world_inverse @ (evaluated.matrix_world @ vertex.co))) for vertex in mesh.vertices]
        vertex_uvs = [(0.0, 0.0) for _ in mesh.vertices]
        assigned: set[int] = set()
        faces: list[FaceRecord] = []
        for loop_triangle in mesh.loop_triangles:
            polygon = mesh.polygons[loop_triangle.polygon_index]
            face_uvs = []
            for loop_index in loop_triangle.loops:
                vertex_index = mesh.loops[loop_index].vertex_index
                if uv_data is not None:
                    uv = uv_data[loop_index].uv
                    uv_pair = (float(uv.x), float(uv.y))
                else:
                    uv_pair = (0.0, 0.0)
                face_uvs.append(uv_pair)
                if vertex_index not in assigned:
                    vertex_uvs[vertex_index] = uv_pair
                    assigned.add(vertex_index)
            faces.append(
                FaceRecord(
                    indices=tuple(int(value) for value in loop_triangle.vertices),
                    material_index=min(int(polygon.material_index), max(len(texture_refs) - 1, 0)),
                    uvs=(face_uvs[0], face_uvs[1], face_uvs[2]),
                )
            )
        return SkeletalMeshPart(
            name=_safe_ascii(obj.name, bone_name),
            vertices=vertices,
            vertex_uvs=vertex_uvs,
            material_textures=list(texture_refs),
            faces=faces,
        )
    finally:
        evaluated.to_mesh_clear()


def _append_skeletal_part(base_part: SkeletalMeshPart, incoming: SkeletalMeshPart) -> None:
    vertex_offset = len(base_part.vertices)
    material_offset = len(base_part.material_textures)
    base_part.vertices.extend(incoming.vertices)
    base_part.vertex_uvs.extend(incoming.vertex_uvs)
    base_part.material_textures.extend(incoming.material_textures)
    for face in incoming.faces:
        base_part.faces.append(
            FaceRecord(
                indices=(face.indices[0] + vertex_offset, face.indices[1] + vertex_offset, face.indices[2] + vertex_offset),
                material_index=face.material_index + material_offset,
                uvs=face.uvs,
            )
        )


def _can_export_rigid_skeletal(armature, meshes: list[bpy.types.Object]) -> bool:
    if armature is None:
        return False
    return all(mesh.parent == armature and mesh.parent_type == "BONE" and mesh.parent_bone for mesh in meshes)


def _prepare_export_output(output_path: Path) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    textures_dir = output_path.parent / f"{output_path.stem}_textures"
    if textures_dir.exists():
        shutil.rmtree(textures_dir)
    textures_dir.mkdir(parents=True, exist_ok=True)

    for anm_path in output_path.parent.glob(f"{output_path.stem}*.anm"):
        anm_path.unlink(missing_ok=True)

    return textures_dir


def _build_skeletal_records(context, armature, meshes: list[bpy.types.Object], textures_dir: Path, texture_size: int, manifest: list[TextureExportRecord], bind_action, bind_frame: int, report):
    armature_bones = [bone for bone in armature.data.bones if bone.use_deform]
    bone_names = [bone.name for bone in armature_bones]
    bind_data = _capture_bind_pose(armature, bone_names, bind_action, bind_frame)

    parts_by_bone: dict[str, SkeletalMeshPart] = {}
    previous_action = armature.animation_data.action if armature.animation_data else None
    previous_frame = bpy.context.scene.frame_current
    if armature.animation_data is None:
        armature.animation_data_create()
    armature.animation_data.action = bind_action
    bpy.context.scene.frame_set(int(bind_frame))
    bpy.context.view_layer.update()

    for mesh_obj in meshes:
        texture_refs = _bake_object_material_textures(context, mesh_obj, textures_dir, texture_size, manifest, report)
        part = _mesh_to_bone_local_part(context, mesh_obj, armature, mesh_obj.parent_bone, texture_refs)
        if mesh_obj.parent_bone in parts_by_bone:
            _append_skeletal_part(parts_by_bone[mesh_obj.parent_bone], part)
        else:
            parts_by_bone[mesh_obj.parent_bone] = part

    bpy.context.scene.frame_set(previous_frame)
    armature.animation_data.action = previous_action
    bpy.context.view_layer.update()

    records: list[SkeletalBoneRecord] = []
    for bone in armature_bones:
        matrix_rows, pivot = bind_data[bone.name]
        records.append(
            SkeletalBoneRecord(
                name=_safe_ascii(bone.name, "bone"),
                parent_name=_safe_ascii(bone.parent.name, "bone") if bone.parent and bone.parent.use_deform else None,
                local_matrix=matrix_rows,
                pivot=pivot,
                mesh_part=parts_by_bone.get(bone.name),
            )
        )
    return records


def _normalize_skeletal_records(records: list[SkeletalBoneRecord], root_name: str) -> list[SkeletalBoneRecord]:
    root_records = [record for record in records if record.parent_name is None]
    if len(root_records) <= 1:
        return records

    synthetic_root = _safe_ascii(root_name, "root")
    existing_names = {record.name for record in records}
    while synthetic_root in existing_names:
        synthetic_root = f"{synthetic_root}_root"

    normalized: list[SkeletalBoneRecord] = []
    for record in records:
        if record.parent_name is None:
            normalized.append(
                SkeletalBoneRecord(
                    name=record.name,
                    parent_name=synthetic_root,
                    local_matrix=record.local_matrix,
                    pivot=record.pivot,
                    mesh_part=record.mesh_part,
                )
            )
        else:
            normalized.append(record)

    normalized.append(
        SkeletalBoneRecord(
            name=synthetic_root,
            parent_name=None,
            local_matrix=_identity_matrix_rows(),
            pivot=(0.0, 0.0, 0.0),
            mesh_part=None,
        )
    )
    return normalized


def _build_animation_sequences(armature, records: list[SkeletalBoneRecord]) -> list[AnimSequence]:
    if armature.animation_data is None:
        armature.animation_data_create()
    previous_action = armature.animation_data.action
    previous_frame = bpy.context.scene.frame_current

    bind_action = next(iter(_iter_export_actions()), None)
    bind_frame = _iter_action_frame_numbers(bind_action)[0] if bind_action else 0
    bind_data = _capture_bind_pose(armature, [record.name for record in records], bind_action, bind_frame) if bind_action else {record.name: (record.local_matrix, record.pivot) for record in records}

    sequences: list[AnimSequence] = []
    for action in _iter_export_actions():
        armature.animation_data.action = action
        frame_numbers = _iter_action_frame_numbers(action)
        keyframes: list[list[AnimBoneTransform]] = []
        for frame_number in frame_numbers:
            bpy.context.scene.frame_set(int(frame_number))
            bpy.context.view_layer.update()
            transforms: list[AnimBoneTransform] = []
            for bone_index, record in enumerate(records):
                pose_bone = armature.pose.bones.get(record.name)
                if pose_bone is None:
                    transforms.append(AnimBoneTransform(bone_index=bone_index, rotation=record.local_matrix, translation=(0.0, 0.0, 0.0)))
                    continue
                local_matrix = _local_pose_matrix(pose_bone)
                translation = local_matrix.to_translation()
                bind_pivot = bind_data[record.name][1]
                transforms.append(
                    AnimBoneTransform(
                        bone_index=bone_index,
                        rotation=_matrix3_rows(local_matrix),
                        translation=(float(translation.x - bind_pivot[0]), float(translation.y - bind_pivot[1]), float(translation.z - bind_pivot[2])),
                    )
                )
            keyframes.append(transforms)
        sequences.append(AnimSequence(name=_safe_action_name(action.name), frame_times=[int(frame) for frame in frame_numbers], keyframes=keyframes))

    bpy.context.scene.frame_set(previous_frame)
    armature.animation_data.action = previous_action
    bpy.context.view_layer.update()
    return sequences


def _write_animation_files(output_path: Path, sequences: list[AnimSequence]) -> list[str]:
    written: list[str] = []
    if not sequences:
        return written
    multi = len(sequences) > 1
    for sequence in sequences:
        if multi:
            anm_path = output_path.with_name(f"{output_path.stem}_{sequence.name}.anm")
        else:
            anm_path = output_path.with_suffix(".anm")
        anm_path.write_bytes(build_anm(sequence))
        written.append(str(anm_path))
    return written


def _locate_msh2smsh(*, hint_paths: list[Path] | None = None) -> Path | None:
    """Locate the msh2smsh.exe converter shipped with the original pv_plugin.

    Search order:
      1. ``TENSIX_MSH2SMSH`` environment variable.
      2. ``pv_plugin/msh2smsh.exe`` walking up from each path in ``hint_paths``
         (export output directory, current .blend file, addon directory, etc.)
         until the workspace root containing ``pv_plugin/`` is found.
      3. PATH lookup via ``shutil.which``.
    """
    import os
    env = os.environ.get("TENSIX_MSH2SMSH")
    if env:
        p = Path(env)
        if p.is_file():
            return p

    candidates: list[Path] = []
    if hint_paths:
        candidates.extend(hint_paths)
    candidates.append(Path(__file__).resolve())
    try:
        blend_file = bpy.data.filepath
        if blend_file:
            candidates.append(Path(blend_file).resolve())
    except Exception:
        pass

    seen: set[Path] = set()
    for start in candidates:
        try:
            start = start.resolve()
        except Exception:
            continue
        for ancestor in [start, *start.parents]:
            if ancestor in seen:
                break
            seen.add(ancestor)
            candidate = ancestor / "pv_plugin" / "msh2smsh.exe"
            if candidate.is_file():
                return candidate
    found = shutil.which("msh2smsh.exe") or shutil.which("msh2smsh")
    return Path(found) if found else None


def _generate_smsh_sidecar(msh_path: Path, *, model_type: str = "Generic Model", report=None) -> Path | None:
    """Run msh2smsh.exe to produce a .smsh sidecar next to ``msh_path``.

    Returns the .smsh path on success, or ``None`` if the converter is missing
    or fails. Failures are reported via ``report`` (Blender operator report) but
    do not raise — the .msh export remains usable on its own.
    """
    converter = _locate_msh2smsh(hint_paths=[msh_path.parent])
    if converter is None:
        if report is not None:
            report({"WARNING"}, "msh2smsh.exe not found; skipping .smsh generation. Set TENSIX_MSH2SMSH or place pv_plugin/msh2smsh.exe in the workspace.")
        return None

    smsh_target = msh_path.with_suffix(".smsh")
    stem = msh_path.stem

    # msh2smsh insists on its own input/output directory layout (see SMSH.CPP)
    # so we stage the .msh into a temp directory and harvest the resulting
    # .smsh from a parallel output directory.
    with tempfile.TemporaryDirectory(prefix="tensix_smsh_") as td:
        td_path = Path(td)
        msh_dir = td_path / "msh"
        smsh_dir = td_path / "smsh"
        msh_dir.mkdir()
        smsh_dir.mkdir()
        staged_msh = msh_dir / f"{stem}.msh"
        staged_msh.write_bytes(msh_path.read_bytes())
        try:
            proc = subprocess.run(
                [str(converter), "-t", model_type, "-i", str(msh_dir), "-s", str(smsh_dir), stem],
                cwd=td,
                capture_output=True,
                timeout=30,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            if report is not None:
                report({"WARNING"}, f"msh2smsh.exe failed to launch: {exc}")
            return None
        produced = smsh_dir / f"{stem}.smsh"
        if proc.returncode != 0 or not produced.is_file():
            stderr = (proc.stderr or b"").decode("latin-1", errors="replace").strip()
            stdout = (proc.stdout or b"").decode("latin-1", errors="replace").strip()
            msg = stderr or stdout or f"exit code {proc.returncode}"
            if report is not None:
                report({"WARNING"}, f"msh2smsh.exe rejected {stem}.msh: {msg}")
            return None
        smsh_target.write_bytes(produced.read_bytes())
    return smsh_target


def _export_static_package(context, filepath: str, report, texture_size: int, emit_reports: bool) -> ExportSummary:
    armature, meshes = _collect_mesh_targets(context)
    output_path = Path(filepath)
    textures_dir = _prepare_export_output(output_path)

    texture_manifest: list[TextureExportRecord] = []
    records = _build_static_records(
        context=context,
        meshes=meshes,
        textures_dir=textures_dir,
        texture_size=texture_size,
        manifest=texture_manifest,
        report=report,
        root_name_hint=_safe_ascii(output_path.stem, "root"),
    )

    output_path.write_bytes(build_skeletal_msh(records))
    smsh_path = _generate_smsh_sidecar(output_path, model_type="Generic Model", report=report)
    manifest_path = None
    if emit_reports:
        manifest_path = output_path.with_suffix(".textures.json")
        manifest_path.write_text(json.dumps([asdict(entry) for entry in texture_manifest], indent=2), encoding="utf-8")
        animation_report = _build_animation_report(armature, meshes)
        if animation_report is not None:
            output_path.with_suffix(".animation_report.json").write_text(json.dumps(asdict(animation_report), indent=2), encoding="utf-8")

    return ExportSummary(
        mesh_mode="static",
        mesh_file=str(output_path),
        texture_manifest_file=str(manifest_path) if manifest_path else None,
        texture_directory=str(textures_dir),
        animation_files=[],
        smsh_file=str(smsh_path) if smsh_path else None,
    )


def _export_skeletal_package(context, filepath: str, report, texture_size: int, emit_reports: bool) -> ExportSummary:
    armature, meshes = _collect_mesh_targets(context)
    if armature is None:
        raise ValueError("No armature was selected for skeletal export")
    output_path = Path(filepath)
    textures_dir = _prepare_export_output(output_path)

    texture_manifest: list[TextureExportRecord] = []
    bind_action = next(iter(_iter_export_actions()), None)
    bind_frame = _iter_action_frame_numbers(bind_action)[0] if bind_action else 0
    records = _build_skeletal_records(context, armature, meshes, textures_dir, texture_size, texture_manifest, bind_action, bind_frame, report)
    records = _normalize_skeletal_records(records, f"{armature.name}_root")
    output_path.write_bytes(build_skeletal_msh(records))
    smsh_path = _generate_smsh_sidecar(output_path, model_type="Generic Model", report=report)
    animation_files = _write_animation_files(output_path, _build_animation_sequences(armature, records))

    manifest_path = None
    if emit_reports:
        manifest_path = output_path.with_suffix(".textures.json")
        manifest_path.write_text(json.dumps([asdict(entry) for entry in texture_manifest], indent=2), encoding="utf-8")
        animation_report = _build_animation_report(armature, meshes)
        if animation_report is not None:
            notes = list(animation_report.notes)
            notes.append(f"Exported {len(animation_files)} .anm file(s).")
            animation_report.notes = notes
            output_path.with_suffix(".animation_report.json").write_text(json.dumps(asdict(animation_report), indent=2), encoding="utf-8")

    return ExportSummary(
        mesh_mode="skeletal",
        mesh_file=str(output_path),
        texture_manifest_file=str(manifest_path) if manifest_path else None,
        texture_directory=str(textures_dir),
        animation_files=animation_files,
        smsh_file=str(smsh_path) if smsh_path else None,
    )


def export_foreign_msh(context, filepath: str, report, texture_size: int = 512, emit_reports: bool = True):
    armature, meshes = _collect_mesh_targets(context)
    if _can_export_rigid_skeletal(armature, meshes):
        summary = _export_skeletal_package(context, filepath, report, texture_size, emit_reports)
    else:
        summary = _export_static_package(context, filepath, report, texture_size, emit_reports)

    report({"INFO"}, f"Exported foreign 10six mesh to {summary.mesh_file}")
    if summary.smsh_file:
        report({"INFO"}, f"Generated companion .smsh: {summary.smsh_file}")
    if summary.texture_directory:
        report({"INFO"}, f"Wrote texture outputs to {summary.texture_directory}")
    if summary.animation_files:
        report({"INFO"}, f"Exported animation files: {', '.join(summary.animation_files)}")
    return {"FINISHED"}
