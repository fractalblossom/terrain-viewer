"""Byte-level parser for 10six ``.anm`` animation files.

Format (verified against ``rbehem1.anm`` / ``rtriage1.anm``):

Header (32 bytes)
-----------------
* 0..3   magic  0x1234ABCD
* 4..7   version 8
* 8..11  entry_count + 1
* 12..15 entry_count (note: differs from MSH which uses entry_count+1 here)
* 16..19 0
* 20..23 1   (constant marker)
* 24..31 0

Chunk table (12 bytes/entry, ``entry_count`` entries):
``(chunk_type:u32, offset:u32, size:u32)`` each.

Chunk types:
* 0x00020001 ``KF_IDX``  — keyframe index table
* 0x00020003 ``META``    — per-keyframe bone-transform chunk references
* 0x00020004 ``BONE``    — a single bone transform for one keyframe

KF_IDX payload (4 + (N+1)*4 bytes)
----------------------------------
* ``count:u32`` — number of keyframes ``N``
* ``entries[0..N]:u32`` — ``N+1`` cumulative markers.
  ``entries[0] = 0``; ``entries[i]`` (for ``i >= 1``) is the *1-based* chunk
  index of the META chunk that terminates keyframe ``i-1``.

META payload (4 + B*4 bytes)
----------------------------
* ``count:u32`` — number of bone transforms referenced (``B`` bones).
* ``refs[0..B-1]:u32`` — 1-based chunk indices of the B BONE chunks that
  belong to this keyframe. Bones are emitted in bone-index order.

BONE payload (56 bytes)
-----------------------
* ``bone_index:u32``
* ``padding:u32`` (always 0)
* ``rotation[9]:f32`` row-major 3x3
* ``translation[3]:f32``
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from pathlib import Path


MAGIC = 0x1234ABCD
VERSION = 8

ANM_CHUNK_KEYFRAME_INDEX = 0x00020001
ANM_CHUNK_KEYFRAME_META = 0x00020003
ANM_CHUNK_BONE_TRANSFORM = 0x00020004


@dataclass
class AnmBoneTransform:
    bone_index: int
    rotation: list[list[float]]
    translation: tuple[float, float, float]


@dataclass
class AnmKeyframe:
    bone_transforms: list[AnmBoneTransform]
    # 1-based chunk index of the META chunk that terminates this keyframe
    # (preserved so byte-exact round-trips can re-emit in the original order).
    meta_chunk_1based: int


@dataclass
class AnmFile:
    keyframes: list[AnmKeyframe]
    entry_count: int
    header_bytes_24_31: bytes = field(default_factory=lambda: b"\x00" * 8)


def parse_anm(path: str | Path) -> AnmFile:
    data = Path(path).read_bytes()
    magic, version = struct.unpack_from("<II", data, 0)
    if magic != MAGIC or version != VERSION:
        raise ValueError(f"{path}: not a 10six .anm file (magic=0x{magic:08X} version={version})")

    entry_count_plus_1, entry_count_bare, zero_a, marker_one = struct.unpack_from("<4I", data, 8)
    if zero_a != 0 or marker_one != 1:
        raise ValueError(f"{path}: unexpected header marker pattern ({zero_a}, {marker_one})")
    if entry_count_plus_1 != entry_count_bare + 1:
        raise ValueError(f"{path}: entry_count mismatch ({entry_count_plus_1} vs {entry_count_bare})")

    entry_count = entry_count_bare
    first_offset = 32 + entry_count * 12
    chunk_table: list[tuple[int, int, int]] = []
    for i in range(entry_count):
        ctype, off, size = struct.unpack_from("<III", data, 32 + i * 12)
        chunk_table.append((ctype, off, size))

    # Real files terminate the chunk table with a `(0, 0, 0)` null sentinel.
    # Accept it silently and otherwise reject unknown trailing garbage.
    while chunk_table and chunk_table[-1] == (0, 0, 0):
        chunk_table.pop()

    if not chunk_table or chunk_table[0][0] != ANM_CHUNK_KEYFRAME_INDEX:
        raise ValueError(f"{path}: expected first chunk to be KF_IDX")

    # --- KF_IDX -----------------------------------------------------------
    _, kf_off, kf_size = chunk_table[0]
    kf_blob = data[kf_off:kf_off + kf_size]
    n_keyframes = struct.unpack_from("<I", kf_blob, 0)[0]
    expected = 4 + (n_keyframes + 1) * 4
    if expected != kf_size:
        raise ValueError(
            f"{path}: KF_IDX size mismatch (count={n_keyframes}, expected {expected} got {kf_size})"
        )
    kf_entries = struct.unpack_from(f"<{n_keyframes + 1}I", kf_blob, 4)
    if kf_entries[0] != 0:
        raise ValueError(f"{path}: KF_IDX[0] expected 0 got {kf_entries[0]}")

    # --- META + BONE -----------------------------------------------------
    keyframes: list[AnmKeyframe] = []
    for kf_i in range(n_keyframes):
        meta_chunk_1based = kf_entries[kf_i + 1]
        meta_chunk_idx = meta_chunk_1based - 1
        if not (0 <= meta_chunk_idx < entry_count):
            raise ValueError(f"{path}: KF_IDX[{kf_i + 1}] points outside chunk table")
        ctype, m_off, m_size = chunk_table[meta_chunk_idx]
        if ctype != ANM_CHUNK_KEYFRAME_META:
            raise ValueError(
                f"{path}: keyframe {kf_i} meta at chunk {meta_chunk_idx} has type 0x{ctype:08X}"
            )
        m_blob = data[m_off:m_off + m_size]
        bone_count = struct.unpack_from("<I", m_blob, 0)[0]
        if 4 + bone_count * 4 != m_size:
            raise ValueError(f"{path}: META size mismatch kf={kf_i}")
        bone_refs = struct.unpack_from(f"<{bone_count}I", m_blob, 4)

        bone_transforms: list[AnmBoneTransform] = []
        for bone_ref_1based in bone_refs:
            b_idx = bone_ref_1based - 1
            if not (0 <= b_idx < entry_count):
                raise ValueError(f"{path}: bone ref out of range in kf {kf_i}")
            b_ctype, b_off, b_size = chunk_table[b_idx]
            if b_ctype != ANM_CHUNK_BONE_TRANSFORM or b_size != 56:
                raise ValueError(
                    f"{path}: kf {kf_i} bone chunk {b_idx} has wrong type/size "
                    f"(0x{b_ctype:08X}, {b_size})"
                )
            b_blob = data[b_off:b_off + b_size]
            bone_index, pad = struct.unpack_from("<II", b_blob, 0)
            floats = struct.unpack_from("<12f", b_blob, 8)
            rotation = [list(floats[0:3]), list(floats[3:6]), list(floats[6:9])]
            translation = (floats[9], floats[10], floats[11])
            bone_transforms.append(
                AnmBoneTransform(bone_index=bone_index, rotation=rotation, translation=translation)
            )

        keyframes.append(
            AnmKeyframe(bone_transforms=bone_transforms, meta_chunk_1based=meta_chunk_1based)
        )

    return AnmFile(
        keyframes=keyframes,
        entry_count=entry_count,
        header_bytes_24_31=bytes(data[24:32]),
    )
