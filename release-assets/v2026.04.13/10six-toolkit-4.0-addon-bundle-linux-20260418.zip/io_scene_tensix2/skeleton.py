from __future__ import annotations

import bpy

from .parser import ParsedMsh


def build_skeleton_placeholder(collection, parsed: ParsedMsh, root_empty=None):
    bone_count = parsed.chunk_type_counts.get("bone", 0)
    if bone_count <= 0:
        return None

    armature_empty = bpy.data.objects.new(f"{parsed.path.stem}_skeleton", None)
    armature_empty.empty_display_type = "SPHERE"
    armature_empty.empty_display_size = 0.6
    armature_empty["tensix_role"] = "skeleton_placeholder"
    armature_empty["tensix_bone_chunk_count"] = bone_count
    if root_empty is not None:
        armature_empty.parent = root_empty
    collection.objects.link(armature_empty)
    return armature_empty
