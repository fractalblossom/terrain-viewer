from __future__ import annotations

import json
import struct
from pathlib import Path


PACK_DIRECTORY_PREFIXES = ("sixpack", "visitor")
PACK_DIRECTORY_INDEXES = range(10)


def _addon_preferences():
    try:
        import bpy
    except Exception:
        return None

    package_name = __package__ or "io_scene_tensix2"
    addon_map = bpy.context.preferences.addons
    if package_name in addon_map:
        return addon_map[package_name].preferences

    short_name = package_name.rsplit(".", 1)[-1]
    if short_name in addon_map:
        return addon_map[short_name].preferences

    for module_name, addon in addon_map.items():
        if module_name == short_name or module_name.endswith(f".{short_name}"):
            return addon.preferences
    return None


def _normalized_existing_path(raw_value: str | None) -> Path | None:
    if not raw_value:
        return None
    candidate = Path(raw_value).expanduser()
    return candidate.resolve() if candidate.exists() else None


def _preferences_path(attribute_name: str) -> Path | None:
    preferences = _addon_preferences()
    if preferences is None:
        return None
    primary = _normalized_existing_path(getattr(preferences, attribute_name, ""))
    if primary is not None:
        return primary
    if attribute_name == "data_root":
        return _normalized_existing_path(getattr(preferences, "sixpack_root", ""))
    return None


def canonical_texture_ref(texture_name: str) -> str:
    normalized = texture_name.replace("\\", "/").strip()
    if "/" in normalized:
        normalized = normalized.rsplit("/", 1)[-1]
    return normalized


def find_smsh_sidecar(msh_path: str | Path) -> Path | None:
    path = Path(msh_path)
    direct = path.with_suffix(".smsh")
    if direct.exists():
        return direct

    parts = list(path.parts)
    try:
        mesh_index = parts.index("mesh")
    except ValueError:
        return None

    candidate_parts = parts[:]
    candidate_parts[mesh_index] = "smsh"
    candidate = Path(*candidate_parts).with_suffix(".smsh")
    if candidate.exists():
        return candidate
    return None


def parse_smsh_strings(smsh_path: str | Path) -> dict:
    path = Path(smsh_path)
    data = path.read_bytes()
    ascii_blob = "".join(chr(byte) if 32 <= byte <= 126 else "\x00" for byte in data)
    strings = [value for value in ascii_blob.split("\x00") if len(value) >= 3]
    return {
        "file": path.name,
        "size": len(data),
        "first_u32_be": struct.unpack_from(">I", data, 0)[0] if len(data) >= 4 else None,
        "first_u32_le": struct.unpack_from("<I", data, 0)[0] if len(data) >= 4 else None,
        "contains_smsh": "SMSH" in strings,
        "strings": strings[:12],
    }


def find_decoded_root(path_like: str | Path) -> Path | None:
    path = Path(path_like).resolve()
    for parent in (path, *path.parents):
        if parent.name == "decoded_10six":
            return parent
    return None


def _pack_directory_names() -> list[str]:
    return [f"{prefix}{index}" for prefix in PACK_DIRECTORY_PREFIXES for index in PACK_DIRECTORY_INDEXES]


def _has_supported_pack_directories(root: Path) -> bool:
    return any((root / directory_name).exists() for directory_name in _pack_directory_names())


def find_data_root(path_like: str | Path) -> Path | None:
    explicit_root = _preferences_path("data_root")
    if explicit_root is not None:
        return explicit_root

    path = Path(path_like).resolve()
    candidates = [path] + list(path.parents)
    for candidate in candidates:
        if _has_supported_pack_directories(candidate):
            return candidate
    return None


def find_sixpack_root(path_like: str | Path) -> Path | None:
    return find_data_root(path_like)


def _local_texture_roots(msh_path: str | Path) -> list[Path]:
    path = Path(msh_path).resolve()
    candidates = [
        path.parent / f"{path.stem}_textures",
        path.parent / "textures",
    ]
    return [candidate for candidate in candidates if candidate.exists() and candidate.is_dir()]


def find_texture_root(msh_path: str | Path) -> Path | None:
    local_roots = _local_texture_roots(msh_path)
    if local_roots:
        return local_roots[0]

    explicit_texture_root = _preferences_path("texture_root_override")
    if explicit_texture_root is not None:
        return explicit_texture_root

    data_root = find_data_root(msh_path)
    if data_root is None:
        decoded_root = find_decoded_root(msh_path)
        data_root = decoded_root
    if data_root is None:
        return None
    for directory_name in _pack_directory_names():
        candidate = data_root / directory_name / "files" / "bmp"
        if candidate.exists():
            return candidate
    return None


def iter_texture_roots(msh_path: str | Path) -> list[Path]:
    roots: list[Path] = []
    seen: set[Path] = set()

    for candidate in _local_texture_roots(msh_path):
        resolved = candidate.resolve()
        if resolved not in seen:
            roots.append(resolved)
            seen.add(resolved)

    explicit_texture_root = _preferences_path("texture_root_override")
    if explicit_texture_root is not None:
        resolved = explicit_texture_root.resolve()
        if resolved not in seen:
            roots.append(resolved)
            seen.add(resolved)

    data_root = find_data_root(msh_path)
    if data_root is None:
        data_root = find_decoded_root(msh_path)
    if data_root is not None:
        for directory_name in _pack_directory_names():
            candidate = data_root / directory_name / "files" / "bmp"
            if not candidate.exists():
                continue
            resolved = candidate.resolve()
            if resolved not in seen:
                roots.append(resolved)
                seen.add(resolved)

    return roots


def load_texture_aliases(msh_path: str | Path) -> dict[str, str]:
    explicit_alias_file = _preferences_path("alias_file_override")
    if explicit_alias_file is not None and explicit_alias_file.is_file():
        alias_file = explicit_alias_file
    else:
        decoded_root = find_decoded_root(msh_path)
        if decoded_root is None:
            return {}
        alias_file = decoded_root / "pipeline" / "texture_aliases.json"
    if not alias_file.exists():
        return {}
    try:
        raw = json.loads(alias_file.read_text(encoding="utf-8"))
    except Exception:
        return {}
    if not isinstance(raw, dict):
        return {}
    aliases: dict[str, str] = {}
    for key, value in raw.items():
        if not isinstance(key, str) or not isinstance(value, str):
            continue
        aliases[canonical_texture_ref(key).lower()] = canonical_texture_ref(value)
    return aliases


def build_texture_lookup(msh_path: str | Path) -> dict[str, Path]:
    texture_roots = iter_texture_roots(msh_path)
    if not texture_roots:
        return {}
    lookup: dict[str, Path] = {}
    for texture_root in texture_roots:
        for texture_path in texture_root.glob("*.*"):
            if not texture_path.is_file():
                continue
            lower_name = texture_path.name.lower()
            lookup.setdefault(lower_name, texture_path)
            lookup.setdefault(f"bmp/{lower_name}", texture_path)
    return lookup


def resolve_texture_path(texture_name: str | None, msh_path: str | Path) -> Path | None:
    if not texture_name:
        return None
    lookup = build_texture_lookup(msh_path)
    aliases = load_texture_aliases(msh_path)
    normalized = canonical_texture_ref(texture_name).lower()
    direct = lookup.get(normalized)
    if direct:
        return direct
    alias_target = aliases.get(normalized)
    if alias_target:
        return lookup.get(alias_target.lower())
    return None
