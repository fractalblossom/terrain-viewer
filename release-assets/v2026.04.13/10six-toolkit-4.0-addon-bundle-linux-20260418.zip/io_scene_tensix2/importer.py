from __future__ import annotations

from pathlib import Path

import bpy

from .animation import collect_animation_notes
from .debug import build_import_report
from .mesh_builder import build_asset_collection
from .metadata import find_smsh_sidecar, parse_smsh_strings
from .parser import parse_msh
from .skeleton import build_skeleton_placeholder


def import_msh_file(
    context,
    filepath: str,
    find_smsh: bool,
    create_debug_empties: bool,
    write_text_report: bool,
    report,
):
    try:
        parsed = parse_msh(filepath)
    except Exception as exc:
        report({"ERROR"}, f"10six import failed: {exc}")
        return {"CANCELLED"}

    smsh_info = None
    if find_smsh:
        smsh_path = find_smsh_sidecar(filepath)
        if smsh_path:
            parsed.smsh_path = Path(smsh_path)
            smsh_info = parse_smsh_strings(smsh_path)

    collection, root_empty = build_asset_collection(context, parsed, create_debug_empties=create_debug_empties)
    skeleton_placeholder = build_skeleton_placeholder(collection, parsed, root_empty=root_empty)

    if parsed.smsh_path:
        collection["tensix_source_smsh"] = str(parsed.smsh_path)
    if skeleton_placeholder is not None:
        collection["tensix_has_skeleton_placeholder"] = True

    notes = collect_animation_notes(parsed)
    for index, note in enumerate(notes):
        collection[f"note_{index:02d}"] = note

    if write_text_report:
        text_name = f"10six_{parsed.path.stem}_report.txt"
        text_block = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
        text_block.clear()
        text_block.write(build_import_report(parsed, smsh_info=smsh_info))

    report(
        {"INFO"},
        f"Imported {parsed.path.name}: {len(parsed.parts)} parts, {len(parsed.chunks)} chunks",
    )
    return {"FINISHED"}
