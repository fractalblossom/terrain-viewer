from __future__ import annotations

import json
from pathlib import Path

import bpy

from .metadata import canonical_texture_ref, resolve_texture_path
from .parser import MeshPart, ParsedMsh


def _flatten_matrix(matrix: list[list[float]] | None) -> list[float]:
    if matrix is None:
        return [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]
    return [matrix[row][col] for row in range(3) for col in range(3)]


def _is_marker_part(part: MeshPart) -> bool:
    return len(part.faces) <= 1 and 0 < len(part.vertices) <= 3


def _find_or_create_material(texture_name: str | None, msh_path: Path):
    stem = Path(canonical_texture_ref(texture_name or "NoTexture")).stem or "NoTexture"
    material_name = f"TenSix_{stem}"
    material = bpy.data.materials.get(material_name)
    if material is None:
        material = bpy.data.materials.new(material_name)
        material.use_nodes = True

    node_tree = material.node_tree
    if node_tree is None:
        return material

    principled = node_tree.nodes.get("Principled BSDF")
    output = node_tree.nodes.get("Material Output")
    if principled is None or output is None:
        return material

    texture_path = resolve_texture_path(texture_name, msh_path)
    if texture_path and texture_path.exists():
        image_node_name = f"10sixImage_{stem}"
        image_node = node_tree.nodes.get(image_node_name)
        if image_node is None:
            image_node = node_tree.nodes.new("ShaderNodeTexImage")
            image_node.name = image_node_name
            image_node.label = image_node_name
            image_node.location = (-320, 280)
        image_node.image = bpy.data.images.load(str(texture_path), check_existing=True)
        if not any(link.from_node == image_node and link.to_node == principled for link in node_tree.links):
            node_tree.links.new(image_node.outputs["Color"], principled.inputs["Base Color"])

    return material


def _tag_common_object_metadata(obj, parsed: ParsedMsh, part: MeshPart, role: str) -> None:
    obj["tensix_source_msh"] = str(parsed.path)
    obj["tensix_vertex_chunk_index"] = part.vertex_chunk_index
    obj["tensix_face_chunk_index"] = part.face_chunk_index if part.face_chunk_index is not None else -1
    obj["tensix_face_chunk_type"] = part.face_chunk_type if part.face_chunk_type is not None else -1
    obj["tensix_vertex_count"] = len(part.vertices)
    obj["tensix_face_count"] = len(part.faces)
    obj["tensix_role"] = role
    obj["tensix_material_textures_json"] = json.dumps(part.material_textures)
    obj["tensix_world_matrix_json"] = json.dumps(_flatten_matrix(part.world_matrix))
    obj["tensix_world_translation_json"] = json.dumps(list(part.world_translation))


def _create_marker_empty(collection, root_empty, parsed: ParsedMsh, part: MeshPart):
    centroid = (
        sum(vertex[0] for vertex in part.vertices) / len(part.vertices),
        sum(vertex[1] for vertex in part.vertices) / len(part.vertices),
        sum(vertex[2] for vertex in part.vertices) / len(part.vertices),
    )
    empty = bpy.data.objects.new(part.name, None)
    empty.empty_display_type = "ARROWS"
    empty.empty_display_size = 0.5
    empty.location = centroid
    empty.parent = root_empty
    empty["tensix_marker_type"] = "possible_mount"
    _tag_common_object_metadata(empty, parsed, part, role="possible_mount")
    collection.objects.link(empty)
    return empty


def _create_mesh_object(collection, root_empty, parsed: ParsedMsh, part: MeshPart):
    mesh = bpy.data.meshes.new(part.name)
    mesh.from_pydata(part.vertices, [], part.faces)
    mesh.update()

    uv_layer = mesh.uv_layers.new(name="UVMap")
    for polygon_index, polygon in enumerate(mesh.polygons):
        if polygon_index < len(part.face_material_indices):
            polygon.material_index = part.face_material_indices[polygon_index]
        if uv_layer is not None and polygon_index < len(part.face_uvs):
            face_uv = part.face_uvs[polygon_index]
            for loop_offset in range(min(polygon.loop_total, 3)):
                uv_layer.data[polygon.loop_start + loop_offset].uv = face_uv[loop_offset]

    slot_count = max([0] + part.face_material_indices) + 1 if part.face_material_indices else max(1, len(part.material_textures))
    for material_index in range(slot_count):
        texture_name = part.material_textures[material_index] if material_index < len(part.material_textures) else None
        mesh.materials.append(_find_or_create_material(texture_name, parsed.path))

    obj = bpy.data.objects.new(part.name, mesh)
    obj.parent = root_empty
    _tag_common_object_metadata(obj, parsed, part, role="mesh_part")
    collection.objects.link(obj)
    return obj


def build_asset_collection(context, parsed: ParsedMsh, create_debug_empties: bool = True):
    root_name = f"10six_{parsed.path.stem}"
    collection = bpy.data.collections.new(root_name)
    context.scene.collection.children.link(collection)

    collection["tensix_source_msh"] = str(parsed.path)
    collection["tensix_version"] = parsed.version
    collection["tensix_chunk_count"] = len(parsed.chunks)
    collection["tensix_named_vertex_chunks"] = len(parsed.named_vertex_chunks)

    for key, value in parsed.chunk_type_counts.items():
        collection[f"chunk_{key}"] = value

    root_empty = bpy.data.objects.new(root_name, None)
    root_empty.empty_display_type = "PLAIN_AXES"
    root_empty.empty_display_size = 1.0
    root_empty["tensix_asset_root"] = True
    root_empty["tensix_source_msh"] = str(parsed.path)
    collection.objects.link(root_empty)

    for part in parsed.parts:
        if _is_marker_part(part):
            _create_marker_empty(collection, root_empty, parsed, part)
        elif create_debug_empties or part.faces:
            _create_mesh_object(collection, root_empty, parsed, part)

    for obj in context.selected_objects:
        obj.select_set(False)
    root_empty.select_set(True)
    context.view_layer.objects.active = root_empty
    return collection, root_empty
