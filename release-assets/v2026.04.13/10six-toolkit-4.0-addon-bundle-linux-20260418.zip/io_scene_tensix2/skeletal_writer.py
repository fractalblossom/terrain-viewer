from __future__ import annotations

import struct
from dataclasses import dataclass, field

from .msh_writer import (
    HEADER_CHUNK,
    INDEX_CHUNK,
    NAME_CHUNK,
    ChunkSpec,
    FaceRecord,
    _pack_face_chunk,
    _pack_header_chunk,
    _pack_index_chunk,
    _pack_material_chunk,
    _pack_name_chunk,
    _pack_vertex_chunk,
    assemble_container,
)


MAGIC = 0x1234ABCD
VERSION = 8

MESH_CHUNK_BONE = 0x00010002
MESH_CHUNK_VERTEX = 0x00010003
MESH_CHUNK_FACES = 0x00010008
MESH_CHUNK_MATERIAL = 0x00010009


@dataclass
class SkeletalMeshPart:
    name: str
    vertices: list[tuple[float, float, float]] = field(default_factory=list)
    vertex_uvs: list[tuple[float, float]] = field(default_factory=list)
    material_textures: list[str] = field(default_factory=list)
    faces: list[FaceRecord] = field(default_factory=list)


@dataclass
class SkeletalBoneRecord:
    name: str
    parent_name: str | None
    local_matrix: list[list[float]]
    pivot: tuple[float, float, float]
    mesh_part: SkeletalMeshPart | None = None
    # When False, no NAME chunk is emitted before this bone (matches the
    # original pv_plugin output for anonymous/intermediate bones). When None
    # (default), the writer treats it as "emit NAME iff name is non-empty and
    # does not look like a synthetic ``__unnamed_*`` marker".
    emit_name: bool | None = None


@dataclass
class _GeometryPlan:
    record: SkeletalBoneRecord
    part: SkeletalMeshPart
    vertex_chunk_index: int
    material_chunk_index: int | None
    face_chunk_index: int | None


@dataclass
class _BonePlan:
    record: SkeletalBoneRecord
    chunk_index: int
    geometry: _GeometryPlan
    # 1-based chunk indices of direct child BONE chunks, in DFS-emit order.
    child_chunk_indices: list[int]
    # 1-based chunk index of this bone's preceding NAME chunk, or 0 if no
    # NAME chunk was emitted for this bone.
    name_chunk_index_one_based: int = 0


def _dummy_part(name: str) -> SkeletalMeshPart:
    return SkeletalMeshPart(name=name, vertices=[(0.0, 0.0, 0.0)], vertex_uvs=[(0.0, 0.0)], material_textures=[], faces=[])


def _children_by_parent(records: list[SkeletalBoneRecord]) -> dict[str | None, list[SkeletalBoneRecord]]:
    by_parent: dict[str | None, list[SkeletalBoneRecord]] = {}
    for record in records:
        by_parent.setdefault(record.parent_name, []).append(record)
    return by_parent


def _postorder(records: list[SkeletalBoneRecord]) -> list[SkeletalBoneRecord]:
    by_parent = _children_by_parent(records)

    result: list[SkeletalBoneRecord] = []

    def _walk(parent_name: str | None) -> None:
        for child in by_parent.get(parent_name, []):
            _walk(child.name)
            result.append(child)

    _walk(None)
    return result


def _preorder(records: list[SkeletalBoneRecord]) -> list[SkeletalBoneRecord]:
    by_parent = _children_by_parent(records)
    result: list[SkeletalBoneRecord] = []

    def _walk(parent_name: str | None) -> None:
        for child in by_parent.get(parent_name, []):
            result.append(child)
            _walk(child.name)

    _walk(None)
    return result


def _pack_bone_chunk(plan: _BonePlan) -> bytes:
    """Pack a MESH_CHUNK_BONE (0x00010002) payload.

    Byte layout (derived from real 10six `.msh` files, e.g. abo_6.msh, a_shadow.msh):
      0   u32  vertex_count
      4   u32  vertex_chunk_index + 1     (1-indexed; 0 means "no geometry")
      8   u32  face_count
      12  u32  face_chunk_index + 1
      16  u32  material_count             (NOT a constant 1; matches material chunk count)
      20  u32  material_chunk_index + 1
      24  u32  child_bone_count
      28  3x(4 floats)  local 3x3 rotation/scale matrix, row-major, each row
                        padded with a trailing 0.0 to 16 bytes (48 bytes total)
      76  3 floats      pivot / attachment offset in parent space
      88  float         constant 1.0 flag
      92  12 floats     rest-pose identity matrix 3x4 (row-major; always identity)
      140 4 floats      (0.0, 0.0, 0.0, 1.0)  — verified across real files
      156 u32 * N       1-based chunk indices of direct child BONE chunks
      ... u32           1-based chunk index of own NAME chunk (0 if no NAME chunk)
    Total tail length = (child_count + 1) * 4 bytes after offset 156.
    """
    record = plan.record
    part = plan.geometry.part
    face_count = len(part.faces)
    face_ref = plan.geometry.face_chunk_index + 1 if plan.geometry.face_chunk_index is not None else 0
    material_ref = plan.geometry.material_chunk_index + 1 if plan.geometry.material_chunk_index is not None else 0
    # Real files set bytes 16-19 to the number of materials (textures) in the
    # referenced MATERIAL chunk. Leaf bones whose part has one texture get 1;
    # bones whose part has multiple textures get the actual count.
    material_count = max(1, len(part.material_textures) if part.material_textures else 1)

    blob = bytearray()
    blob.extend(
        struct.pack(
            "<6I",
            len(part.vertices),
            plan.geometry.vertex_chunk_index + 1,
            face_count,
            face_ref,
            material_count,
            material_ref,
        )
    )
    blob.extend(struct.pack("<I", len(plan.child_chunk_indices)))
    for row in range(3):
        matrix_row = record.local_matrix[row]
        blob.extend(struct.pack("<4f", float(matrix_row[0]), float(matrix_row[1]), float(matrix_row[2]), 0.0))
    blob.extend(struct.pack("<3f", float(record.pivot[0]), float(record.pivot[1]), float(record.pivot[2])))
    blob.extend(struct.pack("<f", 1.0))
    blob.extend(struct.pack("<12f", 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0))
    # bytes 140-155: 4 floats (0, 0, 0, 1.0). The trailing 1.0 is constant in
    # all observed real .msh files.
    blob.extend(struct.pack("<4f", 0.0, 0.0, 0.0, 1.0))
    # bytes 156+: 1-based chunk indices of direct child BONE chunks, then a
    # final u32 = 1-based chunk index of this bone's own NAME chunk (0 if no
    # NAME chunk was emitted). Verified against placeholder.msh, gtoxbom2.msh.
    for child_chunk_index in plan.child_chunk_indices:
        blob.extend(struct.pack("<I", int(child_chunk_index)))
    blob.extend(struct.pack("<I", int(plan.name_chunk_index_one_based)))
    return bytes(blob)


def build_skeletal_msh(records: list[SkeletalBoneRecord], *, emit_names_for_all: bool = False) -> bytes:
    """Serialize a skeletal/rigid MSH container.

    Real 10six `.msh` files (verified against abo_6.msh, a_shadow.msh, etc.) use
    a recursive DFS emission order rather than "all-geometry-first, all-bones-last".
    For each bone we emit:
        1. VERTEX chunk for this bone
        2. MATERIAL chunk for this bone (if geometry present)
        3. FACES chunk for this bone (if geometry present)
        4. Recurse into each child subtree in order
        5. NAME chunk (only if the bone is named and ``emit_names_for_all`` or the
           bone was imported with an explicit name slot)
        6. BONE chunk (payload filled after all indices are known)

    Setting ``emit_names_for_all=True`` forces a NAME chunk before every bone;
    this mirrors the Blender 3.1 behaviour but is NOT what the original 3ds Max
    pv_plugin produced. The default (False) only emits NAME chunks for bones
    whose record carries a non-empty ``name``.
    """
    if not records:
        raise ValueError("No skeletal bone records were provided")

    by_parent = _children_by_parent(records)
    roots = by_parent.get(None, [])
    if not roots:
        raise ValueError("No root bone (parent=None) was provided")

    specs: list[ChunkSpec] = [
        ChunkSpec(HEADER_CHUNK, b""),
        ChunkSpec(INDEX_CHUNK, _pack_index_chunk()),
    ]
    geometry_by_name: dict[str, _GeometryPlan] = {}
    bone_chunk_indices: dict[str, int] = {}
    bone_name_has_chunk: dict[str, bool] = {}
    bone_name_chunk_index: dict[str, int] = {}

    def _emit_subtree(record: SkeletalBoneRecord) -> None:
        part = record.mesh_part or _dummy_part(record.name)
        vertex_chunk_index = len(specs)
        specs.append(ChunkSpec(MESH_CHUNK_VERTEX, _pack_vertex_chunk(part)))

        material_chunk_index: int | None = None
        face_chunk_index: int | None = None
        if part.faces:
            material_chunk_index = len(specs)
            specs.append(ChunkSpec(MESH_CHUNK_MATERIAL, _pack_material_chunk(part)))
            face_chunk_index = len(specs)
            specs.append(ChunkSpec(MESH_CHUNK_FACES, _pack_face_chunk(part, material_chunk_index, face_chunk_index)))

        geometry_by_name[record.name] = _GeometryPlan(
            record=record,
            part=part,
            vertex_chunk_index=vertex_chunk_index,
            material_chunk_index=material_chunk_index,
            face_chunk_index=face_chunk_index,
        )

        for child in by_parent.get(record.name, []):
            _emit_subtree(child)

        emit_name = record.emit_name
        if emit_name is None:
            emit_name = bool(record.name) and not record.name.startswith("__unnamed_")
        if emit_names_for_all:
            emit_name = bool(record.name) and not record.name.startswith("__unnamed_")

        if emit_name:
            name_chunk_index = len(specs)
            specs.append(ChunkSpec(NAME_CHUNK, _pack_name_chunk(record.name)))
            bone_name_has_chunk[record.name] = True
            bone_name_chunk_index[record.name] = name_chunk_index
        else:
            bone_name_has_chunk[record.name] = False
            bone_name_chunk_index[record.name] = -1

        bone_chunk_indices[record.name] = len(specs)
        specs.append(ChunkSpec(MESH_CHUNK_BONE, b""))

    for root in roots:
        _emit_subtree(root)

    # Postorder walk to build bone-chunk payloads now that all indices are known.
    plans: list[_BonePlan] = []
    postorder_records = _postorder(records)
    for record in postorder_records:
        name_idx = bone_name_chunk_index.get(record.name, -1)
        plans.append(
            _BonePlan(
                record=record,
                chunk_index=bone_chunk_indices[record.name],
                geometry=geometry_by_name[record.name],
                # 1-based: real files store "chunk_index + 1" in the bone tail.
                child_chunk_indices=[bone_chunk_indices[child.name] + 1 for child in by_parent.get(record.name, [])],
                name_chunk_index_one_based=(name_idx + 1) if name_idx >= 0 else 0,
            )
        )

    for plan in plans:
        specs[plan.chunk_index].data = _pack_bone_chunk(plan)

    # Header chunk counters match real files: bone_count = number of bones in the
    # skeleton, chunk_count = total number of emitted chunks (including HEADER).
    specs[0].data = _pack_header_chunk(len(postorder_records), len(specs))
    return assemble_container(specs)