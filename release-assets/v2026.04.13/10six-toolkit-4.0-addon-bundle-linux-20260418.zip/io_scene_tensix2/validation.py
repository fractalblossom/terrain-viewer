from __future__ import annotations

from dataclasses import dataclass, field

import bpy

from .parser import MeshPart, ParsedMsh, parse_msh


@dataclass
class ValidationResult:
    source_path: str
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    object_count: int = 0


def find_asset_root(obj):
    current = obj
    while current is not None:
        if bool(current.get("tensix_asset_root")):
            return current
        current = current.parent
    return None


def _gather_descendants(root):
    result = []
    stack = [root]
    while stack:
        current = stack.pop()
        result.append(current)
        stack.extend(list(current.children))
    return result


def _validate_mesh_object(obj, part: MeshPart, result: ValidationResult) -> None:
    if obj.modifiers:
        result.errors.append(f"{obj.name}: modifiers are not supported in round-trip export yet")
    mesh = obj.data
    if mesh is None:
        result.errors.append(f"{obj.name}: missing mesh data")
        return
    if mesh.shape_keys is not None:
        result.errors.append(f"{obj.name}: shape keys are not supported in round-trip export yet")
    if len(mesh.vertices) != len(part.vertices):
        result.errors.append(
            f"{obj.name}: vertex count changed from {len(part.vertices)} to {len(mesh.vertices)}"
        )
    if any(polygon.loop_total != 3 for polygon in mesh.polygons):
        result.errors.append(f"{obj.name}: only triangle polygons are supported for round-trip export")
    mesh.calc_loop_triangles()
    if len(mesh.loop_triangles) != len(part.faces):
        result.errors.append(
            f"{obj.name}: triangle count changed from {len(part.faces)} to {len(mesh.loop_triangles)}"
        )
    if len(mesh.polygons) != len(part.faces):
        result.errors.append(
            f"{obj.name}: polygon count changed from {len(part.faces)} to {len(mesh.polygons)}"
        )
    current_faces = [tuple(polygon.vertices) for polygon in mesh.polygons]
    if current_faces != part.faces:
        result.errors.append(f"{obj.name}: polygon connectivity changed; topology edits are not supported yet")
    if not mesh.uv_layers:
        result.errors.append(f"{obj.name}: missing UV layer")
    required_slots = max([0] + part.face_material_indices) + 1 if part.face_material_indices else max(1, len(part.material_textures))
    if len(mesh.materials) < required_slots:
        result.errors.append(f"{obj.name}: material slot count is lower than the imported source layout")
    for polygon_index, polygon in enumerate(mesh.polygons):
        if polygon_index < len(part.face_material_indices) and polygon.material_index != part.face_material_indices[polygon_index]:
            result.errors.append(f"{obj.name}: material assignment changed on polygon {polygon_index}")


def validate_roundtrip_root(root) -> tuple[ValidationResult, ParsedMsh | None]:
    source_path = root.get("tensix_source_msh")
    result = ValidationResult(source_path=str(source_path or ""))
    if not source_path:
        result.errors.append("Selected asset has no recorded source .msh path")
        return result, None

    try:
        parsed = parse_msh(source_path)
    except Exception as exc:
        result.errors.append(f"Unable to parse source .msh: {exc}")
        return result, None

    part_map = {part.vertex_chunk_index: part for part in parsed.parts}
    asset_objects = [obj for obj in _gather_descendants(root) if obj is not root]
    result.object_count = len(asset_objects)

    seen_chunks: set[int] = set()
    for obj in asset_objects:
        vertex_chunk_index = obj.get("tensix_vertex_chunk_index")
        if vertex_chunk_index is None:
            continue
        if vertex_chunk_index not in part_map:
            result.errors.append(f"{obj.name}: source vertex chunk {vertex_chunk_index} no longer exists in the source file")
            continue
        seen_chunks.add(int(vertex_chunk_index))
        part = part_map[int(vertex_chunk_index)]
        role = obj.get("tensix_role", "")
        if role == "mesh_part":
            if obj.type != "MESH":
                result.errors.append(f"{obj.name}: expected a mesh object for round-trip export")
                continue
            _validate_mesh_object(obj, part, result)
        elif role == "possible_mount":
            if obj.type != "EMPTY":
                result.errors.append(f"{obj.name}: expected an empty object for a mount marker")
        elif role == "skeleton_placeholder":
            result.warnings.append(f"{obj.name}: skeleton placeholder is informational only and is not exported yet")

    missing_parts = [part.name for part in parsed.parts if part.vertex_chunk_index not in seen_chunks]
    if missing_parts:
        result.warnings.append(f"Unrepresented source parts: {', '.join(missing_parts[:12])}")
    return result, parsed


def build_validation_report(result: ValidationResult) -> str:
    lines = [f"10six validation report for: {result.source_path or '<unknown>'}"]
    lines.append(f"objects considered: {result.object_count}")
    lines.append("")
    lines.append("errors:")
    if result.errors:
        for error in result.errors:
            lines.append(f"- {error}")
    else:
        lines.append("- none")
    lines.append("")
    lines.append("warnings:")
    if result.warnings:
        for warning in result.warnings:
            lines.append(f"- {warning}")
    else:
        lines.append("- none")
    return "\n".join(lines) + "\n"


def write_validation_text(result: ValidationResult):
    text_name = "10six_validation_report.txt"
    text_block = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
    text_block.clear()
    text_block.write(build_validation_report(result))
    return text_block