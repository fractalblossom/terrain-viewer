from __future__ import annotations

import struct
from dataclasses import dataclass

MAGIC = 0x1234ABCD
VERSION = 8

HEADER_CHUNK = 0x00010001
INDEX_CHUNK = 0x00010007
NAME_CHUNK = 0x00000003
MESH_CHUNK_VERTEX = 0x00010003
MESH_CHUNK_FACES = 0x00010008
MESH_CHUNK_MATERIAL = 0x00010009


@dataclass
class FaceRecord:
    indices: tuple[int, int, int]
    material_index: int
    uvs: tuple[tuple[float, float], tuple[float, float], tuple[float, float]]


@dataclass
class StaticMeshPart:
    name: str
    vertices: list[tuple[float, float, float]]
    vertex_uvs: list[tuple[float, float]]
    material_textures: list[str]
    faces: list[FaceRecord]


@dataclass
class ChunkSpec:
    chunk_type: int
    data: bytes


def _safe_ascii(value: str, fallback: str) -> str:
    cleaned = value.encode("ascii", errors="ignore").decode("ascii").strip()
    return cleaned or fallback


def _pack_name_chunk(name: str) -> bytes:
    return _safe_ascii(name, "part").encode("ascii") + b"\x00"


def _pack_vertex_chunk(part: StaticMeshPart) -> bytes:
    blob = bytearray()
    blob.extend(struct.pack("<I", len(part.vertices)))
    for index, (x, y, z) in enumerate(part.vertices):
        if index < len(part.vertex_uvs):
            u, v = part.vertex_uvs[index]
        else:
            u, v = 0.0, 0.0
        blob.extend(struct.pack("<5f", float(x), float(y), float(z), float(u), float(v)))
    return bytes(blob)


def _pack_material_record(texture_name: str) -> bytes:
    safe_name = _safe_ascii(texture_name, "NoTexture.bmp")
    encoded = safe_name.encode("ascii")[:35]
    return struct.pack("<7f", 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0) + encoded + b"\x00" + (b"\x00" * (36 - len(encoded) - 1))


def _pack_material_chunk(part: StaticMeshPart) -> bytes:
    textures = part.material_textures or ["NoTexture.bmp"]
    blob = bytearray(struct.pack("<I", len(textures)))
    for texture_name in textures:
        blob.extend(_pack_material_record(texture_name))
    return bytes(blob)


def _pack_face_chunk(part: StaticMeshPart, material_chunk_index: int, face_chunk_index: int) -> bytes:
    blob = bytearray(struct.pack("<III", len(part.faces), int(material_chunk_index), int(face_chunk_index)))
    for face in part.faces:
        i0, i1, i2 = face.indices
        mat_index = max(0, int(face.material_index))
        (u0, v0), (u1, v1), (u2, v2) = face.uvs
        blob.extend(
            struct.pack(
                "<7I8f",
                3,
                int(i0),
                int(i1),
                int(i2),
                0,
                mat_index,
                1,
                float(u0),
                float(u1),
                float(u2),
                0.0,
                float(v0),
                float(v1),
                float(v2),
                0.0,
            )
        )
    return bytes(blob)


def _pack_header_chunk(bone_count: int, nonzero_chunk_count: int) -> bytes:
    return struct.pack("<2I", int(bone_count), int(nonzero_chunk_count))


def _pack_index_chunk() -> bytes:
    return struct.pack("<3I", 0, 1, 2)


def assemble_container(chunks: list[ChunkSpec]) -> bytes:
    """Assemble the full .msh container.

    The 32-byte container header layout derived from real 10six files is:
      bytes  0-3  magic    (0x1234ABCD)
      bytes  4-7  version  (8)
      bytes  8-11 u32      entry_count + 1  (size of chunk table in slots, +1)
      bytes 12-15 u32      chunk_count  + 1  (non-null chunks + 1)
      bytes 16-19 u32      0
      bytes 20-23 u32      1   (constant marker)
      bytes 24-27 u32      0
      bytes 28-31 u32      0
    The chunk table immediately follows the 32-byte header; real files sometimes
    pad the table with zero entries, but the game also accepts a tight table
    with entry_count == chunk_count as long as the counters in bytes 8-15 are
    consistent.
    """
    entry_count = len(chunks)
    chunk_count = len(chunks)
    first_offset = 32 + entry_count * 12
    header = struct.pack(
        "<8I",
        MAGIC,
        VERSION,
        entry_count + 1,
        chunk_count + 1,
        0,
        1,
        0,
        0,
    )

    table = bytearray()
    payload = bytearray()
    offset = first_offset
    for chunk in chunks:
        table.extend(struct.pack("<III", chunk.chunk_type, offset, len(chunk.data)))
        payload.extend(chunk.data)
        offset += len(chunk.data)

    return header + bytes(table) + bytes(payload)


def build_static_msh(parts: list[StaticMeshPart]) -> bytes:
    chunks: list[ChunkSpec] = [
        ChunkSpec(HEADER_CHUNK, b""),
        ChunkSpec(INDEX_CHUNK, _pack_index_chunk()),
    ]
    for part in parts:
        if not part.vertices or not part.faces:
            continue
        vertex_chunk_index = len(chunks)
        material_chunk_index = vertex_chunk_index + 1
        face_chunk_index = vertex_chunk_index + 2
        chunks.append(ChunkSpec(MESH_CHUNK_VERTEX, _pack_vertex_chunk(part)))
        chunks.append(ChunkSpec(MESH_CHUNK_MATERIAL, _pack_material_chunk(part)))
        chunks.append(ChunkSpec(MESH_CHUNK_FACES, _pack_face_chunk(part, material_chunk_index, face_chunk_index)))
        chunks.append(ChunkSpec(NAME_CHUNK, _pack_name_chunk(part.name)))
    if len(chunks) <= 2:
        raise ValueError("No mesh data was available to serialize")
    bone_count = 0
    chunks[0].data = _pack_header_chunk(bone_count, len(chunks))
    return assemble_container(chunks)
