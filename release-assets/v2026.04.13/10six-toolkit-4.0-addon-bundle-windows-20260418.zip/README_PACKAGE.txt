10six Toolkit 4.0 addon bundle for installed Blender

Contents:
- io_scene_tensix2 addon folder
- io_scene_tensix2.zip for manual install through Blender Preferences
- First-run helper script
- Documentation and install scripts

Artist quick start:
1. Unzip this package anywhere on a Windows x64 machine.
2. If you want an automated install, run support/install_me_first.bat.
3. Or install io_scene_tensix2.zip through Blender Preferences > Add-ons > Install.
4. Launch Blender.
5. Set 10six Data Root to the parent folder that contains your original 10six data folders.
6. For foreign assets, build one rooted hierarchy before exporting to .msh.

Notes:
- This package assumes Blender is already installed on the machine.
- This package does not include original 10six game data.
- Use io_scene_tensix2.zip in Blender's installer, not the unpacked addon folder.
- If you install by copying files manually, copy only the inner io_scene_tensix2 folder into Blender's addons directory, not the extracted bundle folder.
- Helper scripts, docs, and the startup helper are bundled under support/.
