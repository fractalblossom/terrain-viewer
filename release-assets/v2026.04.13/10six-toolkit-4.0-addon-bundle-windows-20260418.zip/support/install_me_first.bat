@echo off
setlocal

set SCRIPT_DIR=%~dp0
powershell -ExecutionPolicy Bypass -File "%SCRIPT_DIR%install_into_user_blender.ps1"

if errorlevel 1 (
  echo.
  echo 10six install failed.
  pause
  exit /b 1
)

echo.
echo 10six install completed.
echo Launch Blender next.
pause