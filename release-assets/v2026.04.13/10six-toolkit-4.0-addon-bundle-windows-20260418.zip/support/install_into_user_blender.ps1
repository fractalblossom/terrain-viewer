param(
    [Parameter(Mandatory = $false)]
    [string]$BlenderVersion = "5.1",

    [Parameter(Mandatory = $false)]
    [string]$AddonZip = "..\io_scene_tensix2.zip",

    [Parameter(Mandatory = $false)]
    [string]$AddonFolder = "..\io_scene_tensix2",

    [Parameter(Mandatory = $false)]
    [string]$StartupHelperScript = ".\tensix_first_run_startup.py"
)

$ErrorActionPreference = "Stop"

function Resolve-InstallerPath {
    param([string]$Candidate)

    if ([System.IO.Path]::IsPathRooted($Candidate)) {
        return $Candidate
    }
    return (Join-Path $PSScriptRoot $Candidate)
}

$userScriptsRoot = Join-Path $env:APPDATA "Blender Foundation\Blender\$BlenderVersion\scripts"
$userAddonsRoot = Join-Path $userScriptsRoot "addons"
$userStartupRoot = Join-Path $userScriptsRoot "startup"
$targetAddon = Join-Path $userAddonsRoot "io_scene_tensix2"
$targetStartupScript = Join-Path $userStartupRoot "tensix_first_run_startup.py"

New-Item -ItemType Directory -Force -Path $userAddonsRoot | Out-Null
New-Item -ItemType Directory -Force -Path $userStartupRoot | Out-Null

$resolvedAddonZip = Resolve-InstallerPath $AddonZip
$resolvedAddonFolder = Resolve-InstallerPath $AddonFolder
$resolvedStartupHelperScript = Resolve-InstallerPath $StartupHelperScript

if (Test-Path $targetAddon) {
    Remove-Item -Recurse -Force $targetAddon
}

if (Test-Path $resolvedAddonFolder) {
    Copy-Item -Recurse -Force $resolvedAddonFolder $targetAddon
    Write-Host "Installed io_scene_tensix2 from folder into $targetAddon"
}
elseif (Test-Path $resolvedAddonZip) {
    Expand-Archive -Path $resolvedAddonZip -DestinationPath $userAddonsRoot -Force
    Write-Host "Installed io_scene_tensix2 from zip into $userAddonsRoot"
}
else {
    Write-Error "Could not find io_scene_tensix2 folder or zip next to this installer. Use the extracted bundle root that contains io_scene_tensix2 and support/."
}

if (Test-Path $resolvedStartupHelperScript) {
    Copy-Item -Force $resolvedStartupHelperScript $targetStartupScript
    Write-Host "Installed first-run startup helper into $targetStartupScript"
}

Write-Host "Next steps for the artist:"
Write-Host "1. Launch Blender $BlenderVersion"
Write-Host "2. The first-run helper will try to enable '10six Toolkit 4.0' and create a quick-start text block"
Write-Host "3. Open the 10six panel"
Write-Host "4. Set 10six Data Root to the parent folder containing your original 10six data folders"